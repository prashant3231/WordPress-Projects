<?php
/*
Plugin Name:  Woocommerce Reminder For Orders
Plugin URI:   https://www.callanerd.help
Description:  Woocommerce email notifications for unpaid orders (Sends weekly emails to customers having pending or on hold orders upto 3 weeks and then mark the order cancelled and update stocks. This functionality will start working automatically when the plugin activated there are no option need to set for this plugin.)
Version:      1.0.0
License:      GPLv2 or later
Author:       Felix Patzelt
Author URI:   https://www.callanerd.help
Text Domain:  woocommerce-reminder-for-orders
Domain Path:  /languages
*/

// Do not allow direct access!
if ( ! defined( 'ABSPATH' ) ) {
	die( 'Forbidden' );
}
global $wpdb;
/**
 *  Add a custom email to the list of emails WooCommerce should load
 *
 * @since 0.1
 * @param array $email_classes available email classes
 * @return array filtered available email classes
 */
function add_expedited_order_woocommerce_email( $email_classes ) {
	// include our custom email class
	require_once( 'includes/class-wc-expedited-order-email.php' );
	// add the email class to the list of email classes that WooCommerce loads
	$email_classes['WC_Expedited_Order_Email'] = new WC_Expedited_Order_Email();
	return $email_classes;
}
add_filter( 'woocommerce_email_classes', 'add_expedited_order_woocommerce_email' );

/*cancelled*/

remove_filter( 'woocommerce_cancel_unpaid_orders', 'wc_cancel_unpaid_orders' );
add_filter( 'woocommerce_cancel_unpaid_orders', 'override_cancel_unpaid_orders' );



function override_cancel_unpaid_orders() {
    

    //$data_store    = WC_Data_Store::load( 'order' );
    /*$unpaid_orders = $data_store->get_unpaid_orders( strtotime( '-' . absint( $held_duration ) . ' MINUTES', current_time( 'timestamp' ) ) );*/
	 global $wpdb;

              
/*$unpaid_orders = $wpdb->get_col( $wpdb->prepare( "
		SELECT 	posts.ID
		FROM 	{$wpdb->posts} AS posts
		WHERE 	posts.post_type = 'shop_order'
		AND 	(posts.post_status = 'wc-on-hold' OR posts.post_status = 'wc-pending')
		AND 	posts.post_date < %s
	", date( 'Y-m-d H:i:s', strtotime('-21 days') )  ) );*/
	
	$unpaid_orders = $wpdb->get_col( $wpdb->prepare( "
		SELECT 	posts.ID
		FROM 	{$wpdb->posts} AS posts
		WHERE 	posts.post_type = 'shop_order'
		AND 	(posts.post_status = 'wc-on-hold' OR posts.post_status = 'wc-pending')
		AND 	posts.post_date < %s
	", date( 'Y-m-d H:i:s', strtotime('-3 minutes') )  ) );

    if ( $unpaid_orders ) {
        foreach ( $unpaid_orders as $unpaid_order ) {
            //$order = wc_get_order( $unpaid_order );
$order = new WC_Order( $unpaid_order );
            if ( apply_filters( 'woocommerce_cancel_unpaid_order', 'checkout' === $order->get_created_via(), $order ) ) {
                //Cancel Order
                $order->update_status( 'cancelled', __( 'Unpaid order cancelled - time limit reached.', 'woocommerce' ) );

                //Restock
                foreach ($order->get_items() as $item_id => $item) {
                    // Get an instance of corresponding the WC_Product object
                    $product = $item->get_product();
                    $qty = $item->get_quantity(); // Get the item quantity
                    wc_update_product_stock($product, $qty, 'increase');
                }
            }
        }
    }
    
}

// To change the amount of days just change '-7 days' to your liking.



/*cancelled*/
function email_past_due() {

global $wpdb;




	
	$mailer     =  WC_Emails::instance();
	//$date       = date( "Y-m-d H:i:s", current_time( 'timestamp' ) + 86400 * 7 );
	$date       = date( "Y-m-d H:i:s", current_time( 'timestamp' ) + 60 );
	
	
	
	
	
	
	
	$due_orders = $wpdb->get_col( $wpdb->prepare( "
		SELECT 	posts.ID
		FROM 	{$wpdb->posts} AS posts
		WHERE 	posts.post_type = 'shop_order'
		AND 	(posts.post_status = 'wc-on-hold' OR posts.post_status = 'wc-pending')
		AND 	posts.post_date < %s
	", $date ) );
	
	if ( $due_orders ) {
		foreach ( $due_orders as $due_order ) {
			$order = new WC_Order( $due_order );
			//$order = wc_get_order( $due_order );
			//var_dump($order);
			///$mailer->customer_invoice_pending( $order );
			$mailer = WC()->mailer();
			$mails = $mailer->get_emails();
			if ( ! empty( $mails ) ) {
				foreach ( $mails as $mail ) {
					if ( $mail->id == 'customer_invoice_pending' ) {
					   //$mail->trigger( $order->id );
					}
				 }
			}
			
		}
	}
}


function custom_time_cron( $schedules ) {

    /*$schedules['every_week'] = array(
            'interval'  => 604800, //604800 seconds in 1 week
            'display'   => esc_html__( 'Every Week', 'woocommerce-reminder-for-orders' )
    );*/
	$schedules['every_min'] = array(
            'interval'  => 60, //604800 seconds in 1 week
            'display'   => esc_html__( 'Every Min', 'woocommerce-reminder-for-orders' )
    );
    return $schedules;
}
add_filter( 'cron_schedules', 'custom_time_cron' );

add_action( 'my_cron_hook_reminders', 'my_cron_function' );

if (!function_exists('mytheme_my_activation')) {
    function mytheme_my_activation() {
        if (!wp_next_scheduled('my_cron_hook_reminders')) {
            //wp_schedule_event( time(), 'every_week', 'my_cron_hook_reminders' );
            wp_schedule_event( time(), 'every_min', 'my_cron_hook_reminders' );
        }
    }
}

add_action('wp', 'mytheme_my_activation');

if (!function_exists('my_cron_function')) {
    function my_cron_function() {
         email_past_due();	
		$held_duration = get_option( 'woocommerce_hold_stock_minutes' );
//$held_duration="30240";//3weeks
$held_duration="3";
	
    if ( $held_duration < 1 || 'yes' !== get_option( 'woocommerce_manage_stock' ) ) {
        return;
    }

wp_clear_scheduled_hook( 'woocommerce_cancel_unpaid_orders' );
    wp_schedule_single_event( time() + ( absint( $held_duration ) * 60 ), 'woocommerce_cancel_unpaid_orders' );
		//exit;
    }
}
//add_action('wp', 'email_past_due');