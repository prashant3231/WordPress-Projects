<?php
require_once('./ActiveCampaign.php');

$ac = new ActiveCampaign();
//get account listing
$accounts = $ac->account_list();
print_r($accounts);

// Add new account
$params = array(
    'account'                  => 'mynewaccount', // account name; subdomain portion only
    'cname'                    => 'mynewaccount.mydomain.com', // optional custom domain name
    'name'                     => 'Joe Client', // client's name
    'email'                    => 'joe.client@gmail.com', // client's email address
    'notification'             => 'support-joe@mydomain.com', // notification email address
    'plan'                     => '2', // 500 subscribers monthly plan
    'language'                 => 'spanish', // setup with spanish as a language
    'timezone'                 => 'Europe/Madrid', // setup with timezone set to Madrid, Spain
    //'snapshot'      => '467636f06d275e24b2d3c0c2673db5201', //ID of the snapshot this account should use (optional)
);
$account = $ac->account_add($params);
print_r($account);