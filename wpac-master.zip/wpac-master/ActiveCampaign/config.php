<?php
define('API_URL', 'https://www.activecampaign.com');
define('API_KEY', '4ed653e7dfe5414c8d43a9c330602a976036760a471e234a71967d3ffb64d1d07ee51b78');