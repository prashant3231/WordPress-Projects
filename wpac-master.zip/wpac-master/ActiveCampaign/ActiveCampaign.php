<?php
require_once('./APIAgent.php');

class ActiveCampaign{	
	function __construct() {	
		$this->agent = new APIAgent(); 
	}
	
	public function account_list(array $params=array()){
		$default_params = array(
			'search'=> '', //Any search phrase you wish to use to find accounts
			'planfilter'=> '',//Possible values: 'all' (default), 'trial', 'credit', 'monthly', or 'yearly'
			'statusfilter'=> '',  //Possible values: 'active' (default), 'expired', or 'all'
			'page'=> '',//Results returned in groups of 20 per page by default. Example values: '1', '2', '3', etc.
		);
		$params = array_merge($default_params, $params);
		$list = $this->agent->get('api.php', $params);
		
		if($list) return $list;
		return array();
	}
	
	public function account_add(array $params){
		$default_params = array(
			'account'=> '',// account name; subdomain portion only
			'cname'=> '', // optional custom domain 
			'name'=> '', // client's name
			'email'=> '', // client's email address
			'notification'=> '',  // notification email address
			'plan'=> '',   // subscribers monthly plan
			'language'=> 'spanish',   // setup with a language
			'timezone'=> 'Europe/Madrid',   // setup with timezone set to Madrid, 
		);
		$params = array_merge($default_params, $params);
		$account = $this->agent->post('api.php', 
									array('api_action'   => 'account_add'),
									$params);
		
		return $account;
	}
}
