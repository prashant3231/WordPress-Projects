<?php
require_once('./config.php');

class APIAgent{
	var $data_type = 'json';
	
	function __construct() {
		$this->request = curl_init();
		$this->params = array(
			'api_key' => API_KEY,
			'api_output' => $this->data_type
		);
		curl_setopt($this->request, CURLOPT_HEADER, 0);
		curl_setopt($this->request, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($this->request, CURLOPT_FOLLOWLOCATION, true);
		//curl_setopt($request, CURLOPT_SSL_VERIFYPEER, FALSE);
	}
	
	
	/**
	* Execute API GET method
	*
	* Wrapup the GET cURL call
	* @param string $end_point API end point.
	* @param array $params.
	* @return json_decode.
	*/
	public function get($end_point, array $params){
		$this->params += $params;
		return $this->_exe($end_point);
	}
	
	/**
	* Execute API POST method
	*
	* Wrapup the POST cURL call
	* @param string $end_point API end point.
	* @param array $params.
	* @param array $data.
	* @return json_decode.
	*/
	public function post($end_point, array $params, array $data){
		$this->params += $params;
		curl_setopt($this->request, CURLOPT_POSTFIELDS, http_build_query($data));
		
		return $this->_exe($end_point);
	}
	
	/**
	* Private method to excute the cURL
	*
	* @param string $end_point. 
	* @return json_decode.
	*/
	private function _exe($end_point){
		curl_setopt( $this->request, 
						CURLOPT_URL, 
						API_URL . '/' . $end_point . '?' . http_build_query($this->params));
		
		$response = curl_exec($this->request);
		
		$info = curl_getinfo($this->request);
		if($info['http_code'] != 200 ){
			 throw new Exception(curl_error($this->request));
		}
		
		return json_decode($response);
	}
	
	
	/**
	* Close the cURL request
	*/
	public function close(){
		curl_close($request);
	}
}