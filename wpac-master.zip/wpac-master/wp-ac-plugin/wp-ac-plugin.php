<?php 
/**
 * Plugin Name: WordPress ActiveCampaign Plugin
 * Description: Plugin will Create account for new account for new subscribers to certain product.
Plugin will check if the payment is not going through then it’ll pause the account.
If the client paid, it’ll resume the plan on the reseller.
 * Author: Miami Marketer
 * Author URI: https://miamimarketer.com/
 * Version: 1.0.0
 * Text Domain: wp-ac-plugin
 */

if (!defined('ABSPATH')) {
	exit;
}

add_action( 'admin_menu', 'wpse4677_admin_menu' );
function wp_ac_plugin_admin_menu()
{
    add_options_page(
        'WP AC Plugin',
        'WP AC Plugin',
        'manage_options', // Minimum capability to view this page
        'wp-ac-plugin-admin-options', // Unique identifier
        'wp_ac_plugin_options_contents' // Callback function to get the contents
    );
}

function wp_ac_plugin_options_contents() {
?>
    <!-- Create a header in the default WordPress 'wrap' container -->
    <div class="wrap">
     
        <div id="icon-themes" class="icon32"></div>
        <h2>WP AC Dashboard</h2>
        <?php settings_errors(); ?>
         
        <?php
            if( isset( $_GET[ 'tab' ] ) ) {
                $active_tab = $_GET[ 'tab' ];
            } // end if
        ?>
         
        <h2 class="nav-tab-wrapper">
            <a href="?page=wp-ac-plugin-admin-options&tab=settings" class="nav-tab <?php echo $active_tab == 'settings' ? 'nav-tab-active' : ''; ?>">Settings</a>
            <a href="?page=wp-ac-plugin-admin-options&tab=subscribers" class="nav-tab <?php echo $active_tab == 'subscribers' ? 'nav-tab-active' : ''; ?>">Manage Subscribers</a>
        </h2>
         
        <form method="post" action="options.php">
    <?php
         
        if( $active_tab == 'settings' ) {
            settings_fields( 'wp_ac_plugin_options_settings' );
            do_settings_sections( 'wp_ac_plugin_options_settings' );
        } else {
            settings_fields( 'wp_ac_plugin_options_subscribers' );
            do_settings_sections( 'wp_ac_plugin_options_subscribers' );
        } // end if/else
         
        submit_button();
         
    ?>
</form>
         
    </div><!-- /.wrap -->
<?php
} // end admin_dashboard_display