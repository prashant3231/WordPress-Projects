<?php

/*===============================================*\
|| ############################################# ||
|| # JAKWEB.CH / Version 2.4                   # ||
|| # ----------------------------------------- # ||
|| # Copyright 2019 JAKWEB All Rights Reserved # ||
|| ############################################# ||
\*===============================================*/

// Error reporting:
error_reporting(E_ALL^E_NOTICE);

// The DB connections data
require_once 'include/db.php';

// Do not go any further if install folder still exists
if (is_dir('install')) die('Please delete or rename install folder.');

if (!JAK_CACHE_DIRECTORY) die('Please define a cache directory in the db.php.');

// Start the session
session_start();

// Absolute Path
define('APP_PATH', dirname(__file__) . DIRECTORY_SEPARATOR);

if (isset($_SERVER['SCRIPT_NAME'])) {

    # on Windows _APP_MAIN_DIR becomes \ and abs url would look something like HTTP_HOST\/restOfUrl, so \ should be trimed too
    # @modified Chis Florinel <chis.florinel@candoo.ro>
    $app_main_dir = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
    define('_APP_MAIN_DIR', $app_main_dir);
} else {
    die('[config.php] Cannot determine APP_MAIN_DIR, please set manual and comment this line');
}

// Get the DB class
require_once 'class/class.db.php';

// Change for 3.0.3
use JAKWEB\JAKsql;

// Database connection
$jakdb = new JAKsql([
    // required
    'database_type' => JAKDB_DBTYPE,
    'database_name' => JAKDB_NAME,
    'server' => JAKDB_HOST,
    'username' => JAKDB_USER,
    'password' => JAKDB_PASS,
    'charset' => 'utf8',
    'port' => JAKDB_PORT,
    'prefix' => JAKDB_PREFIX,
 
    // [optional] driver_option for connection, read more from http://www.php.net/manual/en/pdo.setattribute.php
    'option' => [PDO::ATTR_CASE => PDO::CASE_NATURAL]
    ]);

// All important files
include_once 'include/functions.php';
include_once 'class/class.browser.php';
include_once 'class/class.jakbase.php';
include_once 'class/PHPMailerAutoload.php';
include_once 'class/class.userlogin.php';
include_once 'class/class.user.php';

// Windows Fix if !isset REQUEST_URI
if (!isset($_SERVER['REQUEST_URI']))
{
	$_SERVER['REQUEST_URI'] = substr($_SERVER['PHP_SELF'],1 );
	if (isset($_SERVER['QUERY_STRING'])) { $_SERVER['REQUEST_URI'].='?'.$_SERVER['QUERY_STRING']; }
}

// Now launch the rewrite class, depending on the settings in db.
$_SERVER['REQUEST_URI'] = htmlspecialchars($_SERVER['REQUEST_URI'], ENT_QUOTES);
$getURL = New JAK_rewrite($_SERVER['REQUEST_URI']);

// We are not using apache so take the ugly urls
$tempp = $getURL->jakGetseg(0);
$tempp1 = $getURL->jakGetseg(1);
$tempp2 = $getURL->jakGetseg(2);
$tempp3 = $getURL->jakGetseg(3);
$tempp4 = $getURL->jakGetseg(4);
$tempp5 = $getURL->jakGetseg(5);
$tempp6 = $getURL->jakGetseg(6);
$tempp7 = $getURL->jakGetseg(7);

// Check if we want caching
if (!is_dir(APP_PATH.JAK_CACHE_DIRECTORY)) mkdir(APP_PATH.JAK_CACHE_DIRECTORY, 0755);

// define file better for caching
$cachedefinefile = APP_PATH.JAK_CACHE_DIRECTORY.'/define.php';

if (!file_exists($cachedefinefile)) {

$allsettings = "<?php\n";

// Get the general settings out the database
$datasett = $jakdb->select("settings",["varname", "used_value"]);
foreach ($datasett as $row) {
    // Now check if sting contains html and do something about it!
    if (strlen($row['used_value']) != strlen(filter_var($row['used_value'], FILTER_SANITIZE_STRING))) {
    	$defvar  = 'htmlspecialchars_decode("'.htmlspecialchars($row['used_value']).'")';
    } else {
    	$defvar = "'".$row["used_value"]."'";
    }
    	
    $allsettings .= "define('JAK_".strtoupper($row['varname'])."', ".$defvar.");\n";
}
    
$allsettings .= "?>";
        
JAK_base::jakWriteinCache($cachedefinefile, $allsettings, '');

}

// Now include the created definefile
include_once $cachedefinefile;

// Now go with the operatorid
if (isset($_GET['id']) && is_numeric($_GET['id']) && !isset($_SESSION['widgetid']) || (isset($_GET['id']) && isset($_SESSION['widgetid']) && $_SESSION['widgetid'] != $_GET['id'])) $_SESSION['widgetid'] = $_GET['id'];

// Check if there is a quick link
if (!isset($_SESSION['widgetid'])) {

    $page = ($tempp ? jak_url_input_filter($tempp) : '');
    $page1 = ($tempp1 ? jak_url_input_filter($tempp1) : '');

    if ($page == 'link' && is_numeric($page1)) $_SESSION['widgetid'] = $page1;

}

// Get the operator settings
if (isset($_SESSION['widgetid'])) {
    $cacheopid = APP_PATH.JAK_CACHE_DIRECTORY.'/opcache'.$_SESSION['widgetid'].'.php';

    if (!file_exists($cacheopid)) {

        $opsett = "<?php\n";

        // Get the chat widget out the database
        $reswidg = $jakdb->get("chatwidget", "*", ["opid" => $_SESSION['widgetid']]);
        if (isset($reswidg) && !empty($reswidg)) {

            $opsett .= "\$jakwidget = array();\n";

            $opsett .= "\$jakwidget['id'] = ".$reswidg['id'].";\n\$jakwidget['opid'] = ".$reswidg['opid'].";\n\$jakwidget['title'] = '".addslashes($reswidg['title'])."';\n\$jakwidget['whatsapp_message'] = '".addslashes($reswidg['whatsapp_message'])."';\n\$jakwidget['depid'] = ".$reswidg['depid'].";\n\$jakwidget['singleopid'] = ".$reswidg['singleopid'].";\n\$jakwidget['lang'] = '".stripcslashes($reswidg['lang'])."';\n\$jakwidget['widget'] = ".$reswidg['widget'].";\n\$jakwidget['hideoff'] = ".$reswidg['hideoff'].";\n\$jakwidget['buttonimg'] = '".stripcslashes($reswidg['buttonimg'])."';\n\$jakwidget['mobilebuttonimg'] = '".stripcslashes($reswidg['mobilebuttonimg'])."';\n\$jakwidget['slideimg'] = '".stripcslashes($reswidg['slideimg'])."';\n\$jakwidget['floatpopup'] = ".$reswidg['floatpopup'].";\n\$jakwidget['chat_direct'] = ".$reswidg['chat_direct'].";\n\$jakwidget['whatsapp_online'] = ".$reswidg['whatsapp_online'].";\n\$jakwidget['whatsapp_offline'] = ".$reswidg['whatsapp_offline'].";\n\$jakwidget['client_email'] = ".$reswidg['client_email'].";\n\$jakwidget['client_semail'] = ".$reswidg['client_semail'].";\n\$jakwidget['client_phone'] = ".$reswidg['client_phone'].";\n\$jakwidget['client_sphone'] = ".$reswidg['client_sphone'].";\n\$jakwidget['client_question'] = ".$reswidg['client_question'].";\n\$jakwidget['client_squestion'] = ".$reswidg['client_squestion'].";\n\$jakwidget['show_avatar'] = ".$reswidg['show_avatar'].";\n\$jakwidget['floatcss'] = '".stripcslashes($reswidg['floatcss'])."';\n\$jakwidget['floatcsschat'] = '".stripcslashes($reswidg['floatcsschat'])."';\n\$jakwidget['engagecss'] = '".stripcslashes($reswidg['engagecss'])."';\n\$jakwidget['btn_animation'] = '".stripcslashes($reswidg['btn_animation'])."';\n\$jakwidget['chat_animation'] = '".stripcslashes($reswidg['chat_animation'])."';\n\$jakwidget['engage_animation'] = '".stripcslashes($reswidg['engage_animation'])."';\n\$jakwidget['sucolor'] = '".stripcslashes($reswidg['sucolor'])."';\n\$jakwidget['sutcolor'] = '".stripcslashes($reswidg['sutcolor'])."';\n\$jakwidget['template'] = '".stripcslashes($reswidg['template'])."';\n\$jakwidget['theme_colour'] = '".stripcslashes($reswidg['theme_colour'])."';\n\$jakwidget['body_colour'] = '".$reswidg['body_colour']."';\n\$jakwidget['h_colour'] = '".$reswidg['h_colour']."';\n\$jakwidget['c_colour'] = '".$reswidg['c_colour']."';\n\$jakwidget['time_colour'] = '".$reswidg['time_colour']."';\n\$jakwidget['link_colour'] = '".$reswidg['link_colour']."';\n\$jakwidget['sidebar_colour'] = '".$reswidg['sidebar_colour']."';\n\$jakwidget['t_font'] = '".stripcslashes($reswidg['t_font'])."';\n\$jakwidget['h_font'] = '".stripcslashes($reswidg['h_font'])."';\n\$jakwidget['c_font'] = '".stripcslashes($reswidg['c_font'])."';\n\$jakwidget['whitelist'] = '".stripcslashes($reswidg['widget_whitelist'])."';\n"; 
        }

        // Get the general settings out the database
        $dataops = $jakdb->get("op_settings", "*", ["opid" => $reswidg['opid']]);
        if (isset($dataops) && !empty($dataops)) {

            $opsett .= "\n\$jakopsett = array();\n";

            $opsett .= "\$jakopsett['opid'] = ".$dataops['opid'].";\n\$jakopsett['title'] = '".addslashes($dataops['title'])."';\n\$jakopsett['email'] = '".stripcslashes($dataops['email'])."';\n\$jakopsett['lang'] = '".stripcslashes($dataops['lang'])."';\n\$jakopsett['dateformat'] = '".$dataops['dateformat']."';\n\$jakopsett['timeformat'] = '".$dataops['timeformat']."';\n\$jakopsett['newclient'] = '".stripcslashes($dataops['newclient'])."';\n\$jakopsett['newmsg'] = '".stripcslashes($dataops['newmsg'])."';\n\$jakopsett['showalert'] = ".$dataops['showalert'].";\n\$jakopsett['sendtrans'] = ".$dataops['sendtrans'].";\n\$jakopsett['feedback'] = ".$dataops['feedback'].";\n\$jakopsett['ratings'] = ".$dataops['ratings'].";\n\$jakopsett['holiday_mode'] = ".$dataops['holiday_mode'].";\n\$jakopsett['contactredi'] = ".$dataops['contactredi'].";\n\$jakopsett['contacttime'] = ".$dataops['contacttime'].";\n\$jakopsett['contacturl'] = '".stripcslashes($dataops['contacturl'])."';\n\$jakopsett['dsgvo'] = '".stripcslashes($dataops['dsgvo'])."';\n\$jakopsett['timezone'] = '".stripcslashes($dataops['timezone'])."';\n\$jakopsett['emailprotocol'] = ".$dataops['emailprotocol'].";\n\$jakopsett['smtphost'] = '".stripcslashes($dataops['smtphost'])."';\n\$jakopsett['smtpport'] = ".$dataops['smtpport'].";\n\$jakopsett['smtpalive'] = ".$dataops['smtpalive'].";\n\$jakopsett['smtpauth'] = ".$dataops['smtpauth'].";\n\$jakopsett['smtpprefix'] = '".stripcslashes($dataops['smtpprefix'])."';\n\$jakopsett['smtpuser'] = '".stripcslashes($dataops['smtpuser'])."';\n\$jakopsett['smtppass'] = '".stripcslashes($dataops['smtppass'])."';\n\$jakopsett['clientsound'] = '".stripcslashes($dataops['clientsound'])."';\n\$jakopsett['soundalert'] = '".stripcslashes($dataops['soundalert'])."';\n\$jakopsett['created'] = '".$dataops['created']."';\n";
        }

        // Get the subscription out the database
        $opsett .= "\n\$jakosub = array();\n";
        $dataosub = $jakdb->get("subscriptions", "*", ["opid" => $reswidg['opid']]);
        if (isset($dataosub) && !empty($dataosub)) {

            $opsett .= "\$jakosub['id'] = ".$dataosub['id'].";\n\$jakosub['packageid'] = ".$dataosub['packageid'].";\n\$jakosub['opid'] = ".$dataosub['opid'].";\n\$jakosub['operators'] = ".$dataosub['operators'].";\n\$jakosub['extraoperators'] = ".$dataosub['extraoperators'].";\n\$jakosub['departments'] = ".$dataosub['departments'].";\n\$jakosub['files'] = ".$dataosub['files'].";\n\$jakosub['copyfree'] = ".$dataosub['copyfree'].";\n\$jakosub['activechats'] = ".$dataosub['activechats'].";\n\$jakosub['validfor'] = ".$dataosub['validfor'].";\n\$jakosub['trial'] = ".$dataosub['trial'].";\n\$jakosub['active'] = ".$dataosub['active'].";\n\$jakosub['paidtill'] = '".$dataosub['paidtill']."';\n";
        }

        // empty vars
        $answergrid = $responsegrid = $autoproactivegrid = array();

        $opsett .= "\n";

        // Get the general settings out the database
        $datafiles = $jakdb->select("files",["id", "path", "name"], ["opid" => $reswidg['opid']]);
        if (isset($datafiles) && !empty($datafiles)) foreach ($datafiles as $rowf) {
            $filesgrid[] = $rowf;
        }
            
        // Get the answers out the database
        $dataansw = $jakdb->select("answers", ["id", "opid", "department", "lang", "message", "fireup", "msgtype"], ["opid" => $reswidg['opid']]);
        if (isset($dataansw) && !empty($dataansw)) foreach ($dataansw as $rowa) {
            $answergrid[] = $rowa;
        }

        // Get the url black list
        $databl = $jakdb->select("urlblacklist", "path", ["opid" => $reswidg['opid']]);
        if (isset($databl) && !empty($databl)) foreach ($databl as $rowb) {
            $blacklistgrid[] = $rowb;
        }
            
        // Get the responses settings out the database
        $datares = $jakdb->select("responses", ["id", "opid", "department", "title", "message"], ["opid" => $reswidg['opid']]);
        if (isset($datares) && !empty($datares)) foreach ($datares as $rowr) {
            $responsegrid[] = $rowr;
        }

        // Get the chat bot out of the database
        $databot = $jakdb->select("bot_question", ["id", "opid", "depid", "lang", "question", "answer"], ["AND" => ["active" => 1, "opid" => $reswidg['opid']]]);
        if (isset($databot) && !empty($databot)) foreach ($databot as $rowba) {
            $botgrid[] = $rowba;
        }

        // Get the departments
        $datadep = $jakdb->select("departments", ["id", "title", "email", "faq_url"], ["AND" => ["opid" => $reswidg['opid'], "active" => 1], "ORDER" => ["dorder" => "ASC"]]);
        if (isset($datadep) && !empty($datadep)) foreach ($datadep as $rowd) {
            $departmentgrid[] = $rowd;
        }
            
        // Get the auto proactive out the database
        $dataproact = $jakdb->select("autoproactive", ["opid", "path", "title", "imgpath", "message", "btn_confirm", "btn_cancel", "showalert", "soundalert", "timeonsite", "visitedsites"], ["opid" => $reswidg['opid']]);
        if (isset($dataproact) && !empty($dataproact)) foreach ($dataproact as $rowap) {
            $autoproactivegrid[] = $rowap;
        }
            
        if (!empty($answergrid)) $opsett .= "\$answergserialize = '".base64_encode(gzcompress(serialize($answergrid)))."';\n\n\$LC_ANSWERS = unserialize(gzuncompress(base64_decode(\$answergserialize)));\n";

        if (!empty($blacklistgrid)) $opsett .= "\$blacklistserialize = '".base64_encode(gzcompress(serialize($blacklistgrid)))."';\n\n\$LC_BLACKLIST = unserialize(gzuncompress(base64_decode(\$blacklistserialize)));\n";
            
        if (!empty($responsegrid)) $opsett .= "\$responsegserialize = '".base64_encode(gzcompress(serialize($responsegrid)))."';\n\n\$LC_RESPONSES = unserialize(gzuncompress(base64_decode(\$responsegserialize)));\n";

        if (!empty($botgrid)) $opsett .= "\$botserialize = '".base64_encode(gzcompress(serialize($botgrid)))."';\n\n\$LC_BOT_ANSWER = unserialize(gzuncompress(base64_decode(\$botserialize)));\n";

        if (!empty($filesgrid)) $opsett .= "\$filesgserialize = '".base64_encode(gzcompress(serialize($filesgrid)))."';\n\n\$LC_FILES = unserialize(gzuncompress(base64_decode(\$filesgserialize)));\n";

        if (!empty($departmentgrid)) $opsett .= "\$departmentgserialize = '".base64_encode(gzcompress(serialize($departmentgrid)))."';\n\n\$LC_DEPARTMENTS = unserialize(gzuncompress(base64_decode(\$departmentgserialize)));\n";

        if (!empty($autoproactivegrid)) $opsett .= "\$autoproactiveserialize = '".base64_encode(gzcompress(serialize($autoproactivegrid)))."';\n\n\$LC_PROACTIVE = unserialize(gzuncompress(base64_decode(\$autoproactiveserialize)));\n";

        // Finally close the cache file
        $opsett .= "?>";

        JAK_base::jakWriteinCache($cacheopid, $opsett, '');

    }

    // Now include the created definefile
    include_once $cacheopid;
}

// timezone from server or individual from user
if (defined('JAK_TIMEZONESERVER')) {
    if (isset($jakopsett['timezone']) && $jakopsett['timezone'] != JAK_TIMEZONESERVER) {
        date_default_timezone_set($jakopsett['timezone']);
    } else {
        date_default_timezone_set(JAK_TIMEZONESERVER);
    }
}
$jakdb->query('SET time_zone = "'.date("P").'"');

// Check if https is activated
if (JAK_SITEHTTPS) {
    define('BASE_URL', 'https://' . FULL_SITE_DOMAIN . _APP_MAIN_DIR . '/');
} else {
    define('BASE_URL', 'http://' . FULL_SITE_DOMAIN . _APP_MAIN_DIR . '/');
}

// Your copyright link
$JAK_PCOPYRIGHT_LINK = '<a href="https://www.jibjab.chat">JibJab.Chat</a> / ';
// Remove the copyright when customer has paid for
if (isset($jakosub['copyfree']) && $jakosub['copyfree'] == 1) $JAK_PCOPYRIGHT_LINK = "";
// Copyright do only remove or change with a valid copyright free link license
define('JAK_COPYRIGHT_LINK', $JAK_PCOPYRIGHT_LINK.'<a href="https://www.jibjab.chat">Powered by JibJab.Chat</a>');

// Get the users ip address
$ipa = get_ip_address();

// Current date
$loc_date_now = new DateTime();
$JAK_CURRENT_DATE = $loc_date_now->format('Y-m-d H:i:s');
?>