<?php

/*===============================================*\
|| ############################################# ||
|| # JAKWEB.CH / Version 2.0                   # ||
|| # ----------------------------------------- # ||
|| # Copyright 2018 JAKWEB All Rights Reserved # ||
|| ############################################# ||
\*===============================================*/

// Database connection and setup
define('JAKDB_HOST', 'localhost'); // Database host ## Datenbank Server
define('JAKDB_DBTYPE', 'mysql'); // Database host ## Datenbank Server
define('JAKDB_PORT', 3306); // Enter the database port for your mysql server
define('JAKDB_USER', 'jibjab_hero'); // Database user ## Datenbank Benutzername
define('JAKDB_PASS', 'fsxL+%9E4A2%'); // Database password ## Datenbank Passwort
define('JAKDB_NAME', 'jibjab_newwave'); // Database name ## Datenbank Name
define('JAKDB_PREFIX', 'cc3_'); // Database prefix use (a-z) and (_)

// Database connection for the main site where user control is active
define('JAKDB_MAIN_HOST', 'localhost'); // Database host ## Datenbank Server
define('JAKDB_MAIN_DBTYPE', 'mysql'); // Database host ## Datenbank Server
define('JAKDB_MAIN_PORT', 3306); // Enter the database port for your mysql server
define('JAKDB_MAIN_USER', 'jibjab_gunner'); // Database user ## Datenbank Benutzername
define('JAKDB_MAIN_PASS', '9##zD,Tk!E~K'); // Database password ## Datenbank Passwort
define('JAKDB_MAIN_NAME', 'jibjab_chatter'); // Database name ## Datenbank Name
define('JAKDB_MAIN_PREFIX', ''); // Database prefix use (a-z) and (_)

// Location ID as defined in your MAIN Database
define('JAK_MAIN_LOC', 1);

// Define a unique key for your site, don't change after, or people can't login anymore. (https://www.jibjab.chat/faq/a/99/database-and-password-hash)
define('DB_PASS_HASH', 'ueKH3HD349!KDH2KDdd');

// Define your site url, for example: www.jibjab.chat (https://www.jibjab.chat/faq/a/98/full-site-domain)
define('FULL_SITE_DOMAIN', 'www.jibjab.chat');

// Define your sign up url, for example: https://www.jibjab.chat
define('SIGN_UP_URL', 'https://www.jibjab.chat');

// URL Rewrite
define('JAK_USE_APACHE', 0); // Use 1 for Apache / Nginx (SEO URL's) or 0 for all others

// Set http or https
define('JAK_SITEHTTPS', 1); // Site is running in HTTP 0 = / HTTPS = 1

// File Upload directory, absolute path. Read more about here: (https://www.jakweb.ch/faq/a/189/file-upload-for-cloud-chat-3)
define('CLIENT_UPLOAD_DIR', 'your_upload_path_goes_here');

// File encryption key/iv
define('JAK_FILE_SECRET_KEY', 'file_secret_key');
define('JAK_FILE_SECRET_IV', 'file_secret_iv');

// Operator panel
define('JAK_OPERATOR_LOC', 'operator'); // The operator folder, due not change except you have changed the operator folder name as well

// Define cookie path and lifetime
define('JAK_COOKIE_PATH', '/');  // Available in the whole domain
define('JAK_COOKIE_TIME', 60*60*24*30); // 30 days by default

// Choose a cache directory to reduce page and server load
define('JAK_CACHE_DIRECTORY', 'cache');

// Choose the userfiles directory, rename if you like different location
define('JAK_FILES_DIRECTORY', 'files');

// Operator Time
define('OPERATOR_CHAT_EXPIRE', '7200'); // If we have no activity from the operator it will expire after x seconds

// Important Stuff
define('JAK_SUPERADMIN', '1'); // Undeletable and SuperADMIN User, more user seperate with comma. e.g. 1,4,5,6 (userid)
?>