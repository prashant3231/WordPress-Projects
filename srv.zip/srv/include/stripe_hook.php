<?php

/*===============================================*\
|| ############################################# ||
|| # JAKWEB.CH / Version 2.1                   # ||
|| # ----------------------------------------- # ||
|| # Copyright 2018 JAKWEB All Rights Reserved # ||
|| ############################################# ||
\*===============================================*/

if (!file_exists('../config.php')) die('[ipn.php] config.php not exist');
require_once '../config.php';

// Stripe Api
require_once('operator/payment/stripe/Stripe.php');

// Get the absolute url for the image
$ava_url = str_replace('include/', '', BASE_URL);

// Change for 1.0.3
use JAKWEB\JAKsql;

// Set your secret key: remember to change this to your live secret key in production
// See your keys here https://dashboard.stripe.com/account

// Now if we have multi site we have fully automated process
if (!empty(JAKDB_MAIN_NAME) && JAK_MAIN_LOC) {
  
  // Database connection to the main site
  $jakdb1 = new JAKsql([
    // required
    'database_type' => JAKDB_MAIN_DBTYPE,
    'database_name' => JAKDB_MAIN_NAME,
    'server' => JAKDB_MAIN_HOST,
    'username' => JAKDB_MAIN_USER,
    'password' => JAKDB_MAIN_PASS,
    'charset' => 'utf8',
    'port' => JAKDB_MAIN_PORT,
    'prefix' => JAKDB_MAIN_PREFIX,
               
    // [optional] driver_option for connection, read more from http://www.php.net/manual/en/pdo.setattribute.php
    'option' => [PDO::ATTR_CASE => PDO::CASE_NATURAL]
    ]);

  // We get the settings for the payment
  $sett = array();
  $settings = $jakdb1->select("settings", ["varname", "used_value"]);
  foreach ($settings as $v) {
    $sett[$v["varname"]] = $v["used_value"]; 
  }

  $stripe = array(
    'secret_key'      => $sett["stripesecret"],
    'publishable_key' => $sett["stripepublic"]
  );
                     
  \Stripe\Stripe::setApiKey($sett["stripesecret"]);

  // Retrieve the request's body and parse it as JSON
  $input = @file_get_contents("php://input");

  if ($input) {
    $event_json = json_decode($input);

    // Do something with $event_json

    // for extra security, retrieve from the Stripe API
    $event_id = $event_json->id;
    $event = \Stripe\Event::retrieve($event_id);

    // You can find your endpoint's secret in your webhook settings
    $endpoint_secret = $sett["stripewebhook"];

    $sig_header = $_SERVER["HTTP_STRIPE_SIGNATURE"];
    $event = null;

    try {
      $event = \Stripe\Webhook::constructEvent(
        $payload, $sig_header, $endpoint_secret
      );

      // This will send receipts on reminder
      if (isset($event) && $event->type == "invoice.upcoming") {
        $customer = \Stripe\Customer::retrieve($event->data->object->customer);
        $email = $customer->email;
        $paygateid = $customer->id;

        $cu = $jakdb->get("subscriptions", ["[>]user" => ["opid" => "id"]], ["user.name", "user.email"], ["subscriptions.paygateid" => $paygateid]);

        $cuemail = $cu["email"] ? $cu["email"] : $email;

        // Finally inform the customer
        if (JAK_SMTP_MAIL) {
                  
          $mail->IsSMTP(); // telling the class to use SMTP
          $mail->Host = JAK_SMTPHOST;
          $mail->SMTPAuth = (JAK_SMTP_AUTH ? true : false); // enable SMTP authentication
          $mail->SMTPSecure = JAK_SMTP_PREFIX; // sets the prefix to the server
			    $mail->SMTPAutoTLS = false;
          $mail->SMTPKeepAlive = (JAK_SMTP_ALIVE ? true : false); // SMTP connection will not close after each email sent
          $mail->Port = JAK_SMTPPORT; // set the SMTP port for the GMAIL server
          $mail->Username = JAK_SMTPUSERNAME; // SMTP account username
          $mail->Password = JAK_SMTPPASSWORD; // SMTP account password
          $mail->SetFrom(JAK_EMAIL);
          $mail->AddAddress($cuemail);
                    
        } else {
                  
          $mail->SetFrom(JAK_EMAIL);
          $mail->AddAddress($cuemail);
                  
        }
                  
        $mail->Subject = JAK_TITLE.' - '.$sett["invoicetitle"];
        $mail->MsgHTML(sprintf($sett["invoicecontent"], $cu["name"], $ava_url));
        $mail->Send();

      }

      // This will send receipts on succesful invoices
      if (isset($event) && $event->type == "invoice.payment_succeeded") {
        $customer = \Stripe\Customer::retrieve($event->data->object->customer);
        $email = $customer->email;
        $paygateid = $customer->id;

        $cu = $jakdb->get("subscriptions", ["[>]user" => ["opid" => "id"]], ["subscriptions.opid", "subscriptions.packageid", "subscriptions.subscribeid", "user.name", "user.email"], ["subscriptions.paygateid" => $paygateid]);

        $pack = $jakdb1->get("packages", ["id", "validfor"], ["AND" => ["id" => $cu["packageid"], "active" => 1]]);

        $paidunix = strtotime("+".$pack["validfor"]." days");
        // get the nice time
        $paidtill = date('Y-m-d H:i:s', $paidunix);

        $jakdb->update("subscriptions", ["paidwhen" => $jakdb->raw("NOW()"), "paidtill" => $paidtill], ["opid" => $cu["opid"]]);

        $jakdb1->update("subscriptions", ["paidwhen" => $jakdb->raw("NOW()"), "paidtill" => $paidtill], ["AND" => ["locationid" => JAK_MAIN_LOC, "userid" => $cu["opid"], "subscribeid" => $cu["subscribeid"]]]);

        // Now let us delete the define cache file
        $cachewidget = APP_PATH.JAK_CACHE_DIRECTORY.'/opcache'.$cu["opid"].'.php';
        if (file_exists($cachewidget)) {
          unlink($cachewidget);
        }

        // Finally inform the customer
        if (JAK_SMTP_MAIL) {
                  
          $mail->IsSMTP(); // telling the class to use SMTP
          $mail->Host = JAK_SMTPHOST;
          $mail->SMTPAuth = (JAK_SMTP_AUTH ? true : false); // enable SMTP authentication
          $mail->SMTPSecure = JAK_SMTP_PREFIX; // sets the prefix to the server
			    $mail->SMTPAutoTLS = false;
          $mail->SMTPKeepAlive = (JAK_SMTP_ALIVE ? true : false); // SMTP connection will not close after each email sent
          $mail->Port = JAK_SMTPPORT; // set the SMTP port for the GMAIL server
          $mail->Username = JAK_SMTPUSERNAME; // SMTP account username
          $mail->Password = JAK_SMTPPASSWORD; // SMTP account password
          $mail->SetFrom(JAK_EMAIL);
          $mail->AddAddress($cuemail);
                    
        } else {
                  
          $mail->SetFrom(JAK_EMAIL);
          $mail->AddAddress($cuemail);
                  
        }
                  
        $mail->Subject = JAK_TITLE.' - '.$sett["subsctitle"];
        $mail->MsgHTML(sprintf($sett["subsctext"], $cu["name"], $ava_url));
        $mail->Send();

      }

      // This will send receipts on fail
      if (isset($event) && $event->type == "invoice.failed") {
        $customer = \Stripe\Customer::retrieve($event->data->object->customer);
        $email = $customer->email;
        $paygateid = $customer->id;

        $cu = $jakdb->get("subscriptions", ["[>]user" => ["opid" => "id"]], ["subscriptions.opid", "subscriptions.packageid", "subscriptions.subscribeid", "user.name", "user.email"], ["subscriptions.paygateid" => $paygateid]);

        $jakdb->update("subscriptions", ["packageid" => 0, "operators" => 1, "departments" => 1, "files" => 0, "activechats" => 3, "chathistory" => 30, "islc3" => 0, "ishd3" => 0, "validfor" => 0, "paygateid" => $v["paygateid"], "subscribeid" => 0, "subscribed" => 0, "amount" => 0, "currency" => "", "paidhow" => "expired", "paidwhen" => $jakdb->raw("NOW()"), "paidtill" => $paidtill, "trial" => 0, "active" => 0], ["opid" => $cu["opid"]]);

        $jakdb1->update("subscriptions", ["subscribeid" => 0, "subscribed" => 0, "active" => 0], ["AND" => ["locationid" => JAK_MAIN_LOC, "userid" => $cu["opid"], "subscribeid" => $cu["subscribeid"]]]);

        // Now let us delete the define cache file
        $cachewidget = APP_PATH.JAK_CACHE_DIRECTORY.'/opcache'.$cu["opid"].'.php';
        if (file_exists($cachewidget)) {
          unlink($cachewidget);
        }

        // Finally inform the customer
        if (JAK_SMTP_MAIL) {
                  
          $mail->IsSMTP(); // telling the class to use SMTP
          $mail->Host = JAK_SMTPHOST;
          $mail->SMTPAuth = (JAK_SMTP_AUTH ? true : false); // enable SMTP authentication
          $mail->SMTPSecure = JAK_SMTP_PREFIX; // sets the prefix to the server
			    $mail->SMTPAutoTLS = false;
          $mail->SMTPKeepAlive = (JAK_SMTP_ALIVE ? true : false); // SMTP connection will not close after each email sent
          $mail->Port = JAK_SMTPPORT; // set the SMTP port for the GMAIL server
          $mail->Username = JAK_SMTPUSERNAME; // SMTP account username
          $mail->Password = JAK_SMTPPASSWORD; // SMTP account password
          $mail->SetFrom(JAK_EMAIL);
          $mail->AddAddress($cuemail);
                    
        } else {
                  
          $mail->SetFrom(JAK_EMAIL);
          $mail->AddAddress($cuemail);
                  
        }
                  
        $mail->Subject = JAK_TITLE.' - '.$sett["failedtitle"];
        $mail->MsgHTML(sprintf($sett["failedtext"], $cu["name"], $ava_url));
        $mail->Send();
      }

    http_response_code(200); // PHP 5.4 or greater

    } catch(\UnexpectedValueException $e) {
      // Invalid payload
      http_response_code(400); // PHP 5.4 or greater
      exit();
    } catch(\Stripe\Error\SignatureVerification $e) {
      // Invalid signature
      http_response_code(400); // PHP 5.4 or greater
      exit();
    }
  }
}
die("nice try...");