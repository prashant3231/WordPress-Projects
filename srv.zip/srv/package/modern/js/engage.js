function lcjak_closeEngage(urlgo) {
	
  window.location = urlgo;
  return true;

}