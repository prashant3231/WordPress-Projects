<?php

/*===============================================*\
|| ############################################# ||
|| # JAKWEB.CH / Version 2.4                   # ||
|| # ----------------------------------------- # ||
|| # Copyright 2019 JAKWEB All Rights Reserved # ||
|| ############################################# ||
\*===============================================*/

// Check if the file is accessed only via index.php if not stop the script from running
if (!defined('JAK_ADMIN_PREVENT_ACCESS')) die('You cannot access this file directly.');

// Check if the user has access to this file
if (!jak_get_access("settings", $jakuser->getVar("permissions"), JAK_MAIN_OP)) jak_redirect(BASE_URL);

// All the tables we need for this plugin
$errors = $success = array();

// Let's go on with the script
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $jkp = $_POST;
    
    if (isset($jkp['save'])) {
    
        if ($jkp['jak_email'] == '' || !filter_var($jkp['jak_email'], FILTER_VALIDATE_EMAIL)) $errors['e1'] = $jkl['e3'];

        if (!is_numeric($jkp['jak_port'])) $errors['e2'] = $jkl['e15'];

        if (count($errors) == 0) {

            // Clean the dsgvo link
            include_once '../include/htmlawed.php';
            $htmlconfig = array('safe'=>1, 'elements'=>'a, strong', 'deny_attribute'=>'style', 'comment'=> 1, 'cdata' => 1, 'valid_xhtml' => 1, 'make_tag_strict' => 1); 
            $dsgvo_clean = htmLawed($_REQUEST['jak_dsgvo'], $htmlconfig);
            
            // Update the fields
            $update = $jakdb->update("op_settings", ["title" => $jkp['jak_title'], 
                "email" => $jkp['jak_email'],
                "lang" => $jkp['jak_lang'],
                "dateformat" => $jkp['jak_date'],
                "timeformat" => $jkp['jak_time'],
                "timezone" => $jkp['jak_timezone'],
                "newclient" => $jkp['jak_ringtone'],
                "newmsg" => $jkp['jak_msgtone'],
                "clientsound" => $jkp['jak_client_sound'],
                "showalert" => $jkp['showalert'],
                "sendtrans" => $jkp['jak_trans'],
                "feedback" => $jkp['jak_feedback'],
                "ratings" => $jkp['jak_rating'],
                "holiday_mode" => $jkp['jak_holidaym'],
                "contactredi" => $jkp['jak_contactredi'],
                "contacttime" => $jkp['jak_redi_contact'],
                "contacturl" => $jkp['url_red'],
                "dsgvo" => $dsgvo_clean,
                "soundalert" => $jkp['jak_engage_sound'],
                "emailprotocol" => $jkp['jak_smpt'],
                "smtphost" => $jkp['jak_host'],
                "smtpport" => $jkp['jak_port'],
                "smtpalive" => $jkp['jak_alive'],
                "smtpauth" => $jkp['jak_auth'],
                "smtpprefix" => $jkp['jak_prefix'],
                "smtpuser" => $jkp['jak_smtpusername'],
                "smtppass" => $jkp['jak_smtppassword'],
                "lastedit" => $jakdb->raw("NOW()")], ["opid" => $opcacheid]);

        if ($update) {
    		
            // Now let us delete the define cache file
            $cachedefinefile = APP_PATH.JAK_CACHE_DIRECTORY.'/opcache'.$opcacheid.'.php';
            if (file_exists($cachedefinefile)) {
                unlink($cachedefinefile);
            }

            $_SESSION["successmsg"] = $jkl['g14'];
            jak_redirect($_SESSION['LCRedirect']);

        }

    } else {
    
   	    $errors['e'] = $jkl['e'];
        $errors = $errors;
    }
    
    } else {
    
    	$mail = new PHPMailer(true); // the true param means it will throw exceptions on errors, which we need to catch
    
    	// Send email the smpt way or else the mail way
    	if ($jakopsett['emailprotocol']) {
    		
    		try {
        		$mail->IsSMTP(); // telling the class to use SMTP
        		$mail->Host = $jakopsett['smtphost'];
        		$mail->SMTPAuth = ($jakopsett['smtpauth'] ? true : false); // enable SMTP authentication
        		$mail->SMTPSecure = $jakopsett['smtpprefix']; // sets the prefix to the server
				$mail->SMTPAutoTLS = false;
        		$mail->SMTPKeepAlive = ($jakopsett['smtpalive'] ? true : false); // SMTP connection will not close after each email sent
        		$mail->Port = $jakopsett['smtpport']; // set the SMTP port for the GMAIL server
        		$mail->Username = $jakopsett['smtpuser']; // SMTP account username
        		$mail->Password = $jakopsett['smtppass'];        // SMTP account password
        		$mail->SetFrom($jakopsett['email']);
        		$mail->AddReplyTo($jakopsett['email']);
        		$mail->AddAddress($jakopsett['email']);
        		$mail->AltBody = $jkl["g215"]; // optional, comment out and test
        		$mail->Subject = $jkl["g216"];
        		$mail->MsgHTML($jkl["g217"].'SMTP.');
        		$mail->Send();
        		$success['e'] = $jkl["g217"].'SMTP.';
        	} catch (phpmailerException $e) {
    	    	$errors['e'] = $e->errorMessage(); //Pretty error messages from PHPMailer
        	} catch (Exception $e) {
        		$errors['e'] = $e->getMessage(); //Boring error messages from anything else!
        	}
    		
    	} else {
    	
    		try {
        		$mail->SetFrom(JAK_EMAIL);
        		$mail->AddReplyTo($jakopsett['email']);
        		$mail->AddAddress($jakopsett['email']);
        		$mail->AltBody = $jkl["g215"]; // optional, comment out and test
        		$mail->Subject = $jkl["g216"];
        		$mail->MsgHTML($jkl["g217"].'Mail().');
        		$mail->Send();
        		$success['e'] = $jkl["g217"].'Mail().';
    		} catch (phpmailerException $e) {
    			$errors['e'] = $e->errorMessage(); //Pretty error messages from PHPMailer
    		} catch (Exception $e) {
    		  	$errors['e'] = $e->getMessage(); //Boring error messages from anything else!
    		}
    	
    	}
    
    }
    
}

// Call the settings function
$lang_files = jak_get_lang_files();

// Get all sound files
$sound_files = jak_get_sound_files();

// Title and Description
$SECTION_TITLE = $jkl["m5"];
$SECTION_DESC = "";

// Include the javascript file for results
$js_file_footer = 'js_settings.php';

// Call the template
$template = 'opsetting.php';

?>