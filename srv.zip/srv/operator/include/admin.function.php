<?php

/*===============================================*\
|| ############################################# ||
|| # JAKWEB.CH / Version 2.3                   # ||
|| # ----------------------------------------- # ||
|| # Copyright 2018 JAKWEB All Rights Reserved # ||
|| ############################################# ||
\*===============================================*/

// Get the data per array for page,newsletter with limit
function jak_get_page_info($table, $opid, $limit = "") 
{
	global $jakdb;
	if (!empty($limit)) {
    	$datatable = $jakdb->select($table, "*", ["opid" => $opid, "ORDER" => ["id" => "DESC"], "LIMIT" => $limit]);
    } else {
    	$datatable = $jakdb->select($table, "*", ["opid" => $opid, "ORDER" => ["id" => "DESC"]]);
    }
        
    if (!empty($datatable)) return $datatable;
}
// Get the data per array for page,newsletter with limit
function jak_get_page_info_admin($table, $limit = "") 
{
	global $jakdb;
	if (!empty($limit)) {
    	$datatable = $jakdb->select($table, "*", ["ORDER" => ["id" => "DESC"], "LIMIT" => $limit]);
    } else {
    	$datatable = $jakdb->select($table, "*", ["ORDER" => ["id" => "DESC"]]);
    }
        
    if (!empty($datatable)) return $datatable;
}

// Search for lang files in the admin folder, only choose .ini files.
function jak_get_lang_files() {

	// Get the language folder
	$langdir = '../lang/';
	
	if ($handle = opendir($langdir)) {
	
	    /* This is the correct way to loop over the directory. */
	    while (false !== ($file = readdir($handle))) {
	    $showlang = substr($file, strrpos($file, '.'));
	    if ($file != '.' && $file != '..' && $showlang == '.php') {
	    
	    	$getlang[] = substr($file, 0, -4);
	    
	    }
	    }
		return $getlang;
	    closedir($handle);
	}
}

// Search for lang files in the admin folder, only choose .ini files.
function jak_get_chat_packages() {

	// Get the language folder
	$packdir = '../'.'package/';

	return array_diff(scandir($packdir), array('..', '.', 'index.html', '.DS_Store'));
}

// Search for lang files in the admin folder, only choose .ini files.
function jak_get_sound_files() {

	$getsound = array();

	global $jakdb;
	// Get the sounds from the installed packages
	$packsound = $jakdb->select("chatwidget", "template", ["GROUP" => "template"]);

    if (isset($packsound) && !empty($packsound)) {

        foreach ($packsound as $v) {

        	$packagef = 'package/'.$v.'/';
			if (file_exists('../'.$packagef.'config.php')) {

				include_once '../'.$packagef.'config.php';

	        	if (isset($jakgraphix["sound"]) && !empty($jakgraphix["sound"])) {

	        		// Get the general sounds
					$dynsound = '../'.$packagef.$jakgraphix["sound"];

					if ($dynhandle = opendir($dynsound)) {
					
					    /* This is the correct way to loop over the directory. */
					    while (false !== ($dynfile = readdir($dynhandle))) {
					    	$dynshowsound = substr($dynfile, strrpos($dynfile, '.'));
						    if ($dynfile != '.' && $dynfile != '..' && $dynshowsound == '.mp3') {
						    
						    	$getsound[] = $packagef.$jakgraphix["sound"].substr($dynfile, 0, -4);
						    
						    }
					    }
					    closedir($dynhandle);
					}
	        	}
	        }
        }
    }
	
	// Get the general sounds
	$soundir = '../sound/';

	if ($handle = opendir($soundir)) {
	
	    /* This is the correct way to loop over the directory. */
	    while (false !== ($file = readdir($handle))) {
		    $showsound = substr($file, strrpos($file, '.'));
		    if ($file != '.' && $file != '..' && $showsound == '.mp3') {
		    
		    	$getsound[] = 'sound/'.substr($file, 0, -4);
		    
		    }
	    }
	    closedir($handle);
		return $getsound;
	    
	}
}

// Get all user out the database limited with the paginator
function jak_get_user_all($table, $userid, $limit = '') {

	global $jakdb;
	if ($userid) {
		if ($limit == "meandsibling") {
			$datausr = $jakdb->select($table, "*", ["OR" => ["id" => $userid, "opid" => $userid]]);
		} elseif ($limit == "siblings") {
			$datausr = $jakdb->select($table, "*", ["AND" => ["opid" => $userid, "extraop" => 1]]);
		} else {
			$datausr = $jakdb->select($table, "*", ["id" => $userid]);
		}
	} else {
		$datausr = $jakdb->select($table, "*", ["LIMIT" => $limit]);
	}
	
    return $datausr;
}

// Check if user exist and it is possible to delete ## (config.php)
function jak_user_exist_deletable($id) {
	$useridarray = explode(',', JAK_SUPERADMIN);
	// check if userid is protected in the config.php
	if (in_array($id, $useridarray)) {
	    return false;
	} else {
		global $jakdb;
	    if ($jakdb->has("user", ["id" => $id])) return true;
	}
	return false;
}

// Check if row exist with id
function jak_field_not_exist_id($lsvar,$id,$table,$lsvar3)
{
		global $jakdb;
        if ($jakdb->has($table, ["AND" => ["id[!]" => $id, $lsvar3 => $lsvar]])) {
        return true;
}
}

// Get files
function jak_get_files($directory,$exempt = array('.','..','.DS_Store','.svn','js','css','img','_cache','index.html'),&$files = array()) { 
	
	if ($handle = opendir($directory)) {
		$getlang = array();
	    /* This is the correct way to loop over the directory. */
	    while (false !== ($file = readdir($handle))) {
	    if (!in_array($file, $exempt)) {
	    
	    	$getfiles[] = $file;
	    
	    }
	    }
		if (!empty($getfiles)) return $getfiles;
	    closedir($handle);
	}
}

function secondsToTime($seconds,$time) {
	$singletime = explode(",", $time);
	if (is_numeric($seconds)) {
    	$dtF = new DateTime("@0");
    	$dtT = new DateTime("@$seconds");
    	return $dtF->diff($dtT)->format('%a '.$singletime[0].', %h '.$singletime[1].', %i '.$singletime[2].' '.$singletime[4].' %s '.$singletime[3]);
    } else {
    	return '0 '.$singletime[0].', 0 '.$singletime[1].', 0 '.$singletime[2].' '.$singletime[4].' 0 '.$singletime[3];
    }
}

function update_main_operator($subs, $pack, $stripekey, $stripesecret, $currency, $amount, $paygateid, $subscribeid, $subscribed, $paidhow, $opid, $locationid) {

	global $jakdb;
	global $jakdb1;
	// Ok we have less operators therefore we remove the oldest ones.
	if ($subs['operators'] > $pack['operators']) {

		$opremove = $subs['operators'] - $pack['operators'];

		$oldops = $jakdb->select("user", "id", ["opid" => $opid, "ORDER" => ["lastactivty" => "ASC"], "LIMIT" => $opremove]);
		if (isset($oldops) && !empty($oldops)) foreach ($oldops as $o) {

			// Delete the stuff from this user
			$jakdb->delete("user", ["id" => $o]);
			$jakdb->delete("push_notification_devices", ["userid" => $o]);
			$jakdb->delete("user_stats", ["userid" => $o]);
		}

	}

	// Ok we have less department therefore we remove the newest ones.
	if ($subs['departments'] > $pack['departments']) {

		$dpremove = $subs['departments'] - $pack['departments'];

		$olddep = $jakdb->select("departments", "id", ["opid" => $opid, "ORDER" => ["id" => "DESC"], "LIMIT" => $dpremove]);
		if (isset($olddep) && !empty($olddep)) foreach ($olddep as $d) {

			// Delete the stuff from this user
			$jakdb->delete("departments", ["id" => $d]);
		}

	}

	// Last but not least if we had a subscription we need to cancel it
	if ($subs["subscribed"] && $subs["subscribeid"]) {

		// Set your secret key: remember to change this to your live secret key in production
		require_once(APP_PATH.JAK_OPERATOR_LOC.'/payment/stripe/Stripe.php');
						 
		$stripe = array(
			'secret_key'      => $stripesecret,
			'publishable_key' => $stripekey
		);
															 
		\Stripe\Stripe::setApiKey($stripesecret);

		$subscription = \Stripe\Subscription::retrieve($subs["subscribeid"]);
		$subscription->cancel();

		// Change the subscription to zero
	    $jakdb->update("subscriptions", ["subscribeid" => 0, "subscribed" => 0], ["id" => $subs['id']]);
	    $jakdb1->update("subscriptions", ["subscribeid" => 0, "subscribed" => 0], ["AND" => ["locationid" => $locationid, "userid" => $opid]]);

		// subscription canceled succesfully
		$_SESSION["infomsg"] = $jkl['i44'];

	}

	$paidunix = strtotime("+".$pack["validfor"]." days");
	// get the nice time
	$paidtill = date('Y-m-d H:i:s', $paidunix);

	// Ok, we have removed the old stuff and now we update the user subscription table
	$jakdb->update("subscriptions", ["packageid" => $pack["id"], "operators" => $pack["operators"], "departments" => $pack["departments"], "files" => $pack["files"], "activechats" => $pack["activechats"], "chathistory" => $pack["chathistory"], "islc3" => $pack["islc3"], "ishd3" => $pack["ishd3"], "validfor" => $pack["validfor"], "paygateid" => $paygateid, "subscribeid" => $subscribeid, "subscribed" => $subscribed, "amount" => $amount, "currency" => $currency, "paidhow" => $paidhow, "paidwhen" => $jakdb->raw("NOW()"), "paidtill" => $paidtill, "trial" => 0], ["opid" => $opid]);

	return true;

}
?>