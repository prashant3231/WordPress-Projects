<?php

/*===============================================*\
|| ############################################# ||
|| # JAKWEB.CH / Version 2.4                   # ||
|| # ----------------------------------------- # ||
|| # Copyright 2019 JAKWEB All Rights Reserved # ||
|| ############################################# ||
\*===============================================*/

// Check if the file is accessed only via index.php if not stop the script from running
if (!defined('JAK_ADMIN_PREVENT_ACCESS')) die('You cannot access this file directly.');

// Change for 1.0.3
use JAKWEB\JAKsql;

// Already logged in, don't load it again
if (JAK_USERID) jak_redirect(BASE_URL_ADMIN);

// Login IN
if (!empty($page1) && !empty($page2) && is_numeric($page1) && is_numeric($page2)) {

    if ($jakdb->has("user_confirm", ["confirmcode" => $page2])) {

        // Ok, already activated
        $_SESSION["infomsg"] = $jkl['i8'];
        jak_redirect(BASE_URL_ADMIN);

    } else {

        // Database connection to the main site
        $jakdb1 = new JAKsql([
            // required
            'database_type' => JAKDB_MAIN_DBTYPE,
            'database_name' => JAKDB_MAIN_NAME,
            'server' => JAKDB_MAIN_HOST,
            'username' => JAKDB_MAIN_USER,
            'password' => JAKDB_MAIN_PASS,
            'charset' => 'utf8',
            'port' => JAKDB_MAIN_PORT,
            'prefix' => JAKDB_MAIN_PREFIX,
         
            // [optional] driver_option for connection, read more from http://www.php.net/manual/en/pdo.setattribute.php
            'option' => [PDO::ATTR_CASE => PDO::CASE_NATURAL]
            ]);

        // Now get the user information
        $activeuser = $jakdb1->get("users", ["id", "email", "username", "password"], ["AND" => ["id" => $page1, "active" => 0, "confirm" => $page2]]);

        // We get the settings for the payment
        $sett = array();
        $settings = $jakdb1->select("settings", ["varname", "used_value"]);
        foreach ($settings as $v) {
            $sett[$v["varname"]] = $v["used_value"]; 
        }

        if (isset($activeuser) && !empty($activeuser)) {

            $jakdb->insert("user", [ 
                "password" => $activeuser["password"],
                "username" => $activeuser["username"],
                "name" => $activeuser["username"],
                "email" => $activeuser["email"],
                "access" => 1,
                "permissions" => "leads,leads_all,off_all,statistic,statistic_all,files,proactive,usrmanage,responses,departments,settings,answers,widget,blacklist",
                "time" => $jakdb->raw("NOW()")]);

            $lastid = $jakdb->id();
        
            if ($lastid) {

                $newuserpath = APP_PATH.JAK_FILES_DIRECTORY.'/'.$lastid;
                
                if (!is_dir($newuserpath)) {
                    mkdir($newuserpath, 0755);
                    copy(APP_PATH.JAK_FILES_DIRECTORY."/index.html", $newuserpath."/index.html");
                }

                // Create the settings for the operator
                $jakdb->insert("op_settings", ["opid" => $lastid, "title" => "Live Chat", "email" => $activeuser["email"], "lang" => JAK_LANG, "dateformat" => "d.m.Y ", "timeformat" => "g:i a", "newclient" => "files/package/standard/sound/birds", "newmsg" => "sound/new_message3", "clientsound" => "sound/hello", "soundalert" => "files/package/standard/sound/owl", "emailprotocol" => 0, "created" => $jakdb->raw("NOW()")]);

                // Insert the chat widget
                $jakdb->insert("chatwidget", ["opid" => $lastid, "title" => "Live Chat", "lang" => JAK_LANG, "widget" => 1, "hideoff" => 0, "buttonimg" => "globe_on.png", "slideimg" => "chatnow_on.png", "floatpopup" => 1, "floatcss" => "bottom:20px;right:20px;", "floatcsschat" => "bottom:20px;right:20px;", "engagecss" => "left:50%;top:50%;transform: translate(-50%, -50%);", "template" => "modern", "theme_colour" => "standard", "body_colour" => "#ffffff", "h_colour" => "#494949", "c_colour" => "#494949", "time_colour" => "#999999", "link_colour" => "#007ff5", "sidebar_colour" => "#857d7d", "h_font" => "Open+Sans", "c_font" => "Open+Sans", "created" => $jakdb->raw("NOW()")]);

                // Insert the department
                $jakdb->insert("departments", ["opid" => $lastid, "title" => "My First Department", "description" => "Edit this department to your needs...", "active" => 1, "dorder" => 1, "time" => $jakdb->raw("NOW()")]);

                $jakdb->insert("answers", [["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Enters Chat", "message" => "%operator% enters the chat.", "fireup" => 15, "msgtype" => 2, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Expired", "message" => "This session has expired!", "fireup" => 15, "msgtype" => 4, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Ended", "message" => "%client% has ended the conversation", "fireup" => 15, "msgtype" => 3, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Welcome", "message" => "Welcome %client%, a representative will be with you shortly.", "fireup" => 15, "msgtype" => 5, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Leave", "message" => "has left the conversation.", "fireup" => 15, "msgtype" => 6, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Start Page", "message" => "Please insert your name to begin, a representative will be with you shortly.", "fireup" => 15, "msgtype" => 7, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Contact Page", "message" => "None of our representatives are available right now, although you are welcome to leave a message!", "fireup" => 15, "msgtype" => 8, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Feedback Page", "message" => "We would appreciate your feedback to improve our service.", "fireup" => 15, "msgtype" => 9, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Quickstart Page", "message" => "Please type a message and hit enter to start the conversation.", "fireup" => 15, "msgtype" => 10, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "WhatsApp Online", "message" => "Please click on a operator below to connect via WhatsApp and get help immediately.", "fireup" => 15, "msgtype" => 26, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "WhatsApp Offline", "message" => "We are currently offline however please check below for available operators in WhatsApp, we try to help you as soon as possible.", "fireup" => 15, "msgtype" => 27, "created" => $jakdb->raw("NOW()")]]);

                // Get the trial in the correct format
                $trialunix = strtotime("+".$sett["trialdays"]." day");
                $trialtime = $paidtill = date('Y-m-d H:i:s', $trialunix);

                // Insert into the local subscription table
                $jakdb->insert("subscriptions", ["opid" => $lastid, "validfor" => $sett["trialdays"], "paidwhen" => $jakdb->raw("NOW()"), "paidtill" => $trialtime, "registered" => $jakdb->raw("NOW()")]);

                // Now let's check if we have a standard package after sign up.
                if ($jakdb1->has("packages", ["AND" => ["locationid" => JAK_MAIN_LOC, "supackage" => 1, "active" => 1]])) {

                    // First we need the old subscriptions
                    $subs = $jakdb->get("subscriptions", ["id", "packageid", "operators", "departments", "files", "chathistory", "paygateid", "subscribeid", "subscribed"], ["opid" => $lastid]);

                    // Get the package
                    $pack = $jakdb1->get("packages", ["id", "title", "amount", "currency", "operators", "departments", "files", "copyfree", "activechats", "chathistory", "islc3", "ishd3", "validfor"], ["AND" => ["locationid" => JAK_MAIN_LOC, "supackage" => 1, "active" => 1]]);

                    // Paid unix
                    $paidunix = strtotime("+".$pack["validfor"]." days");
                    // get the nice time
                    $paidtill = date('Y-m-d H:i:s', $paidunix);
                    // Price
                    $couponprice = $pack['amount'];
                    // zero
                    $subscribed = $paygateid = $subscribeid = 0;

                    // We collect the customer id from stripe
                    $paygateid = $subs["paygateid"];
                    $subscribeid = $subs["subscribeid"];

                    // Nasty stuff starts
                    if (isset($subs) && isset($pack)) {

                        // Update the main operator subscription
                        update_main_operator($subs, $pack, $sett["stripepublic"], $sett["stripesecret"], $sett["currency"], $couponprice, $paygateid, $subscribeid, $subscribed, "Standard User Plan", $lastid, JAK_MAIN_LOC);

                    }

                    // finally update the main database
                    $jakdb->update("users", ["paidtill" => $paidtill], ["AND" => ["opid" => $lastid, "locationid" => JAK_MAIN_LOC]]);

                    // Set the correct trialtime because it is none
                    $trialtime = "1980-05-06 00:00:00";

                }

                // finally update the main database
                $jakdb1->update("users", [ 
                    "opid" => $lastid,
                    "trial" => $trialtime,
                    "paidtill" => $paidtill,
                    "welcomemsg" => 1,
                    "active" => 1,
                    "confirm" => 0], ["id" => $activeuser["id"]]);

                // So we do not need to connect to main database all the time the user clicks the link
               $jakdb->insert("user_confirm", ["opid" => $lastid, "confirmcode" => $page2, "created" => $jakdb->raw("NOW()")]);

            }

            // Something went wrong
            $_SESSION["successmsg"] = $jkl['i9'];
            jak_redirect(BASE_URL_ADMIN);

        } else {
            // Something went wrong
            $_SESSION["errormsg"] = $jkl['i3'];
            jak_redirect(BASE_URL_ADMIN);
        }
	}
}

// Something went wrong
$_SESSION["errormsg"] = $jkl['i3'];
jak_redirect(BASE_URL_ADMIN);
?>