<?php

/*===============================================*\
|| ############################################# ||
|| # JAKWEB.CH / Version 2.4                   # ||
|| # ----------------------------------------- # ||
|| # Copyright 2019 JAKWEB All Rights Reserved # ||
|| ############################################# ||
\*===============================================*/

// Do not go any further if install folder still exists
if (is_dir('../install')) die('Please delete or rename install folder.');

// The DB connections data
require_once '../include/db.php';

// Get the real stuff
require_once '../config.php';

define('BASE_URL_ADMIN', BASE_URL);
define('BASE_URL_ORIG', str_replace('/'.JAK_OPERATOR_LOC.'/', '/', BASE_URL));
define('BASE_PATH_ORIG', str_replace('/'.JAK_OPERATOR_LOC.'', '/', _APP_MAIN_DIR));

// Include some functions for the ADMIN Area
include_once 'include/admin.function.php';
include_once '../class/class.paginator.php';

// Set the last activity and session into cookies
setcookie('lastactivity', time(), time() + 60 * 60 * 24 * 10, JAK_COOKIE_PATH);
setcookie('usrsession', session_id(), time() + 60 * 60 * 24 * 10, JAK_COOKIE_PATH);

// Check if user is logged in
$jakuserlogin = new JAK_userlogin();
$jakuserrow = $jakuserlogin->jakChecklogged();
$jakuser = new JAK_user($jakuserrow);
if ($jakuser) {
	define('JAK_USERID', $jakuser->getVar("id"));
} else {
	define('JAK_USERID', false);
}

// Now we get the siblings sorted
$opcacheid = JAK_USERID;
$mainop = false;

// Update last activity from this user
if (JAK_USERID) {
	
	// Check if a sibling has logged in
	if ($jakuser->getVar("opid") != 0) {
	    $opcacheid = $jakuser->getVar("opid");
	} else {
		$mainop = true;
	}

	// Update the last activity timer
	$jakuserlogin->jakUpdatelastactivity(JAK_USERID);

	// Operator has logged in but no cache file is available...
    $cacheopidadmin = APP_PATH.JAK_CACHE_DIRECTORY.'/opcache'.$opcacheid.'.php';

    // Get the operator settings
    if (!file_exists($cacheopidadmin)) {

        $opsett = "<?php\n";

        // Get the general settings out the database
        $reswidg = $jakdb->get("chatwidget", "*", ["opid" => $opcacheid]);
        if (isset($reswidg) && !empty($reswidg)) {

            $opsett .= "\$jakwidget = array();\n";

            $opsett .= "\$jakwidget['id'] = ".$reswidg['id'].";\n\$jakwidget['opid'] = ".$reswidg['opid'].";\n\$jakwidget['title'] = '".addslashes($reswidg['title'])."';\n\$jakwidget['whatsapp_message'] = '".addslashes($reswidg['whatsapp_message'])."';\n\$jakwidget['depid'] = ".$reswidg['depid'].";\n\$jakwidget['singleopid'] = ".$reswidg['singleopid'].";\n\$jakwidget['lang'] = '".stripcslashes($reswidg['lang'])."';\n\$jakwidget['widget'] = ".$reswidg['widget'].";\n\$jakwidget['hideoff'] = ".$reswidg['hideoff'].";\n\$jakwidget['buttonimg'] = '".stripcslashes($reswidg['buttonimg'])."';\n\$jakwidget['mobilebuttonimg'] = '".stripcslashes($reswidg['mobilebuttonimg'])."';\n\$jakwidget['slideimg'] = '".stripcslashes($reswidg['slideimg'])."';\n\$jakwidget['floatpopup'] = ".$reswidg['floatpopup'].";\n\$jakwidget['chat_direct'] = ".$reswidg['chat_direct'].";\n\$jakwidget['whatsapp_online'] = ".$reswidg['whatsapp_online'].";\n\$jakwidget['whatsapp_offline'] = ".$reswidg['whatsapp_offline'].";\n\$jakwidget['client_email'] = ".$reswidg['client_email'].";\n\$jakwidget['client_semail'] = ".$reswidg['client_semail'].";\n\$jakwidget['client_phone'] = ".$reswidg['client_phone'].";\n\$jakwidget['client_sphone'] = ".$reswidg['client_sphone'].";\n\$jakwidget['client_question'] = ".$reswidg['client_question'].";\n\$jakwidget['client_squestion'] = ".$reswidg['client_squestion'].";\n\$jakwidget['show_avatar'] = ".$reswidg['show_avatar'].";\n\$jakwidget['floatcss'] = '".stripcslashes($reswidg['floatcss'])."';\n\$jakwidget['floatcsschat'] = '".stripcslashes($reswidg['floatcsschat'])."';\n\$jakwidget['btn_animation'] = '".stripcslashes($reswidg['btn_animation'])."';\n\$jakwidget['chat_animation'] = '".stripcslashes($reswidg['chat_animation'])."';\n\$jakwidget['engage_animation'] = '".stripcslashes($reswidg['engage_animation'])."';\n\$jakwidget['engagecss'] = '".stripcslashes($reswidg['engagecss'])."';\n\$jakwidget['sucolor'] = '".stripcslashes($reswidg['sucolor'])."';\n\$jakwidget['sutcolor'] = '".stripcslashes($reswidg['sutcolor'])."';\n\$jakwidget['template'] = '".stripcslashes($reswidg['template'])."';\n\$jakwidget['theme_colour'] = '".stripcslashes($reswidg['theme_colour'])."';\n\$jakwidget['body_colour'] = '".$reswidg['body_colour']."';\n\$jakwidget['h_colour'] = '".$reswidg['h_colour']."';\n\$jakwidget['c_colour'] = '".$reswidg['c_colour']."';\n\$jakwidget['time_colour'] = '".$reswidg['time_colour']."';\n\$jakwidget['link_colour'] = '".$reswidg['link_colour']."';\n\$jakwidget['sidebar_colour'] = '".$reswidg['sidebar_colour']."';\n\$jakwidget['t_font'] = '".stripcslashes($reswidg['t_font'])."';\n\$jakwidget['h_font'] = '".stripcslashes($reswidg['h_font'])."';\n\$jakwidget['c_font'] = '".stripcslashes($reswidg['c_font'])."';\n\$jakwidget['whitelist'] = '".stripcslashes($reswidg['widget_whitelist'])."';\n";
        }

        // Get the general settings out the database
        $dataops = $jakdb->get("op_settings", "*", ["opid" => $opcacheid]);
        if (isset($dataops) && !empty($dataops)) {

            $opsett .= "\n\$jakopsett = array();\n";

            $opsett .= "\$jakopsett['opid'] = ".$dataops['opid'].";\n\$jakopsett['title'] = '".addslashes($dataops['title'])."';\n\$jakopsett['email'] = '".stripcslashes($dataops['email'])."';\n\$jakopsett['lang'] = '".stripcslashes($dataops['lang'])."';\n\$jakopsett['dateformat'] = '".$dataops['dateformat']."';\n\$jakopsett['timeformat'] = '".$dataops['timeformat']."';\n\$jakopsett['newclient'] = '".stripcslashes($dataops['newclient'])."';\n\$jakopsett['newmsg'] = '".stripcslashes($dataops['newmsg'])."';\n\$jakopsett['showalert'] = ".$dataops['showalert'].";\n\$jakopsett['sendtrans'] = ".$dataops['sendtrans'].";\n\$jakopsett['feedback'] = ".$dataops['feedback'].";\n\$jakopsett['ratings'] = ".$dataops['ratings'].";\n\$jakopsett['holiday_mode'] = ".$dataops['holiday_mode'].";\n\$jakopsett['contactredi'] = ".$dataops['contactredi'].";\n\$jakopsett['contacttime'] = ".$dataops['contacttime'].";\n\$jakopsett['contacturl'] = '".stripcslashes($dataops['contacturl'])."';\n\$jakopsett['dsgvo'] = '".stripcslashes($dataops['dsgvo'])."';\n\$jakopsett['timezone'] = '".stripcslashes($dataops['timezone'])."';\n\$jakopsett['emailprotocol'] = ".$dataops['emailprotocol'].";\n\$jakopsett['smtphost'] = '".stripcslashes($dataops['smtphost'])."';\n\$jakopsett['smtpport'] = ".$dataops['smtpport'].";\n\$jakopsett['smtpalive'] = ".$dataops['smtpalive'].";\n\$jakopsett['smtpauth'] = ".$dataops['smtpauth'].";\n\$jakopsett['smtpprefix'] = '".stripcslashes($dataops['smtpprefix'])."';\n\$jakopsett['smtpuser'] = '".stripcslashes($dataops['smtpuser'])."';\n\$jakopsett['smtppass'] = '".stripcslashes($dataops['smtppass'])."';\n\$jakopsett['clientsound'] = '".stripcslashes($dataops['clientsound'])."';\n\$jakopsett['soundalert'] = '".stripcslashes($dataops['soundalert'])."';\n\$jakopsett['created'] = '".$dataops['created']."';\n";
        }

        // Get the subscription out the database
        $opsett .= "\n\$jakosub = array();\n";
        $dataosub = $jakdb->get("subscriptions", "*", ["opid" => $reswidg['opid']]);
        if (isset($dataosub) && !empty($dataosub)) {

            $opsett .= "\$jakosub['id'] = ".$dataosub['id'].";\n\$jakosub['packageid'] = ".$dataosub['packageid'].";\n\$jakosub['opid'] = ".$dataosub['opid'].";\n\$jakosub['operators'] = ".$dataosub['operators'].";\n\$jakosub['extraoperators'] = ".$dataosub['extraoperators'].";\n\$jakosub['departments'] = ".$dataosub['departments'].";\n\$jakosub['files'] = ".$dataosub['files'].";\n\$jakosub['copyfree'] = ".$dataosub['copyfree'].";\n\$jakosub['activechats'] = ".$dataosub['activechats'].";\n\$jakosub['validfor'] = ".$dataosub['validfor'].";\n\$jakosub['trial'] = ".$dataosub['trial'].";\n\$jakosub['active'] = ".$dataosub['active'].";\n\$jakosub['paidtill'] = '".$dataosub['paidtill']."';\n";
        }

        // empty vars
        $answergrid = $responsegrid = $autoproactivegrid = array();

        $opsett .= "\n";

        // Get the general settings out the database
        $datafiles = $jakdb->select("files",["id", "path", "name"], ["opid" => $opcacheid]);
        if (isset($datafiles) && !empty($datafiles)) foreach ($datafiles as $rowf) {
            $filesgrid[] = $rowf;
        }
                
        // Get the answers out the database
        $dataansw = $jakdb->select("answers", ["id", "opid", "department", "lang", "message", "fireup", "msgtype"], ["opid" => $opcacheid]);
        if (isset($dataansw) && !empty($dataansw)) foreach ($dataansw as $rowa) {
            $answergrid[] = $rowa;
        }

        // Get the url black list
        $databl = $jakdb->select("urlblacklist", "path", ["opid" => $opcacheid]);
        if (isset($databl) && !empty($databl)) foreach ($databl as $rowb) {
            $blacklistgrid[] = $rowb;
        }
                
        // Get the responses settings out the database
        $datares = $jakdb->select("responses", ["id", "opid", "department", "title", "message"], ["opid" => $opcacheid]);
        if (isset($datares) && !empty($datares)) foreach ($datares as $rowr) {
            $responsegrid[] = $rowr;
        }

        // Get the chat bot out of the database
        $databot = $jakdb->select("bot_question", ["id", "opid", "depid", "lang", "question", "answer"], ["AND" => ["active" => 1, "opid" => $opcacheid]]);
        if (isset($databot) && !empty($databot)) foreach ($databot as $rowba) {
            $botgrid[] = $rowba;
        }

        // Get the departments
        $datadep = $jakdb->select("departments", ["id", "title", "email", "faq_url"], ["AND" => ["opid" => $opcacheid, "active" => 1], "ORDER" => ["dorder" => "ASC"]]);
        if (isset($datadep) && !empty($datadep)) foreach ($datadep as $rowd) {
            $departmentgrid[] = $rowd;
        }
                
        // Get the auto proactive out the database
        $dataproact = $jakdb->select("autoproactive", ["opid", "path", "title", "imgpath", "message", "btn_confirm", "btn_cancel", "showalert", "timeonsite", "visitedsites"], ["opid" => $opcacheid]);
        if (isset($dataproact) && !empty($dataproact)) foreach ($dataproact as $rowap) {
           $autoproactivegrid[] = $rowap;
        }
                
        if (!empty($answergrid)) $opsett .= "\$answergserialize = '".base64_encode(gzcompress(serialize($answergrid)))."';\n\n\$LC_ANSWERS = unserialize(gzuncompress(base64_decode(\$answergserialize)));\n";

        if (!empty($blacklistgrid)) $opsett .= "\$blacklistserialize = '".base64_encode(gzcompress(serialize($blacklistgrid)))."';\n\n\$LC_BLACKLIST = unserialize(gzuncompress(base64_decode(\$blacklistserialize)));\n";
                
        if (!empty($responsegrid)) $opsett .= "\$responsegserialize = '".base64_encode(gzcompress(serialize($responsegrid)))."';\n\n\$LC_RESPONSES = unserialize(gzuncompress(base64_decode(\$responsegserialize)));\n";

        if (!empty($botgrid)) $opsett .= "\$botserialize = '".base64_encode(gzcompress(serialize($botgrid)))."';\n\n\$LC_BOT_ANSWER = unserialize(gzuncompress(base64_decode(\$botserialize)));\n";

        if (!empty($filesgrid)) $opsett .= "\$filesgserialize = '".base64_encode(gzcompress(serialize($filesgrid)))."';\n\n\$LC_FILES = unserialize(gzuncompress(base64_decode(\$filesgserialize)));\n";

        if (!empty($departmentgrid)) $opsett .= "\$departmentgserialize = '".base64_encode(gzcompress(serialize($departmentgrid)))."';\n\n\$LC_DEPARTMENTS = unserialize(gzuncompress(base64_decode(\$departmentgserialize)));\n";

        if (!empty($autoproactivegrid)) $opsett .= "\$autoproactiveserialize = '".base64_encode(gzcompress(serialize($autoproactivegrid)))."';\n\n\$LC_PROACTIVE = unserialize(gzuncompress(base64_decode(\$autoproactiveserialize)));\n";

        // Finally close the cache file
        $opsett .= "?>";

        JAK_base::jakWriteinCache($cacheopidadmin, $opsett, '');
    }

    // Now include the created operator cache file
    include_once $cacheopidadmin;

    // Set the widget id into a session
    $_SESSION['widgetid'] = $jakwidget['opid'];

}

// Define the MAIN_OP
define('JAK_MAIN_OP', $mainop);
?>