<?php

/*===============================================*\
|| ############################################# ||
|| # JAKWEB.CH / Version 2.0                   # ||
|| # ----------------------------------------- # ||
|| # Copyright 2018 JAKWEB All Rights Reserved # ||
|| ############################################# ||
\*===============================================*/

// Check if the file is accessed only via index.php if not stop the script from running
if (!defined('JAK_ADMIN_PREVENT_ACCESS')) die('You cannot access this file directly.');

// Change for 1.0.3
use JAKWEB\JAKsql;

$subs = $jakdb->get("subscriptions", ["id", "subscribeid", "paidtill"], ["AND" => ["opid" => JAK_USERID, "subscribed" => 1]]);

// Last but not least if we had a subscription we need to cancel it
if ($subs["subscribeid"]) {

    // Set your secret key: remember to change this to your live secret key in production
    require_once('payment/stripe/Stripe.php');

    // Database connection to the main site
    $jakdb1 = new JAKsql([
        // required
        'database_type' => JAKDB_MAIN_DBTYPE,
        'database_name' => JAKDB_MAIN_NAME,
        'server' => JAKDB_MAIN_HOST,
        'username' => JAKDB_MAIN_USER,
        'password' => JAKDB_MAIN_PASS,
        'charset' => 'utf8',
        'port' => JAKDB_MAIN_PORT,
        'prefix' => JAKDB_MAIN_PREFIX,
                             
        // [optional] driver_option for connection, read more from http://www.php.net/manual/en/pdo.setattribute.php
        'option' => [PDO::ATTR_CASE => PDO::CASE_NATURAL]
    ]);

    // We get the settings for the payment
    $sett = array();
    $settings = $jakdb1->select("settings", ["varname", "used_value"]);
    foreach ($settings as $v) {
        $sett[$v["varname"]] = $v["used_value"]; 
    }
                         
    $stripe = array(
        'secret_key'      => $sett["stripesecret"],
        'publishable_key' => $sett["stripepublic"]
    );
                                                             
    \Stripe\Stripe::setApiKey($sett["stripesecret"]);

    $subscription = \Stripe\Subscription::retrieve($subs["subscribeid"]);
    $subscription->cancel();

    $date1 = new DateTime($subs["paidtill"]);
    $date2 = new DateTime();

    // Change the subscription to zero
    $jakdb->update("subscriptions", ["subscribeid" => 0, "subscribed" => 0], ["id" => $subs['id']]);
    $jakdb1->update("subscriptions", ["subscribeid" => 0, "subscribed" => 0], ["AND" => ["locationid" => JAK_MAIN_LOC, "userid" => JAK_USERID]]);

    $validtill = $date2->diff($date1)->format("%a");

    // subscription canceled succesfully
    $_SESSION["infomsg"] = sprintf($jkl['i45'], $validtill);

}
        
jak_redirect(BASE_URL);

?>