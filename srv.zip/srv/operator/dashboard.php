<?php

/*===============================================*\
|| ############################################# ||
|| # JAKWEB.CH / Version 2.4.3                 # ||
|| # ----------------------------------------- # ||
|| # Copyright 2019 JAKWEB All Rights Reserved # ||
|| ############################################# ||
\*===============================================*/

// Check if the file is accessed only via index.php if not stop the script from running
if (!defined('JAK_ADMIN_PREVENT_ACCESS')) die('You cannot access this file directly.');

// Reset
$opmain = '';
$opadd = 0;

// Change for 1.0.3
use JAKWEB\JAKsql;

// Now if we have multi site we have fully automated process
if (!empty(JAKDB_MAIN_NAME) && JAK_MAIN_LOC && JAK_MAIN_OP) {
	
	// Database connection to the main site
	$jakdb1 = new JAKsql([
		// required
		'database_type' => JAKDB_MAIN_DBTYPE,
		'database_name' => JAKDB_MAIN_NAME,
		'server' => JAKDB_MAIN_HOST,
		'username' => JAKDB_MAIN_USER,
		'password' => JAKDB_MAIN_PASS,
		'charset' => 'utf8',
		'port' => JAKDB_MAIN_PORT,
		'prefix' => JAKDB_MAIN_PREFIX,
			         
		// [optional] driver_option for connection, read more from http://www.php.net/manual/en/pdo.setattribute.php
		'option' => [PDO::ATTR_CASE => PDO::CASE_NATURAL]
		]);

	// We get the user data from the main table
	$opmain = $jakdb1->get("users", ["id", "signup", "trial", "paidtill", "active"], ["AND" => ["opid" => JAK_USERID, "locationid" => JAK_MAIN_LOC]]);

	// Now we get the packages
	$packages = $jakdb1->select("packages", ["id", "title", "description", "previmg", "amount", "currency", "operators", "departments", "files", "copyfree", "activechats", "chathistory", "islc3", "ishd3", "validfor", "multipleuse", "isfree"], ["AND" => ["locationid" => JAK_MAIN_LOC, "active" => 1], "GROUP" => "id", "ORDER" => ["lastedit" => "DESC"]]);

	// Now we get the subscriptions
	$subscriptions = $jakdb1->select("subscriptions", ["[>]packages" => ["packageid" => "id"]], ["subscriptions.id", "subscriptions.packageid", "subscriptions.amount", "subscriptions.currency", "subscriptions.paidfor", "subscriptions.paidhow", "subscriptions.subscribed", "subscriptions.paidwhen", "subscriptions.paidtill", "subscriptions.active", "subscriptions.success", "packages.title"], ["AND" => ["subscriptions.locationid" => JAK_MAIN_LOC, "subscriptions.userid" => JAK_USERID], "ORDER" => ["subscriptions.paidwhen" => "DESC"]]);

	// Check if we have some new and unread tickets.
	$count = 0;
	$count = $jakdb1->count("support_tickets", ["AND" => ["userid" => $opmain["id"], "readtime" => 0]]);

	// We get the settings for the payment
    $sett = array();
    $settings = $jakdb1->select("settings", ["varname", "used_value"]);
    foreach ($settings as $v) {
        $sett[$v["varname"]] = $v["used_value"]; 
    }

	if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['check'])) {

		// Current time
		$timenow = time();

		if ($_POST['check'] == "coupon") {

			$coupon = filter_var($_POST['coupon'], FILTER_SANITIZE_STRING);

			if (isset($_POST['pid']) && is_numeric($_POST['pid']) && isset($coupon) && !empty($coupon) && $jakdb1->has("coupons", ["AND" => ["locationid" => JAK_MAIN_LOC, "code" => $coupon, "active" => 1]])) {

				// We get the user data from the main table
				$cd = $jakdb1->get("coupons", ["id", "discount", "freepackageid", "used", "total", "datestart", "dateend", "products"], ["AND" => ["locationid" => JAK_MAIN_LOC, "code" => $coupon, "active" => 1]]);

				// Nice, we have one let's go through and check if the coupon code is still available
				if ($cd['used'] < $cd['total'] && ($cd['datestart'] == 0 && $cd['dateend'] == 0 || $cd['datestart'] < $timenow && $cd['dateend'] > $timenow)) {

					// Ok, but is it also for the right product?
					if ($cd['products'] == 0 || in_array($_POST['pid'], explode(",", $cd['products']))) {

						// We have one great for the client bad for us. ;) The last check do we have a freepackageid or a discount.
						if ($cd['freepackageid'] != 0 && $cd['freepackageid'] == $_POST['pid'] && $jakdb1->has("packages", "id", ["AND" => ["id" => $cd['freepackageid'], "islc3" => 0, "ishd3" => 0]])) {

							// We are on checkout
							if (isset($_POST['checkout']) && $_POST['checkout'] == "true") {

								// We have a free packageid and we go for it.

								// First we need the old subscriptions
								$subs = $jakdb->get("subscriptions", ["id", "packageid", "operators", "departments", "files", "chathistory", "paygateid", "subscribeid", "subscribed"], ["opid" => JAK_USERID]);

								// Then we need the new subscription
								$pack = $jakdb1->get("packages", ["id", "title", "amount", "currency", "operators", "departments", "files", "copyfree", "activechats", "validfor", "chathistory"], ["AND" => ["id" => $cd['freepackageid'], "active" => 1]]);

								// Nasty stuff starts
								if (isset($subs) && isset($pack)) {

									// Run the complicated stuff
									update_main_operator($subs, $pack, $sett["stripepublic"], $sett["stripesecret"], $sett["currency"], 0, 0, 0, 0, "Free Package - Coupon", JAK_USERID, JAK_MAIN_LOC);

									$paidunix = strtotime("+".$pack["validfor"]." days");
									// get the nice time
									$paidtill = date('Y-m-d H:i:s', $paidunix);

									// We insert the subscription into the main table for that user.
									$jakdb1->insert("subscriptions", ["packageid" => $pack["id"],
										"locationid" => JAK_MAIN_LOC,
										"userid" => JAK_USERID,
										"amount" => 0,
										"currency" => $sett["currency"],
										"paidfor" => $pack["title"],
										"paidhow" => "Free Package - Coupon",
										"paidwhen" => $jakdb->raw("NOW()"),
										"paidtill" => $paidtill,
										"active" => 1,
										"success" => 1]);

									// finally update the main database
									$jakdb1->update("users", ["trial" => "1980-05-06 00:00:00",
										"paidtill" => $paidtill,
										"payreminder" => 0,
										"paythanks" => 0,
										"active" => 1,
										"confirm" => 0], ["AND" => ["opid" => JAK_USERID, "locationid" => JAK_MAIN_LOC]]);

									// Update the coupon counter
									$jakdb1->update("coupons", ["used[+]" => 1], ["id" => $cd["id"]]);

									// Now let us delete the define cache file
						            $cachedefinefile = APP_PATH.JAK_CACHE_DIRECTORY.'/opcache'.JAK_USERID.'.php';
						            if (file_exists($cachedefinefile)) {
						                unlink($cachedefinefile);
						            }

						            $_SESSION["successmsg"] = $jkl['i43'];

						            if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
										header('Cache-Control: no-cache');
										die(json_encode(array("status" => 2, "redirect" => BASE_URL)));
									} else {
										// redirect back to home
										jak_redirect(BASE_URL);
									}

								} else {

									if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
										header('Cache-Control: no-cache');
										die(json_encode(array("status" => 0, "ctext" => $jkl['i34'])));
									} else {
										// redirect back to home
										$_SESSION["errormsg"] = $jkl['i34'];
										jak_redirect(BASE_URL);
									}

								}
								
							} else {
								$pgift = $jkl['i35'];
								$disc_price = 0;
							}
						} else {

							// Calculate the discount
							$totalD = $_POST['amount'] / 100 * $cd['discount'];
							$disc_price = $_POST['amount'] - number_format(round($totalD, 1), 2, '.', '');

							if ($_POST['checkout'] === true) {
								$pgift = $disc_price;
							} else {
								$pgift = sprintf($jkl['i33'], $cd['discount'].'%');
							}
						}

						if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
							header('Cache-Control: no-cache');
							die(json_encode(array("status" => 1, "ctext" => $pgift, "newprice" => $disc_price)));
						} else {
							// redirect back to home
							$_SESSION["successmsg"] = $jkl['g14'];
							jak_redirect(BASE_URL);
						}

					}

				}

			}

			if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
				header('Cache-Control: no-cache');
				die(json_encode(array("status" => 0, "ctext" => $jkl['i34'])));
			} else {
				// redirect back to home
				$_SESSION["errormsg"] = $jkl['i34'];
				jak_redirect(BASE_URL);
			}

		}

		if ($_POST['check'] == "paymember") {

			if (isset($_POST['pid']) && is_numeric($_POST['pid']) && $jakdb1->has("packages", "id", ["AND" => ["id" => $_POST['pid'], "active" => 1]])) {

		        // Get the package
				$pack = $jakdb1->get("packages", ["id", "title", "amount", "currency", "operators", "departments", "files", "copyfree", "activechats", "chathistory", "islc3", "ishd3", "validfor", "isfree"], ["AND" => ["id" => $_POST['pid'], "active" => 1]]);

				// We get the user data from the main table
				$couponcode = $coupontitle = '';
				$createcoupon = false;
				$couponprice = $pack['amount'];
				if (isset($_POST["cval"]) && $jakdb1->has("coupons", ["AND" => ["locationid" => JAK_MAIN_LOC, "code" => $_POST["cval"], "active" => 1]])) {
					$cd = $jakdb1->get("coupons", ["id", "title", "discount", "freepackageid", "used", "total", "datestart", "dateend", "products"], ["AND" => ["locationid" => JAK_MAIN_LOC, "code" => $_POST["cval"], "active" => 1]]);

					// Nice, we have one let's go through and check if the coupon code is still available
					if ($cd['used'] < $cd['total'] && $cd['freepackageid'] == 0 && ($cd['datestart'] == 0 && $cd['dateend'] == 0 || $cd['datestart'] < $timenow && $cd['dateend'] > $timenow)) {

						// Ok, but is it also for the right product?
						if ($cd['products'] == 0 || in_array($_POST['pid'], explode(",", $cd['products']))) {

							// Calculate the discount
							$totalD = $pack['amount'] / 100 * $cd['discount'];
							$couponprice = $pack['amount'] - number_format(round($totalD, 1), 2, '.', '');

							// We create a coupon in Stripe
							$couponcode = 'cc3-coupon-'.$cd['id'];
							$createcoupon = true;
							$coupontitle = $cd['title'];

						}

					}
				}

				// First we need the old subscriptions
				$subs = $jakdb->get("subscriptions", ["id", "packageid", "operators", "departments", "files", "chathistory", "paygateid", "subscribeid", "subscribed", "paidtill"], ["opid" => JAK_USERID]);

				if (isset($_POST['paidhow']) && $_POST['paidhow'] == 'stripe' && isset($_POST['token']) && !empty($_POST['token'])) {

					require_once('payment/stripe/Stripe.php');
						 
					$stripe = array(
						'secret_key'      => $sett["stripesecret"],
						'publishable_key' => $sett["stripepublic"]
					);
										 
					\Stripe\Stripe::setApiKey($sett["stripesecret"]);

					try {

					$subscribed = $paygateid = 0;
					$planexist = "false";

					// We create the coupon for that special stuff
					if ($createcoupon) {
						try {
							$couponexist = \Stripe\Coupon::retrieve($couponcode);
						} catch (Exception $e) {
							$couponexist = false;
						}

						if (!$couponexist) {
							\Stripe\Coupon::create(array(
								"percent_off" => $cd['discount'],
								"duration" => "once",
								"id" => $couponcode)
							);
						}

					}

					if ($_POST["sub"] == "true") {

						// We subscribing
						$subscribed = 1;

						// plan name
						$planid = 'cc3-plan-'.$pack["id"];

						// Charge amount
						$stripe_amount = $pack["amount"] * 100;

						// Ok we need to figure out the intervals for charging the customer
						$intervalc = 1;
						$intervalm = "month";
						if ($pack['validfor'] == 7) {
							$intervalc = 1;
							$intervalm = "week";
						} elseif ($pack['validfor'] == 14) {
							$intervalc = 2;
							$intervalm = "week";
						} elseif ($pack['validfor'] == 30) {
							$intervalc = 1;
							$intervalm = "month";
						} elseif ($pack['validfor'] == 90) {
							$intervalc = 3;
							$intervalm = "month";
						} elseif ($pack['validfor'] == 180) {
							$intervalc = 6;
							$intervalm = "month";
						} elseif ($pack['validfor'] == 365) {
							$intervalc = 1;
							$intervalm = "year";
						}

						try {
							$planexist = \Stripe\Plan::retrieve($planid);
					    } catch (Exception $e) {
							$planexist = false;
						}

						if (!$planexist) {
							$plan = \Stripe\Plan::create(array(
							  "name" => $pack["title"],
							  "id" => $planid,
							  "interval" => $intervalm,
							  "interval_count" => $intervalc,
							  "currency" => $pack["currency"],
							  "amount" => $stripe_amount
							));
						}

						$ccu = false;
						if ($subs["paygateid"]) {

							try {
								$cu = \Stripe\Customer::retrieve($subs["paygateid"]);
						    } catch (Exception $e) {
								$cu = false;
							}

							if (!$cu) {
								$ccu = true;
							} else {
								$cu->source = $_POST['token']; // obtained with Stripe.js
								$cu->save();
							}

							// We collect the customer id from stripe
							$paygateid = $subs["paygateid"];

						} else {
							$ccu = true;
						}

						if ($ccu) {
							$customer = \Stripe\Customer::create(array(
							  "email" => $jakuser->getVar("email"),
							  'source' => $_POST['token']
							));
							// We collect the customer id from stripe
							$paygateid = $customer->id;
						}

						if ($subs["subscribed"] == 1 && !empty($subs["subscribeid"])) {

							// Up or downgrade the subscription
							$subscription = \Stripe\Subscription::retrieve($subs["subscribeid"]);
							$itemID = $subscription->items->data[0]->id;	

							if ($couponcode) {

								$items = array(
								  array(
								    "id" => $itemID,
								    "plan" => $planid,
								  ),
								  "coupon" => $couponcode
								);

							} else {

								$items = array(
								  array(
								    "id" => $itemID,
								    "plan" => $planid,
								  )
								);

							}

							// What the customer needs to pay
							$invoice = \Stripe\Invoice::upcoming(array(
							  "customer" => $subs["paygateid"],
							  "subscription" => $subs["subscribeid"],
							  "subscription_items" => $items, # Switch to new plan
							  "subscription_proration_date" => $timenow
							));

							// Calculate the proration cost:
							$cost = 0;
							$current_prorations = array();
							foreach ($invoice->lines->data as $line) {
							  if ($line->period->start == $proration_date) {
							    array_push($current_prorations, $line);
							    $cost += $line->amount;
							  }
							}
							// We only record the pice he needs to pay
							if (isset($cost)) $couponprice = number_format(round($cost, 1), 2, '.', '');

							if ($couponcode) {

								$params = array(
									"items" => array(
									    array(
									      "id" => $itemID,
									      "plan" => $planid
									    )
									  ),
							  		"coupon" => $couponcode,
							  		"proration_date" => $timenow
								);

							} else {

								$params = array(
									"items" => array(
									    array(
									      "id" => $itemID,
									      "plan" => $planid
									    )
									  ),
									"proration_date" => $timenow
								);

							}

							// Finally update the customers
							\Stripe\Subscription::update($subs["subscribeid"], $params);

							// We are moving the user, make sure it does not get deleted. Will be updated in the admin.function.php again
							$jakdb1->update("subscriptions", ["subscribeid" => 0, "subscribed" => 0, "active" => 0], ["AND" => ["locationid" => JAK_MAIN_LOC, "userid" => JAK_USERID, "subscribeid" => $subs["subscribeid"]]]);
							$subs["subscribed"] = 0;

							$subscribeid = $subs["subscribeid"];

						} else {

							if ($couponcode) {

								$params = array(
									"customer" => $paygateid,
							  		"items" => array(
									    array(
									      "plan" => $planid
									    )
									  ),
							  		"coupon" => $couponcode
								);

							} else {

								$params = array(
									"customer" => $paygateid,
							  		"items" => array(
									    array(
									      "plan" => $planid
									    )
									  )
								);

							}

							// Create new subscription
							$ssc = \Stripe\Subscription::create($params);

							// Get the subscription ID
							$subscribeid = $ssc->id;
							
						}

					} else {

						// Charge amount
						$stripe_amount = $couponprice * 100;

						$charge = \Stripe\Charge::create(array(
							"amount" => $stripe_amount, // amount in cents, again
							"currency" => $sett["currency"],
							"source" => $_POST['token'],
							"description" => $jakuser->getVar("email"))
						);

					}

					// Create the unix time stamp from the package
					$paidunix = strtotime("+".$pack["validfor"]." days");

					// Since 2.3.1 we will calculate the already paid days and add it when in the same package
	                if ($subs["packageid"] == $pack["id"]) {
	                    $paidtillold = strtotime($subs["paidtill"]);
	                    if ($paidtillold > $timenow) {

	                        $diffpaid = $paidtillold - $timenow;
	                        $paidunix = $paidunix + $diffpaid;

	                    }
	                }

					// get the nice time
					$paidtill = date('Y-m-d H:i:s', $paidunix);

					// We have an advanced payment
	                if ($pack["islc3"] || $pack["ishd3"]) {

	                	// 1 stands for LC3
	                	$islc3hd3 = 1;
	                	if ($pack["ishd3"]) $islc3hd3 = 2;

	                	if ($jakdb1->has("advaccess", ["AND" => ["userid" => $opmain["id"], "opid" => JAK_USERID]])) {

	                		// Update the advanced access table
			                $jakdb1->update("advaccess", [ 
			                    "lastedit" => $jakdb->raw("NOW()"),
			                    "paidtill" => $paidtill,
			                    "lc3hd3" => $islc3hd3,
			                    "paythanks" => 1], ["AND" => ["opid" => JAK_USERID, "userid" => $opmain["id"]]]);
	                	} else {
	                		$jakdb1->insert("advaccess", ["userid" => $opmain["id"], "opid" => JAK_USERID, "lc3hd3" => $islc3hd3, "lastedit" => $jakdb->raw("NOW()"), "paythanks" => 1, "paidtill" => $paidtill, "created" => $jakdb->raw("NOW()")]);
	                	}

	                	// Ok, we have removed the old stuff and now we update the user subscription table
						$jakdb->update("subscriptions", ["packageid" => $pack["id"], "operators" => $pack["operators"], "departments" => $pack["departments"], "files" => $pack["files"], "activechats" => $pack["activechats"], "chathistory" => $pack["chathistory"], "islc3" => $pack["islc3"], "ishd3" => $pack["ishd3"], "validfor" => $pack["validfor"], "paygateid" => $paygateid, "subscribed" => $subscribed, "amount" => $couponprice, "currency" => $sett["currency"], "paidhow" => "Free Package - Coupon", "paidwhen" => $jakdb->raw("NOW()"), "paidtill" => $paidtill, "trial" => 0], ["opid" => JAK_USERID]);
					

	                	// The time for the advanced installation
	                	$paidunix = strtotime("+".$pack["validfor"]." days");

	                	$mail = new PHPMailer(); // defaults to using php "mail()"

	                	if (JAK_SMTP_MAIL) {
                            
	                        $mail->IsSMTP(); // telling the class to use SMTP
	                        $mail->Host = JAK_SMTPHOST;
	                        $mail->SMTPAuth = (JAK_SMTP_AUTH ? true : false); // enable SMTP authentication
	                        $mail->SMTPSecure = JAK_SMTP_PREFIX; // sets the prefix to the server
			         		$mail->SMTPAutoTLS = false;
	                        $mail->SMTPKeepAlive = (JAK_SMTP_ALIVE ? true : false); // SMTP connection will not close after each email sent
	                        $mail->Port = JAK_SMTPPORT; // set the SMTP port for the GMAIL server
	                        $mail->Username = JAK_SMTPUSERNAME; // SMTP account username
	                        $mail->Password = JAK_SMTPPASSWORD; // SMTP account password
	                        $mail->SetFrom(JAK_EMAIL);
	                        $mail->AddAddress(JAK_EMAIL);
	                        $mail->AddReplyTo($jakuser->getVar("email"));
	                                
	                    } else {
	                            
	                        $mail->SetFrom(JAK_EMAIL);
	                        $mail->AddAddress(JAK_EMAIL);
	                        $mail->AddReplyTo($jakuser->getVar("email"));
	                            
	                    }
						    	
						$mail->Subject = $jkl['i49'];

						$mailadv = sprintf($jkl['i50'], $jakuser->getVar("name"), $jakuser->getVar("username"), JAK_USERID, $jakuser->getVar("email"), $jakuser->getVar("password"), $paidunix, ($islc3hd3 == 1 ? 'Live Chat 3' : 'HelpDesk 3'), SIGN_UP_URL.'/process/confirmadv.php?uid='.JAK_USERID);
						$mail->MsgHTML($mailadv);
						$mail->Send();

						$stripemsg = $jkl['i51'];
						$stripestatus = 2;

	                } else {

	                	// Nasty stuff starts
						if (isset($subs) && isset($pack)) {

							// Update the main operator subscription
							update_main_operator($subs, $pack, $sett["stripepublic"], $sett["stripesecret"], $sett["currency"], $couponprice, $paygateid, $subscribeid, $subscribed, "Stripe", JAK_USERID, JAK_MAIN_LOC);

							// Thank you message can be found in the operator/lang/en.php file
							$stripemsg = $jkl['i52'];
							$stripestatus = 1;

						}

	                }

	                // Update old subscriptions to none active
                    $jakdb1->update("subscriptions", ["active" => 0], ["AND" => ["locationid" => JAK_MAIN_LOC, "userid" => JAK_USERID]]);

					// We insert the subscription into the main table for that user.
					$jakdb1->insert("subscriptions", ["packageid" => $pack["id"],
						"locationid" => JAK_MAIN_LOC,
						"userid" => JAK_USERID,
						"amount" => $couponprice,
						"currency" => $sett["currency"],
						"paidfor" => $pack["title"],
						"paidhow" => "Stripe",
						"subscribed" => $subscribed,
						"paygateid" => $paygateid,
						"subscribeid" => $subscribeid,
						"paidwhen" => $jakdb->raw("NOW()"),
						"paidtill" => $paidtill,
						"active" => 1,
						"success" => 1]);

					// finally update the main database
					$jakdb1->update("users", ["trial" => "1980-05-06 00:00:00",
						"paidtill" => $paidtill,
						"payreminder" => 0,
						"paythanks" => 1,
						"active" => 1,
						"confirm" => 0], ["AND" => ["opid" => JAK_USERID, "locationid" => JAK_MAIN_LOC]]);

					// Update the coupon counter
					if ($couponcode) $jakdb1->update("coupons", ["used[+]" => 1], ["id" => $cd["id"]]);

					// Now let us delete the define cache file
					$cachewidget = APP_PATH.JAK_CACHE_DIRECTORY.'/opcache'.JAK_USERID.'.php';
					if (file_exists($cachewidget)) {
						unlink($cachewidget);
					}

		            if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
						header('Cache-Control: no-cache');
						die(json_encode(array("status" => $stripestatus, "infomsg" => $stripemsg, "date" => JAK_base::jakTimesince($paidtill, $jakopsett['dateformat'], $jakopsett['timeformat']))));
					} else {
						// redirect back to home
						jak_redirect(BASE_URL);
					}
												
					} catch(\Stripe\Error\Card $e) {
						// Error go back to set group
						if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
							header('Cache-Control: no-cache');
							die(json_encode(array("status" => 0, "infomsg" => $jkl["i53"])));
						} else {
							// redirect back to home
							$_SESSION["errormsg"] = $jkl["i53"];
							jak_redirect(BASE_URL);
						}
											
					}

				}

				// Now we go with paypal and verify the payment
				if (isset($_POST['paidhow']) && $_POST['paidhow'] == 'paypal') {

					if ($pack["islc3"] || $pack["ishd3"]) {
						$msgpaypal = "successadv";
					} else {
						$msgpaypal = "success";
					}
								
					// Include the paypal library
					include_once ('payment/paypal.php');
											
					// Create an instance of the paypal library
					$myPaypal = new Paypal();
											
					// Specify your paypal email
					$myPaypal->addField('business', $sett["paypal"]);
											
					// Specify the currency
					$myPaypal->addField('currency_code', $sett["currency"]);
											
					// Specify the url where paypal will send the user on success/failure
					$myPaypal->addField('return', JAK_rewrite::jakParseurl('ps', $msgpaypal));
					$myPaypal->addField('cancel_return', JAK_rewrite::jakParseurl('ps', 'failure'));
											
					// Specify the url where paypal will send the IPN
					$myPaypal->addField('notify_url', BASE_URL.'payment/paypal_ipn.php');
											
					// Specify the product information
					$myPaypal->addField('item_name', JAK_TITLE);
					$myPaypal->addField('amount', $couponprice);
											
					// Specify any custom value
					$myPaypal->addField('custom', base64_encode('paymember:#:'.JAK_USERID.':#:'.$couponprice.':#:'.$_POST["cval"].':#:'.$pack["id"]));
											
					// Enable test mode if needed
					// $myPaypal->enableTestMode();
									
					$JAK_GO_PAY = $myPaypal->submitPayment($jkl["g296"]);

					if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
						header('Cache-Control: no-cache');
						die(json_encode(array("status" => 1, "content" => $JAK_GO_PAY)));
					}

				}

				// Now we go with 2Checkout and verify the payment
				if (isset($_POST['paidhow']) && $_POST['paidhow'] == 'twoco') {

					if ($pack["islc3"] || $pack["ishd3"]) {
						$msgpaypal = "successadv";
					} else {
						$msgpaypal = "success";
					}
								
					// Include the 2Checkout library
					include_once ('payment/twoco.php');

					// Create an instance of the 2Checkout library
					$my2CO = new TwoCo();
						
					// Specify your 2Checkout vendor id
					$my2CO->addField('sid', $sett['twoco']);
						
					// Specify the order information
					$my2CO->addField('cart_order_id', JAK_TITLE);
					$my2CO->addField('total', $couponprice);
						
					// Specify the url where 2Checkout will send the IPN
					$my2CO->addField('x_Receipt_Link_URL', BASE_URL.'payment/twoco_ipn.php');
					$my2CO->addField('tco_currency', $sett["currency"]);
					$my2CO->addField('custom', base64_encode('paymember:#:'.JAK_USERID.':#:'.$couponprice.':#:'.$_POST["cval"].':#:'.$pack["id"]));
						
					// Enable test mode if needed
					// $my2CO->enableTestMode();
						
					$JAK_GO_PAY = $my2CO->submitPayment($jkl["g331"]);

					if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
						header('Cache-Control: no-cache');
						die(json_encode(array("status" => 1, "content" => $JAK_GO_PAY)));
					}

				}	

				// Now we go with free access and verify the package
				if (isset($_POST['paidhow']) && $_POST['paidhow'] == 'freeaccess') {

					// Paid unix
					$paidunix = strtotime("+".$pack["validfor"]." days");
					// get the nice time
					$paidtill = date('Y-m-d H:i:s', $paidunix);

					// We collect the customer id from stripe
					$paygateid = $subs["paygateid"];
					$subscribeid = $subs["subscribeid"];

					// We have an advanced payment
	                if ($pack["islc3"] || $pack["ishd3"]) {

	                	// 1 stands for LC3
	                	$islc3hd3 = 1;
	                	if ($pack["ishd3"]) $islc3hd3 = 2;

	                	if ($jakdb1->has("advaccess", ["AND" => ["userid" => $opmain["id"], "opid" => JAK_USERID]])) {

	                		// Update the advanced access table
			                $jakdb1->update("advaccess", [ 
			                    "lastedit" => $jakdb->raw("NOW()"),
			                    "paidtill" => $paidtill,
			                    "lc3hd3" => $islc3hd3,
			                    "paythanks" => 1], ["AND" => ["opid" => JAK_USERID, "id" => $opmain["id"]]]);
	                	} else {
	                		$jakdb1->insert("advaccess", ["userid" => $opmain["id"], "opid" => JAK_USERID, "lc3hd3" => $islc3hd3, "lastedit" => $jakdb->raw("NOW()"), "paythanks" => 1, "paidtill" => $paidtill, "created" => $jakdb->raw("NOW()")]);
	                	}

	                	// Ok, we have removed the old stuff and now we update the user subscription table
						$jakdb->update("subscriptions", ["packageid" => $pack["id"], "operators" => $pack["operators"], "departments" => $pack["departments"], "files" => $pack["files"], "activechats" => $pack["activechats"], "chathistory" => $pack["chathistory"], "islc3" => $pack["islc3"], "ishd3" => $pack["ishd3"], "validfor" => $pack["validfor"], "paygateid" => $paygateid, "subscribed" => 0, "amount" => $couponprice, "currency" => $sett["currency"], "paidhow" => "Free Package - Coupon", "paidwhen" => $jakdb->raw("NOW()"), "paidtill" => $paidtill, "trial" => 0], ["opid" => JAK_USERID]);
					

	                	// The time for the advanced installation
	                	$paidunix = strtotime("+".$pack["validfor"]." days");

	                	$mail = new PHPMailer(); // defaults to using php "mail()"

	                	if (JAK_SMTP_MAIL) {
                            
	                        $mail->IsSMTP(); // telling the class to use SMTP
	                        $mail->Host = JAK_SMTPHOST;
	                        $mail->SMTPAuth = (JAK_SMTP_AUTH ? true : false); // enable SMTP authentication
	                        $mail->SMTPSecure = JAK_SMTP_PREFIX; // sets the prefix to the server
			         		$mail->SMTPAutoTLS = false;
	                        $mail->SMTPKeepAlive = (JAK_SMTP_ALIVE ? true : false); // SMTP connection will not close after each email sent
	                        $mail->Port = JAK_SMTPPORT; // set the SMTP port for the GMAIL server
	                        $mail->Username = JAK_SMTPUSERNAME; // SMTP account username
	                        $mail->Password = JAK_SMTPPASSWORD; // SMTP account password
	                        $mail->SetFrom(JAK_EMAIL);
	                        $mail->AddAddress(JAK_EMAIL);
	                        $mail->AddReplyTo($jakuser->getVar("email"));
	                                
	                    } else {
	                            
	                        $mail->SetFrom(JAK_EMAIL);
	                        $mail->AddAddress(JAK_EMAIL);
	                        $mail->AddReplyTo($jakuser->getVar("email"));
	                            
	                    }
						    	
						$mail->Subject = $jkl['i49'];

						$mailadv = sprintf($jkl['i50'], $jakuser->getVar("name"), $jakuser->getVar("username"), JAK_USERID, $jakuser->getVar("email"), $jakuser->getVar("password"), $paidunix, ($islc3hd3 == 1 ? 'Live Chat 3' : 'HelpDesk 3'), SIGN_UP_URL.'/process/confirmadv.php?uid='.JAK_USERID);
						$mail->MsgHTML($mailadv);
						$mail->Send();

						$stripemsg = $jkl['i51'];
						$stripestatus = 2;

	                } else {

	                	// Nasty stuff starts
						if (isset($subs) && isset($pack)) {

							// Update the main operator subscription
							update_main_operator($subs, $pack, $sett["stripepublic"], $sett["stripesecret"], $sett["currency"], $couponprice, $paygateid, $subscribeid, 0, "Free Plan", JAK_USERID, JAK_MAIN_LOC);

						}

	                }

	                // Update old subscriptions to none active
                    $jakdb1->update("subscriptions", ["active" => 0], ["AND" => ["locationid" => JAK_MAIN_LOC, "userid" => JAK_USERID]]);

	                // We insert the subscription into the main table for that user.
					$jakdb1->insert("subscriptions", ["packageid" => $pack["id"],
						"locationid" => JAK_MAIN_LOC,
						"userid" => JAK_USERID,
						"amount" => $couponprice,
						"currency" => $sett["currency"],
						"paidfor" => $pack["title"],
						"paidhow" => "Free Plan",
						"subscribed" => 0,
						"paygateid" => $paygateid,
						"subscribeid" => $subscribeid,
						"paidwhen" => $jakdb->raw("NOW()"),
						"paidtill" => $paidtill,
						"freeplan" => 1,
						"active" => 1,
						"success" => 1]);

					// finally update the main database
					$jakdb1->update("users", ["trial" => "1980-05-06 00:00:00",
						"paidtill" => $paidtill,
						"payreminder" => 0,
						"paythanks" => 1,
						"active" => 1,
						"confirm" => 0], ["AND" => ["opid" => JAK_USERID, "locationid" => JAK_MAIN_LOC]]);

					// Now let us delete the define cache file
					$cachewidget = APP_PATH.JAK_CACHE_DIRECTORY.'/opcache'.JAK_USERID.'.php';
					if (file_exists($cachewidget)) {
						unlink($cachewidget);

						if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
							header('Cache-Control: no-cache');
							die(json_encode(array("status" => 1, "infomsg" => $jkl['i43'], "date" => JAK_base::jakTimesince($paidtill, $jakopsett['dateformat'], $jakopsett['timeformat']))));
						} else {
							// redirect back to home
							$_SESSION["successmsg"] = $jkl["i43"];
							jak_redirect(BASE_URL);
						}
					}
				}
			}

		// Get the payment for extending an operator
		} elseif ($_POST['check'] == "newop") {

			if (isset($_POST['paidhow']) && $_POST['paidhow'] == 'stripe' && isset($_POST['token']) && !empty($_POST['token']) && isset($_POST['ops']) && is_numeric($_POST['ops'])) {

				// Calculate the price from the months
				$amount = $_POST['ops']*$sett["addops"];

				require_once('payment/stripe/Stripe.php');
						 
				$stripe = array(
					'secret_key'      => $sett["stripesecret"],
					'publishable_key' => $sett["stripepublic"]
				);

				$stripe_amount = $amount * 100;
										 
				\Stripe\Stripe::setApiKey($sett["stripesecret"]);

				try {
					$charge = \Stripe\Charge::create(array(
					"amount" => $stripe_amount, // amount in cents, again
					"currency" => $sett["currency"],
					"source" => $_POST['token'],
					"description" => $jakuser->getVar("email"))
				);

				// Ok we have a successful payment via Stripe let's add this to the extra operators
				$jakdb->update("subscriptions", ["extraoperators[+]" => $_POST['ops']], ["opid" => JAK_USERID]);

				$date = new DateTime();
				// Modify the date
				$date->modify('+1 month');
				$paiddate = $date->format('Y-m-d H:i:s');

	            // Payment details insert
	            $jakdb1->insert("subscriptions", [ 
		            "locationid" => JAK_MAIN_LOC,
		            "userid" => JAK_USERID,
		            "amount" => $amount,
		            "currency" => $sett["currency"],
		            "paidfor" => "Extra Operator Account(s) / ".$_POST['ops'],
		            "paidhow" => "Stripe - Credit Card",
		            "paidwhen" => $jakdb->raw("NOW()"),
		            "paidtill" => $paiddate,
		            "success" => 1,
		        	"active" => 1]);

				// Now let us delete the define cache file
				$cachewidget = APP_PATH.JAK_CACHE_DIRECTORY.'/opcache'.JAK_USERID.'.php';
					if (file_exists($cachewidget)) {
					unlink($cachewidget);
				}

				// Thank you message can be found in the operator/lang/en.php file
				$_SESSION["successmsg"] = $jkl['i52'];

	            if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
						header('Cache-Control: no-cache');
						die(json_encode(array("status" => 1)));
					} else {
						// redirect back to home
						jak_redirect(BASE_URL);
					}

	            } catch(\Stripe\Error\Card $e) {
					// Error go back to set group
					if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
						header('Cache-Control: no-cache');
						die(json_encode(array("status" => 0, "infomsg" => $jkl["i53"])));
					} else {
						// redirect back to home
						$_SESSION["errormsg"] = $jkl["i53"];
						jak_redirect(BASE_URL);
					}
											
				}

			}

			// Now we go with paypal and verify the payment
			if (isset($_POST['paidhow']) && $_POST['paidhow'] == 'paypal' && isset($_POST['ops']) && is_numeric($_POST['ops'])) {

				// Calculate the price from the months
				$amount = $_POST['ops']*$sett["addops"];
								
				// Include the paypal library
				include_once ('payment/paypal.php');
											
				// Create an instance of the paypal library
				$myPaypal = new Paypal();
											
				// Specify your paypal email
				$myPaypal->addField('business', $sett["paypal"]);
											
				// Specify the currency
				$myPaypal->addField('currency_code', $sett["currency"]);
											
				// Specify the url where paypal will send the user on success/failure
				$myPaypal->addField('return', JAK_rewrite::jakParseurl('ps', 'success'));
				$myPaypal->addField('cancel_return', JAK_rewrite::jakParseurl('ps', 'failure'));
											
				// Specify the url where paypal will send the IPN
				$myPaypal->addField('notify_url', BASE_URL.'payment/paypal_ipn.php');
											
				// Specify the product information
				$myPaypal->addField('item_name', JAK_TITLE);
				$myPaypal->addField('amount', $amount);
											
				// Specify any custom value
				$myPaypal->addField('custom', base64_encode('newop:#:'.JAK_USERID.':#:'.$_POST['ops']));
											
				// Enable test mode if needed
				// $myPaypal->enableTestMode();
									
				$JAK_GO_PAY = $myPaypal->submitPayment($jkl["g296"]);

				if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
					header('Cache-Control: no-cache');
					die(json_encode(array("status" => 1, "content" => $JAK_GO_PAY)));
				}

			}

			// Now we go with paypal and verify the payment
			if (isset($_POST['paidhow']) && $_POST['paidhow'] == 'twoco' && isset($_POST['ops']) && is_numeric($_POST['ops'])) {

				// Calculate the price from the months
				$amount = $_POST['ops']*$sett["addops"];

				// Include the 2Checkout library
				include_once ('payment/twoco.php');

				// Create an instance of the 2Checkout library
				$my2CO = new TwoCo();
						
				// Specify your 2Checkout vendor id
				$my2CO->addField('sid', $sett['twoco']);
						
				// Specify the order information
				$my2CO->addField('cart_order_id', JAK_TITLE);
				$my2CO->addField('total', $amount);
						
				// Specify the url where 2Checkout will send the IPN
				$my2CO->addField('x_Receipt_Link_URL', BASE_URL.'payment/twoco_ipn.php');
				$my2CO->addField('tco_currency', $sett["currency"]);
				$my2CO->addField('custom', base64_encode('newop:#:'.JAK_USERID.':#:'.$_POST['ops']));
						
				// Enable test mode if needed
				// $my2CO->enableTestMode();
						
				$JAK_GO_PAY = $my2CO->submitPayment($jkl["g331"]);

				if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
					header('Cache-Control: no-cache');
					die(json_encode(array("status" => 1, "content" => $JAK_GO_PAY)));
				}

			}

		// Get the payment for extending an operator
		} elseif ($_POST['check'] == "opextend") {

			if (isset($_POST['paidhow']) && $_POST['paidhow'] == 'stripe' && isset($_POST['token']) && !empty($_POST['token']) && isset($_POST['months']) && isset($_POST['opid']) && is_numeric($_POST['opid'])) {

				// Calculate the price from the months
				$amount = $_POST['months']*$sett["addops"];

				require_once('payment/stripe/Stripe.php');
						 
				$stripe = array(
					'secret_key'      => $sett["stripesecret"],
					'publishable_key' => $sett["stripepublic"]
				);

				$stripe_amount = $amount * 100;
										 
				\Stripe\Stripe::setApiKey($sett["stripesecret"]);

				try {
					$charge = \Stripe\Charge::create(array(
					"amount" => $stripe_amount, // amount in cents, again
					"currency" => $sett["currency"],
					"source" => $_POST['token'],
					"description" => $jakuser->getVar("email"))
				);

				// Ok we have a successful payment via Stripe let's extend the account
				$operator = $jakdb->get("user", ["id", "validtill"], ["AND" => ["id" => $_POST['opid'], "opid" => JAK_USERID]]);
				if ($operator['validtill'] > $JAK_CURRENT_DATE) {
					$date = new DateTime($operator['validtill']);
				} else {
					$date = new DateTime();
					
				}

				// Modify the date
				$date->modify('+'.$_POST['months'].' month');
				$paiddate = $date->format('Y-m-d H:i:s');

	            // Payment details insert
	            $jakdb1->insert("subscriptions", [ 
		            "locationid" => JAK_MAIN_LOC,
		            "userid" => JAK_USERID,
		            "amount" => $amount,
		            "currency" => $sett["currency"],
		            "paidfor" => "Operator Account extended",
		            "paidhow" => "Stripe - Credit Card",
		            "paidwhen" => $jakdb->raw("NOW()"),
		            "paidtill" => $paiddate,
		            "success" => 1,
		        	"active" => 1]);

	            // Now finally update the user profile
	            $jakdb->update("user", ["validtill" => $paiddate], ["id" => $operator["id"]]);

	            // Thank you message can be found in the operator/lang/en.php file
				$stripemsg = $jkl['i52'];
				$stripestatus = 1;

	            if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
						header('Cache-Control: no-cache');
						die(json_encode(array("status" => $stripestatus, "infomsg" => $stripemsg, "date" => JAK_base::jakTimesince($paiddate, $jakopsett['dateformat'], $jakopsett['timeformat']))));
					} else {
						// redirect back to home
						jak_redirect(BASE_URL);
					}

	            } catch(\Stripe\Error\Card $e) {
					// Error go back to set group
					if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
						header('Cache-Control: no-cache');
						die(json_encode(array("status" => 0, "infomsg" => $jkl["i53"])));
					} else {
						// redirect back to home
						$_SESSION["errormsg"] = $jkl["i53"];
						jak_redirect(BASE_URL);
					}
											
				}

			}

			// Now we go with paypal and verify the payment
			if (isset($_POST['paidhow']) && $_POST['paidhow'] == 'paypal' && isset($_POST['months']) && isset($_POST['opid']) && is_numeric($_POST['opid'])) {

				// Calculate the price from the months
				$amount = $_POST['months']*$sett["addops"];
								
				// Include the paypal library
				include_once ('payment/paypal.php');
											
				// Create an instance of the paypal library
				$myPaypal = new Paypal();
											
				// Specify your paypal email
				$myPaypal->addField('business', $sett["paypal"]);
											
				// Specify the currency
				$myPaypal->addField('currency_code', $sett["currency"]);
											
				// Specify the url where paypal will send the user on success/failure
				$myPaypal->addField('return', JAK_rewrite::jakParseurl('ps', 'success'));
				$myPaypal->addField('cancel_return', JAK_rewrite::jakParseurl('ps', 'failure'));
											
				// Specify the url where paypal will send the IPN
				$myPaypal->addField('notify_url', BASE_URL.'payment/paypal_ipn.php');
											
				// Specify the product information
				$myPaypal->addField('item_name', JAK_TITLE);
				$myPaypal->addField('amount', $amount);
											
				// Specify any custom value
				$myPaypal->addField('custom', base64_encode('opextend:#:'.JAK_USERID.':#:'.$_POST['months'].':#:'.$_POST['opid']));
											
				// Enable test mode if needed
				// $myPaypal->enableTestMode();
									
				$JAK_GO_PAY = $myPaypal->submitPayment($jkl["g296"]);

				if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
					header('Cache-Control: no-cache');
					die(json_encode(array("status" => 1, "content" => $JAK_GO_PAY)));
				}

			}

			// Now we go with paypal and verify the payment
			if (isset($_POST['paidhow']) && $_POST['paidhow'] == 'twoco' && isset($_POST['months']) && isset($_POST['opid']) && is_numeric($_POST['opid'])) {

				// Calculate the price from the months
				$amount = $_POST['months']*$sett["addops"];

				// Include the 2Checkout library
				include_once ('payment/twoco.php');

				// Create an instance of the 2Checkout library
				$my2CO = new TwoCo();
						
				// Specify your 2Checkout vendor id
				$my2CO->addField('sid', $sett['twoco']);
						
				// Specify the order information
				$my2CO->addField('cart_order_id', JAK_TITLE);
				$my2CO->addField('total', $amount);
						
				// Specify the url where 2Checkout will send the IPN
				$my2CO->addField('x_Receipt_Link_URL', BASE_URL.'payment/twoco_ipn.php');
				$my2CO->addField('tco_currency', $sett["currency"]);
				$my2CO->addField('custom', base64_encode('opextend:#:'.JAK_USERID.':#:'.$_POST['months'].':#:'.$_POST['opid']));
						
				// Enable test mode if needed
				// $my2CO->enableTestMode();
						
				$JAK_GO_PAY = $my2CO->submitPayment($jkl["g331"]);

				if ($_SERVER['HTTP_X_REQUESTED_WITH']) {
					header('Cache-Control: no-cache');
					die(json_encode(array("status" => 1, "content" => $JAK_GO_PAY)));
				}

			}

		}

	}

}

// Statistics
$stataccess = false;
$sessCtotal = $commCtotal = $statsCtotal = $visitCtotal = 0;
if (jak_get_access("statistic", $jakuser->getVar("permissions"))) {

	if (jak_get_access("statistic_all", $jakuser->getVar("permissions"))) {

		// Get the stats  , ["[>]departments" => ["department" => "id"]
		$sessCtotal = $jakdb->count("sessions", ["widgetid" => $opcacheid]);
		$commCtotal = $jakdb->count("transcript", ["[>]sessions" => ["convid" => "id"]], "transcript.id", ["sessions.widgetid" => $opcacheid]);
		$statsCtotal = $jakdb->count("user_stats", ["OR" => ["userid" => JAK_USERID, "userid" => $opcacheid]]);
		$visitCtotal = $jakdb->count("buttonstats", ["opid" => $opcacheid]);
		
	} else {

		// Get the stats
		$sessCtotal = $jakdb->count("sessions", ["AND" => ["widgetid" => $opcacheid, "operatorid" => JAK_USERID]]);
		// Get all convid into an array
		$sessids = $jakdb->select("sessions", "id", ["AND" => ["widgetid" => $opcacheid, "operatorid" => JAK_USERID]]);
		// Get all messages from the convids
		$commCtotal = $jakdb->count("transcript", ["convid" => $sessids]);
		$statsCtotal = $jakdb->count("user_stats", ["userid" => JAK_USERID]);
		$visitCtotal = $jakdb->count("buttonstats", ["AND" => ["opid" => $opcacheid, "depid" => [$jakuser->getVar("departments")]]]);

	}

	$stataccess = true;
}

$JAK_USER_ALL = array();
if (!empty($jakosub) && $jakosub['extraoperators'] > 0) $JAK_USER_ALL = jak_get_user_all("user", JAK_USERID, "siblings");

// Title and Description
$SECTION_TITLE = $jkl['m'];
$SECTION_DESC = "";

// Include the javascript file for results
$js_file_footer = 'js_dashboard.php';
// Call the template
$template = 'dashboard.php';

?>