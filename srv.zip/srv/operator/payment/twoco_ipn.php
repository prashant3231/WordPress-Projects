<?php

/*===============================================*\
|| ############################################# ||
|| # JAKWEB.CH / Version 2.4.3                 # ||
|| # ----------------------------------------- # ||
|| # Copyright 2019 JAKWEB All Rights Reserved # ||
|| ############################################# ||
\*===============================================*/

if (!file_exists('../../config.php')) die('[ipn.php] db.php not exist');
require_once '../../config.php';

// Include the paypal library
include_once ('twoco.php');

// Create an instance of the authorize.net library
$my2CO = new TwoCo();

// Log the IPN results
$my2CO->ipnLog = TRUE;

// Change for 1.0.3
use JAKWEB\JAKsql;

// Now if we have multi site we have fully automated process
if (!empty(JAKDB_MAIN_NAME) && JAK_MAIN_LOC) {
// Database connection to the main site
  $jakdb1 = new JAKsql([
// required
    'database_type' => JAKDB_MAIN_DBTYPE,
    'database_name' => JAKDB_MAIN_NAME,
    'server' => JAKDB_MAIN_HOST,
    'username' => JAKDB_MAIN_USER,
    'password' => JAKDB_MAIN_PASS,
    'charset' => 'utf8',
    'port' => JAKDB_MAIN_PORT,
    'prefix' => JAKDB_MAIN_PREFIX,

// [optional] driver_option for connection, read more from http://www.php.net/manual/en/pdo.setattribute.php
    'option' => [PDO::ATTR_CASE => PDO::CASE_NATURAL]
  ]);

// We get the settings for the payment
  $sett = array();
  $settings = $jakdb1->select("settings", ["varname", "used_value"]);
  foreach ($settings as $v) {
    $sett[$v["varname"]] = $v["used_value"]; 
  }
}

// Specify your authorize login and secret
$my2CO->setSecret($sett['twoco_secret']);

// Enable test mode if needed
// $my2CO->enableTestMode();

// Check validity and write down it
if ($my2CO->validateIpn()) {

  $item_name = base64_decode($my2CO->ipnData['custom']);
  $payment_currency = $my2CO->ipnData['tco_currency'];
  $payment_status = $my2CO->ipnData['invoice_status'];
  $txn_id = $my2CO->ipnData['vendor_order_id'];
  $payment_amount = $my2CO->ipnData['total'];
  $payer_email = $my2CO->ipnData['vendor_id'];
  $onumber = base64_decode($my2CO->ipnData['order_number']);

  $custom = explode(":#:", $item_name);

  // Define the userid
  define('JAK_USERID', $custom[1]);

  $jakdb1->insert("payment_ipn", [
    "userid" => $custom[1],
    "status" => $payment_status,
    "amount" => $payment_amount,
    "currency" => $payment_currency,
    "txn_id" => $txn_id,
    "receiver_email" => $sett['twoco'],
    "payer_email" => $payer_email,
    "paid_with" => "2Checkout",
    "time" => $jakdb->raw("NOW()")]);

  // check that txn_id has not been previously processed
  $onepay = $jakdb1->count("payment_ipn", ["txn_id" => $txn_id]);

  // Current time
  $timenow = time();

  if ($onepay == 1 && $jakdb1 && $custom[0] == "paymember") {

    if (!empty($payment_amount) && $custom[4]) {

      // Get the package
      $pack = $jakdb1->get("packages", ["id", "title", "amount", "currency", "operators", "departments", "files", "copyfree", "activechats", "chathistory", "islc3", "ishd3", "validfor"], ["AND" => ["id" => $custom[4], "active" => 1]]);

      // First we need the old subscriptions
      $subs = $jakdb->get("subscriptions", ["id", "packageid", "operators", "departments", "files", "chathistory", "paygateid", "subscribeid", "subscribed", "paidtill"], ["opid" => $custom[1]]);

      // We get the user data from the main table
      $couponvalid = false;
      if (isset($custom[3]) && $jakdb1->has("coupons", ["AND" => ["locationid" => JAK_MAIN_LOC, "code" => $custom[3], "active" => 1]])) {
        $cd = $jakdb1->get("coupons", ["id", "title", "discount", "freepackageid", "used", "total", "datestart", "dateend", "products"], ["AND" => ["locationid" => JAK_MAIN_LOC, "code" => $custom[3], "active" => 1]]);
        $couponvalid = true;
      }

      // is there any open subscription
      $jakdb1->update("subscriptions", ["subscribeid" => 0, "subscribed" => 0, "active" => 0], ["AND" => ["locationid" => JAK_MAIN_LOC, "userid" => $custom[1], "subscribeid" => $subs["subscribeid"]]]);

      // Get the user details.
      $mainusr = $jakdb1->get("users", ["opid", "name", "email", "username", "password"], ["AND" => ["opid" => $custom[1], "locationid" => JAK_MAIN_LOC]]);

      // How long is the package valid for in unix
      $paidunix = strtotime("+".$pack["validfor"]." days");

      // Since 2.4 we will calculate the already paid days and add it when in the same package
      if ($subs["packageid"] == $pack["id"]) {
        $paidtillold = strtotime($subs["paidtill"]);
        if ($paidtillold > $timenow) {

          $diffpaid = $paidtillold - $timenow;
          $paidunix = $paidunix + $diffpaid;

        }
      }

      // get the nice time
      $paidtill = date('Y-m-d H:i:s', $paidunix);

      // We have an advanced payment
      if ($pack["islc3"] || $pack["ishd3"]) {

        // 1 stands for LC3
        $islc3hd3 = 1;
        if ($pack["ishd3"]) $islc3hd3 = 2;

        if ($jakdb1->has("advaccess", ["AND" => ["userid" => $opmain["id"], "opid" => $custom[1]]])) {

          // Update the advanced access table
          $jakdb1->update("advaccess", [ 
            "lastedit" => $jakdb->raw("NOW()"),
            "paidtill" => $paidtill,
            "lc3hd3" => $islc3hd3,
            "paythanks" => 1], ["AND" => ["opid" => $custom[1], "id" => $opmain["id"]]]);
        } else {
          $jakdb1->insert("advaccess", ["userid" => $opmain["id"], "opid" => $custom[1], "lc3hd3" => $islc3hd3, "lastedit" => $jakdb->raw("NOW()"), "paythanks" => 1, "paidtill" => $paidtill, "created" => $jakdb->raw("NOW()")]);
        }

        // Ok, we have removed the old stuff and now we update the user subscription table
        $jakdb->update("subscriptions", ["packageid" => $pack["id"], "operators" => $pack["operators"], "departments" => $pack["departments"], "files" => $pack["files"], "activechats" => $pack["activechats"], "chathistory" => $pack["chathistory"], "islc3" => $pack["islc3"], "ishd3" => $pack["ishd3"], "validfor" => $pack["validfor"], "subscribed" => 0, "amount" => $payment_amount, "currency" => $sett["currency"], "paidhow" => "2Checkout", "paidwhen" => $jakdb->raw("NOW()"), "paidtill" => $paidtill, "trial" => 0], ["opid" => $custom[1]]);

                    $mail = new PHPMailer(); // defaults to using php "mail()"

                    if (JAK_SMTP_MAIL) {

                        $mail->IsSMTP(); // telling the class to use SMTP
                        $mail->Host = JAK_SMTPHOST;
                        $mail->SMTPAuth = (JAK_SMTP_AUTH ? true : false); // enable SMTP authentication
                        $mail->SMTPSecure = JAK_SMTP_PREFIX; // sets the prefix to the server
                        $mail->SMTPAutoTLS = false;
                        $mail->SMTPKeepAlive = (JAK_SMTP_ALIVE ? true : false); // SMTP connection will not close after each email sent
                        $mail->Port = JAK_SMTPPORT; // set the SMTP port for the GMAIL server
                        $mail->Username = JAK_SMTPUSERNAME; // SMTP account username
                        $mail->Password = JAK_SMTPPASSWORD; // SMTP account password
                        $mail->SetFrom(JAK_EMAIL);
                        $mail->AddAddress(JAK_EMAIL);
                        $mail->AddReplyTo($mainusr["email"]);

                      } else {

                        $mail->SetFrom(JAK_EMAIL);
                        $mail->AddAddress(JAK_EMAIL);
                        $mail->AddReplyTo($mainusr["email"]);

                      }

                      $mail->Subject = $jkl['i49'];

                      $mailadv = sprintf($jkl['i50'], $mainusr["name"], $mainusr["username"], $custom[1], $mainusr["email"], $mainusr["password"], $paidunix, ($islc3hd3 == 1 ? 'Live Chat 3' : 'HelpDesk 3'), SIGN_UP_URL.'/process/confirmadv.php?uid='.$custom[1]);
                      $mail->MsgHTML($mailadv);
                      $mail->Send();

                    } else {

                      // Nasty stuff starts
                      if (isset($subs) && isset($pack)) {

                        update_main_operator($subs, $pack, $sett["stripepublic"], $sett["stripesecret"], $sett["currency"], $payment_amount, $subs["paygateid"], 0, 0, "2Checkout", $custom[1], JAK_MAIN_LOC);

                      }

                    }

                    // Update old subscriptions to none active
                    $jakdb1->update("subscriptions", ["active" => 0], ["AND" => ["locationid" => JAK_MAIN_LOC, "userid" => $custom[1]]]);

                    // We insert the subscription into the main table for that user.
                    $jakdb1->insert("subscriptions", ["locationid" => JAK_MAIN_LOC,
                      "packageid" => $pack["id"],
                      "userid" => $custom[1],
                      "amount" => $payment_amount,
                      "currency" => $sett["currency"],
                      "paidfor" => $pack["title"],
                      "paidhow" => "2Checkout",
                      "subscribed" => $subs['subscribed'],
                      "paygateid" => $subs["paygateid"],
                      "subscribeid" => $subs['subscribeid'],
                      "paidwhen" => $jakdb->raw("NOW()"),
                      "paidtill" => $paidtill,
                      "active" => 1,
                      "success" => 1]);

                    // finally update the main database
                    $jakdb1->update("users", ["trial" => "1980-05-06 00:00:00",
                      "paidtill" => $paidtill,
                      "payreminder" => 0,
                      "paythanks" => 1,
                      "active" => 1,
                      "confirm" => 0], ["AND" => ["opid" => $custom[1], "locationid" => JAK_MAIN_LOC]]);

                    // Update the coupon counter
                    if ($couponvalid) $jakdb1->update("coupons", ["used[+]" => 1], ["id" => $cd["id"]]);

                    // Now let us delete the define cache file
                    $cachewidget = APP_PATH.JAK_CACHE_DIRECTORY.'/opcache'.$custom[1].'.php';
                    if (file_exists($cachewidget)) {
                      unlink($cachewidget);
                    }

                  }

                  if ($jakdb1 && $custom[0] == "newop") {

                    // Calculate the price from the months
                    $amount = $custom[2]*$sett["addops"];

                    // Ok we have a successful payment via Stripe let's add this to the extra operators
                    $jakdb->update("subscriptions", ["extraoperators[+]" => $custom[2]], ["opid" => $custom[1]]);

                    $date = new DateTime();
                    // Modify the date
                    $date->modify('+1 month');
                    $paiddate = $date->format('Y-m-d H:i:s');

                    // Payment details insert
                    $jakdb1->insert("subscriptions", [ 
                      "locationid" => JAK_MAIN_LOC,
                      "userid" => $custom[1],
                      "amount" => $amount,
                      "currency" => $sett["currency"],
                      "paidfor" => "Extra Operator Account(s) / ".$custom[2],
                      "paidhow" => "2Checkout",
                      "paidwhen" => $jakdb->raw("NOW()"),
                      "paidtill" => $paiddate,
                      "success" => 1,
                      "active" => 1]);

                  }

                  if ($jakdb1 && $custom[0] == "opextend") {

                    // Calculate the price from the months
                    $amount = $custom[2]*$sett["addops"];

                    // Ok we have a successful payment via 2Checkout let's extend the account
                    $operator = $jakdb->get("user", ["id", "validtill"], ["AND" => ["id" => $custom[3], "opid" => $custom[1]]]);
                    if ($operator['validtill'] > $JAK_CURRENT_DATE) {
                      $date = new DateTime($operator['validtill']);
                    } else {
                      $date = new DateTime();

                    }

                    // Modify the date
                    $date->modify('+'.$custom[2].' month');
                    $paiddate = $date->format('Y-m-d H:i:s');

                    // Payment details insert
                    $jakdb1->insert("subscriptions", [ 
                      "locationid" => JAK_MAIN_LOC,
                      "userid" => $custom[1],
                      "amount" => $amount,
                      "currency" => $sett["currency"],
                      "paidfor" => "Operator Account extended",
                      "paidhow" => "2Checkout",
                      "paidwhen" => $jakdb->raw("NOW()"),
                      "paidtill" => $paiddate,
                      "success" => 1,
                      "active" => 1]);

                    // Now finally update the user profile
                    $jakdb->update("user", ["validtill" => $paiddate], ["id" => $operator["id"]]);

                  }

            // Send the succesful message to the business owner
            $mail = new PHPMailer(); // defaults to using php "mail()"
            $mail->SetFrom(JAK_EMAIL);
            $mail->AddAddress(JAK_EMAIL);
            $mail->AddReplyTo($payer_email);
            $mail->Subject = JAK_TITLE.' - 2Checkout Success';
            $mail->Body = 'There is a new payment thru 2Checkout, userid: '.$custom[1].' - '.$item_name.' - '.$payment_status.' - '.$payment_amount.' - '.$payment_currency.' - '.$txn_id.' - '.$receiver_email.' - '.$payer_email;
            $mail->Send(); // Send email without any warnings

          } else {

            // log for manual investigation amount is not the same
            $mail = new PHPMailer(); // defaults to using php "mail()"
            $mail->SetFrom(JAK_EMAIL);
            $mail->AddAddress(JAK_EMAIL);
            $mail->AddReplyTo($payer_email);
            $mail->Subject = JAK_TITLE.' - 2Checkout Success, but...';
            $mail->Body = 'There is a new payment thru 2Checkout, userid: '.$custom[1].' - '.$item_name.' - '.$payment_status.' - '.$payment_amount.' - '.$payment_currency.' - '.$txn_id.' - '.$receiver_email.' - '.$payer_email.' But the amount was paid is not the same amount was ordered, please check in the shop order details.';
            $mail->Send(); // Send email without any warnings
            
          }

} else {

  // Write the error into the log file
  file_put_contents('2co.ipn_results.log', "FAILURE\n\n" . $my2CO->ipnData);

  // log for manual investigation
  $mail = new PHPMailer(); // defaults to using php "mail()"
  $mail->SetFrom(JAK_EMAIL);
  $mail->AddAddress(JAK_EMAIL);
  $mail->AddReplyTo($payer_email);
  $mail->Subject = JAK_TITLE.' - 2Checkout HTTP error';
  $mail->Body = 'There is an error with 2Checkout, please check with 2Checkout.';
}
?>