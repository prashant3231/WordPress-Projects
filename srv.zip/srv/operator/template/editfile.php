<?php include_once 'header.php';?>

<?php if ($errors) { ?>
<div class="alert alert-danger">
<?php if (isset($errors["e"])) echo $errors["e"];
	  if (isset($errors["e1"])) echo $errors["e1"];?>
</div>
<?php } ?>

<form role="form" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
<div class="box">
<div class="box-header with-border">
  <h3 class="box-title"><?php echo $jkl["g47"];?></h3>
</div><!-- /.box-header -->
<div class="box-body">
<div class="table-responsive">
<table class="table table-striped">
<tr>
	<td>
		<?php if (file_exists(CLIENT_UPLOAD_DIR.$JAK_FORM_DATA["path"])) { if (getimagesize(CLIENT_UPLOAD_DIR.$JAK_FORM_DATA["path"])) { ?>
			<img class="img-thumbnail img-fluid" src="<?php echo BASE_URL_ORIG;?>_showfile.php?i=<?php echo jak_encrypt_decrypt($JAK_FORM_DATA["path"].':#:'.$JAK_FORM_DATA["orig_name"].':#:'.$JAK_FORM_DATA["mime_type"]);?>" alt="<?php echo $JAK_FORM_DATA["name"];?>">
		<?php } else { ?>
			<a class="btn btn-secondary" href="<?php echo BASE_URL_ORIG;?>_showfile.php?i=<?php echo jak_encrypt_decrypt($JAK_FORM_DATA["path"].':#:'.$JAK_FORM_DATA["orig_name"].':#:'.$JAK_FORM_DATA["mime_type"]);?>"><i class="fa fa-download fa-2x"></i> <?php echo $JAK_FORM_DATA["orig_name"];?></a>
		<?php } } else { ?>
		<?php echo $jkl['i16'];?>
		<?php } ?>
	</td>
<tr>
	<td>
	<div class="form-group">
		<label for="name"><?php echo $jkl["g53"];?></label>
		<input type="text" name="name" id="name" class="form-control<?php if (isset($errors["e"])) echo " is-invalid";?>" value="<?php echo $JAK_FORM_DATA["name"];?>" />
	</div>
	</td>
</tr>
<tr>
	<td>
		<div class="form-group">
			<label for="desc"><?php echo $jkl["g52"];?></label>
			<textarea name="description" id="desc" rows="5" class="form-control"><?php echo $JAK_FORM_DATA["description"];?></textarea>
		</div>		
	</td>
</tr>
</table>
</div>
</div>
<div class="box-footer">
	<a href="<?php echo JAK_rewrite::jakParseurl('files');?>" class="btn btn-default"><?php echo $jkl["g103"];?></a>
	<button type="submit" name="save" class="btn btn-primary pull-right"><?php echo $jkl["g38"];?></button>
</div>
</div>

</form>
		
<?php include_once 'footer.php';?>