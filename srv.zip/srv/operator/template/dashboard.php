<?php include_once 'header.php';?>

<?php if ($jakopsett['holiday_mode'] != 0) { ?>
<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> <?php echo $jkl["g303"];?> (<?php echo (JAK_HOLIDAY_MODE == 1 ? $jkl["g1"] : $jkl["g305"]);?>)</div>
<?php } ?>

<?php if ($stataccess) { ?>

<h3><?php echo $jkl["m10"];?> <a href="<?php echo JAK_rewrite::jakParseurl('statistics');?>"><i class="fa fa-pie-chart"></i></a></h3>

<!-- Small boxes (Stat box) -->
<div class="row">
  <div class="col-lg-3 col-6">
    <!-- small box -->
    <div class="small-box bg-aqua">
      <div class="inner">
        <h3><?php echo $sessCtotal;?></h3>
        <p><?php echo $jkl["stat_s25"];?></p>
      </div>
      <div class="icon">
        <i class="fa fa-bar-chart"></i>
      </div>
      <a href="<?php echo JAK_rewrite::jakParseurl('leads');?>" class="small-box-footer"><?php echo $jkl["stat_s28"];?> <i class="fa fa-arrow-circle-right"></i></a>
    </div>
  </div><!-- ./col -->
  <div class="col-lg-3 col-6">
    <!-- small box -->
    <div class="small-box bg-green">
      <div class="inner">
        <h3><?php echo $commCtotal;?></h3>
        <p><?php echo $jkl["stat_s26"];?></p>
      </div>
      <div class="icon">
        <i class="fa fa-comments-o"></i>
      </div>
      <a href="<?php echo JAK_rewrite::jakParseurl('leads');?>" class="small-box-footer"><?php echo $jkl["stat_s28"];?> <i class="fa fa-arrow-circle-right"></i></a>
    </div>
  </div><!-- ./col -->
  <div class="col-lg-3 col-6">
    <!-- small box -->
    <div class="small-box bg-yellow">
      <div class="inner">
        <h3><?php echo $statsCtotal;?></h3>
        <p><?php echo $jkl["stat_s10"];?></p>
      </div>
      <div class="icon">
        <i class="fa fa-pie-chart"></i>
      </div>
      <a href="<?php echo JAK_rewrite::jakParseurl('users');?>" class="small-box-footer"><?php echo $jkl["stat_s28"];?> <i class="fa fa-arrow-circle-right"></i></a>
    </div>
  </div><!-- ./col -->
  <div class="col-lg-3 col-6">
    <!-- small box -->
    <div class="small-box bg-red">
      <div class="inner">
        <h3><?php echo $visitCtotal;?></h3>
        <p><?php echo $jkl["stat_s27"];?></p>
      </div>
      <div class="icon">
        <i class="fa fa-users"></i>
      </div>
      <a href="<?php echo JAK_rewrite::jakParseurl('uonline');?>" class="small-box-footer"><?php echo $jkl["stat_s28"];?> <i class="fa fa-arrow-circle-right"></i></a>
    </div>
  </div><!-- ./col -->
</div><!-- /.row -->
<?php } ?>
<!-- Small boxes (Stat box) -->

<!-- Link to Apps -->
<?php echo $sett["appboxes"];?>
<!-- end Link to Apps -->

<!-- Let's get the client up and running -->
<?php if (isset($opmain) && !empty($opmain)) { if (strtotime($opmain["paidtill"]) < time()) { ?>

<div class="alert alert-danger" id="expiredmsg"><?php echo $sett["expiredmsgdash"];?></div>

<?php } else { if (strtotime($opmain["trial"]) > time()) { ?>
<div class="row" id="trialmsg">
<div class="col-md-12">
<div class="alert alert-info">
  <p class="mb-0">
<?php 
    $trans = array("{{trialdate}}" => JAK_base::jakTimesince($opmain["trial"], $jakopsett['dateformat'], $jakopsett['timeformat']));
    echo strtr($sett["trialdate"], $trans);
?>
</p>
</div>
</div>
</div>
<?php } } ?>

<?php if (!empty($sett["welcomedash"])) { ?>
<div class="row">
  <div class="col-md-12">
    <div class="alert alert-secondary">
      <div class="row">
        <div class="col-md-12">
          <?php echo $sett["welcomedash"];?>
        </div>
      </div>
    </div>
  </div>
</div>
<?php } if (!empty($sett["heldashpmsg"])) { 
    $trans = array("{{paidtill}}" => ($jakosub["paidtill"] != "0000-00-00 00:00:00" ? JAK_base::jakTimesince($jakosub["paidtill"], $jakopsett['dateformat'], $jakopsett['timeformat']) : 'expired'), "{{clientprofile}}" => JAK_rewrite::jakParseurl('users','edit',JAK_USERID), "{{clientsettings}}" => JAK_rewrite::jakParseurl('opsettings'), "{{clientwidget}}" => JAK_rewrite::jakParseurl('widget'), "{{clientresponse}}" => JAK_rewrite::jakParseurl('response'), "{{clientproactive}}" => JAK_rewrite::jakParseurl('proactive'), "{{clientbot}}" => JAK_rewrite::jakParseurl('bot'));
    echo strtr($sett["heldashpmsg"], $trans);

  }
?>

<?php if (!$jakuser->getVar("hours_array")) { ?>
<div class="row">
  <div class="col-md-12">
    <div class="alert alert-warning">
      <div class="row">
        <div class="col-md-1">
          <i class="fa fa-flag fa-4x"></i>
        </div>
        <div class="col-md-11">
          <p class="mb-0"><?php $trans = array("{{clientprofile}}" => JAK_rewrite::jakParseurl('users','edit',JAK_USERID));
    echo strtr($sett["businesshours"], $trans);?></p>
        </div>
      </div>
    </div>
  </div>
</div>
<?php } ?>

<?php if (isset($subscriptions) && !empty($subscriptions)) { ?>
<!-- Purchased subscriptions -->
<div class="row">
  <div class="col-md-12">
  <div class="box box-success">
  <div class="box-header with-border">
    <h3 class="box-title"><i class="fa fa-user"></i> <?php echo $sett["purchasedtitle"];?></h3>
  </div><!-- /.box-header -->
  <div class="box-body">

  <div class="table-responsive">
    <table class="table table-striped">
      <thead>
        <tr>
          <th><?php echo $jkl['g16'];?></th>
          <th><?php echo $jkl["i36"];?></th>
          <th><?php echo $jkl["i37"];?></th>
          <th><?php echo $jkl["i38"];?></th>
          <th><?php echo $jkl["i39"];?></th>
          <th><?php echo $jkl["i40"];?></th>
          <th><?php echo $jkl["g14"];?></th>
          <th><?php echo $jkl['g101'];?></th>
          <th></th>
        </tr>
      </thead>
    <?php $subused = array(); foreach($subscriptions as $s) { ?>
      <tr>
        <td><?php echo ($s["title"] ? $s["title"] : $s["paidfor"]);?></td>
        <td><?php echo $s["amount"].' '.$s["currency"];?></td>
        <td><?php echo $s["paidhow"];?></td>
        <td><?php echo ($s["subscribed"] ? '<i class="fa fa-check"></i>' : '<i class="fa fa-times"></i>');?></td>
        <td><?php echo ($s["paidwhen"] ? JAK_base::jakTimesince($s["paidwhen"], "d.m.Y", " g:i a") : "-");?></td>
        <td><?php echo ($s["paidtill"] ? JAK_base::jakTimesince($s["paidtill"], "d.m.Y", " g:i a") : "-");?></td>
        <td><?php echo ($s["success"] ? '<i class="fa fa-check"></i>' : '<i class="fa fa-times"></i>');?></td>
        <td><?php echo ($s["active"] ? '<i class="fa fa-check"></i>' : '<i class="fa fa-times"></i>');?></td>
        <td><?php echo ($s["subscribed"] && $s["active"] ? '<a href="'.JAK_rewrite::jakParseurl('cs', $s["id"],JAK_USERID).'" class="btn btn-sm btn-danger">'.$jkl['g280'].'</a>' : '');?></td>
      </tr>
    <?php $subused[] = $s["packageid"]; } ?>
    </table>
  </div>
  </div>
</div>
</div>
</div>
<?php } ?>

<?php if (isset($packages) && !empty($packages)) { ?>
<div class="row">
  <div class="col-md-12">
  <div class="box box-primary">
  <div class="box-header with-border">
    <h3 class="box-title"><i class="fa fa-archive"></i> <?php echo $sett["packageseltitle"];?></h3>
  </div><!-- /.box-header -->
  <div class="box-body">
    <p><span class="badge badge-light"><?php echo $jkl['i46'];?></span> <span class="badge badge-success"><?php echo $jkl['i47'];?></span> <span class="badge  badge-dark"><?php echo $jkl['i48'];?></span></p>
    <div class="row">
    <?php foreach ($packages as $p) { ?>
    <div class="col-md-4 mb-3">
    <div class="card<?php if ($p["multipleuse"] == 0 && !empty($p["sid"])) { echo ' text-white bg-dark'; } elseif ($p["id"] == $jakosub['packageid']) { echo ' text-white bg-success';}?>">
    <?php if (!empty($p["previmg"])) { ?><img class="card-img-top img-fluid" src="<?php echo $p["previmg"];?>" alt="<?php echo $p["title"];?>"><?php } ?>
    <div class="card-body">
        <h4 class="card-title"><?php echo $p["title"];?></h4>
        <p class="card-text"><?php echo $p["description"];?></p>
        <p class="card-text"><?php echo sprintf($jkl['i17'], $p["operators"]);?><br>
        <?php echo sprintf($jkl['i18'], $p["departments"]);?><br>
        <?php echo sprintf($jkl['i19'], ($p["files"] ? '<i class="fa fa-check"></i>' : '<i class="fa fa-times"></i>'));?><br>
        <?php echo sprintf($jkl['i20'], ($p["copyfree"] ? '<i class="fa fa-check"></i>' : '<i class="fa fa-times"></i>'));?><br>
        <?php echo sprintf($jkl['i21'], $p["activechats"]);?><br>
        <?php echo sprintf($jkl['i42'], $p["chathistory"]);?><br>
        <?php echo ($p["islc3"] ? sprintf($jkl['i22'], '<i class="fa fa-check"></i>').'<br>' : '');?>
        <?php echo ($p["ishd3"] ? sprintf($jkl['i23'], '<i class="fa fa-check"></i>').'<br>' : '');?>
        <strong><?php echo sprintf($jkl['i24'], $p["validfor"]);?></strong><br>
        <?php echo sprintf($jkl['i25'], ($p["multipleuse"] ? '<i class="fa fa-check"></i>' : '<i class="fa fa-times"></i>'));?><?php if ($sett["stripepublic"] && $p["isfree"] == 0) { ?><br>
        <?php echo sprintf($jkl['i26'], '<input type="checkbox" name="subscribe" id="subscribe-'.$p["id"].'" class="subscribe" data-multid="'.$p["id"].'" value="1">');?><?php } ?></p>
        <h6><?php echo sprintf($jkl['i31'], '<span id="price-'.$p["id"].'">'.$p["amount"].'</span> '.$p["currency"]);?></h6>
        <?php if ($p["isfree"] == 0) { ?>
        <div class="form-group">
          <label for="coupon"><?php echo $jkl['i27'];?></label>
          <div class="input-group">
          <input type="text" class="form-control" id="coupon-<?php echo $p["id"];?>" autocomplete="false">
              <span class="input-group-btn">
            <button class="btn btn-secondary coupon-check" data-cid="<?php echo $p["id"];?>" data-amount="<?php echo $p["amount"];?>" type="button"><i class="jak-loadbtn"></i> <?php echo $jkl['i30'];?></button>
          </span>
          </div>
          <small id="coupon-help-<?php echo $p["id"];?>" class="form-text"></small>
        </div>
        <?php } ?>
    </div>
    <div class="card-footer text-center">
      <?php if ($p["multipleuse"] == 0 && !empty($subused) && in_array($p["id"], $subused)) { ?>
        <a href="javascript:void(0)" class="btn btn-danger"><?php echo $jkl['i41'];?></a>
        <?php } else { if ($p["isfree"] == 1) { ?>
        <a href="javascript:void(0)" class="btn btn-primary free-access" data-package="<?php echo $p["id"];?>" data-amount="<?php echo $p["amount"];?>" data-currency="<?php echo $p["currency"];?>" data-title="<?php echo $p["title"];?>" data-description="<?php echo $p["description"];?>"><i class="jak-loadbtn"></i> <i class="fa fa-gift"></i> <?php echo $jkl["g333"];?></a>
      <?php } else { if ($sett["stripepublic"]) { ?>
      <a href="javascript:void(0)" class="btn btn-primary stripe" data-package="<?php echo $p["id"];?>" data-amount="<?php echo $p["amount"];?>" data-currency="<?php echo $p["currency"];?>" data-title="<?php echo $p["title"];?>" data-description="<?php echo $p["description"];?>"><i class="jak-loadbtn"></i> <i class="fa fa-cc-stripe"></i> <?php echo $jkl['g293'];?></a>
      <?php } if ($sett["paypal"]) { ?>
      <a href="javascript:void(0)" class="btn btn-primary paypal" id="paypal-hide-<?php echo $p["id"];?>" data-package="<?php echo $p["id"];?>" data-amount="<?php echo $p["amount"];?>" data-currency="<?php echo $p["currency"];?>" data-title="<?php echo $p["title"];?>" data-description="<?php echo $p["description"];?>"><i class="jak-loadbtn"></i> <i class="fa fa-paypal"></i> <?php echo $jkl['g294'];?></a>
      <?php } if ($sett["twoco"]) { ?>
      <a href="javascript:void(0)" class="btn btn-primary twoco" id="twoco-hide-<?php echo $p["id"];?>" data-package="<?php echo $p["id"];?>" data-amount="<?php echo $p["amount"];?>" data-currency="<?php echo $p["currency"];?>" data-title="<?php echo $p["title"];?>" data-description="<?php echo $p["description"];?>"><i class="jak-loadbtn"></i> <i class="fa fa-credit-card-alt"></i> <?php echo $jkl["g332"];?></a>
      <?php } } } ?>
      <input type="hidden" id="discount-<?php echo $p["id"];?>" value="0">
    </div>
  </div>
</div>
    <?php } ?>
  </div>
  </div>
</div>
</div>
</div>
<?php } ?>

<?php if (!empty($sett["addops"])) { ?>

<?php echo $sett["addopsmsg"];?>

<!-- Additional Operator Accounts -->
<div class="row">
  <div class="col-md-12">
  <div class="box box-success">
  <div class="box-header with-border">
    <h3 class="box-title"><i class="fa fa-user"></i> <?php echo $sett["addoptitle"];?></h3>
  </div><!-- /.box-header -->
  <div class="box-body">

    <div class="row">
      <div class="col-3">
        <select name="newops" id="newops" class="form-control">
          <optgroup label="Add more Operators *">
            <?php if ($jakopsett['totalops'] < 5) { ?>
            <option value="1" data-price="<?php echo $sett["addops"];?>">1 Operator (<?php echo $sett["addops"].' '.$sett["currency"];?> per Month)</option>
            <?php } if ($jakopsett['totalops'] < 4) { ?>
            <option value="2" data-price="<?php echo 2*$sett["addops"];?>">2 Operators (<?php echo 2*$sett["addops"].' '.$sett["currency"];?> per Month)</option>
            <?php } if ($jakopsett['totalops'] < 3) { ?>
            <option value="3" data-price="<?php echo 3*$sett["addops"];?>">3 Operators (<?php echo 3*$sett["addops"].' '.$sett["currency"];?> per Month)</option>
            <?php } if ($jakopsett['totalops'] < 2) { ?>
            <option value="4" data-price="<?php echo 4*$sett["addops"];?>">4 Operators (<?php echo 4*$sett["addops"].' '.$sett["currency"];?> per Month)</option>
            <?php } if ($jakopsett['totalops'] < 1) { ?>
            <option value="5" data-price="<?php echo 5*$sett["addops"];?>">5 Operators (<?php echo 5*$sett["addops"].' '.$sett["currency"];?> per Month)</option>
            <?php } ?>
          </optgroup>
        </select>
      </div>
      <div class="col-3">
        <?php if ($sett["paypal"]) { ?><p><a href="javascript:void(0)" class="btn btn-primary btn-block btn-pay" id="new-op-paypal"><i class="jak-loadbtn"></i> <i class="fa fa-paypal"></i> <?php echo $jkl['g294'];?></a></p><?php } ?>
      </div>
      <div class="col-3">
        <?php if ($sett["stripepublic"]) { ?><p><a href="javascript:void(0)" class="btn btn-primary btn-block btn-pay" id="new-op-stripe"><i class="jak-loadbtn"></i> <i class="fa fa-cc-stripe"></i> <?php echo $jkl['g293'];?></a></p><?php } ?>
      </div>
      <div class="col-3">
        <?php if ($sett["twoco"]) { ?><p><a href="javascript:void(0)" class="btn btn-primary btn-block btn-pay" id="new-op-twoco"><i class="jak-loadbtn"></i> <i class="fa fa-credit-card-alt"></i> <?php echo $jkl['g332'];?></a></p><?php } ?>
      </div>
    </div>

  <!-- Additional Operator Accounts -->
  <?php if ($jakosub['extraoperators'] > 0 && isset($JAK_USER_ALL) && empty($JAK_USER_ALL)) { ?>
    <p>You can <a href="<?php echo JAK_rewrite::jakParseurl('users', 'new');?>" class="alert-link">add more operators</a> here.</p>
  <?php } elseif (isset($JAK_USER_ALL) && !empty($JAK_USER_ALL) && is_array($JAK_USER_ALL)) { ?>
  <div class="table-responsive">
    <table class="table table-striped">
      <thead>
        <tr>
          <th><?php echo $jkl["u"];?></th>
          <th><?php echo $jkl["u1"];?></th>
          <th><?php echo $jkl["u2"];?></th>
          <th><?php echo $jkl['g47'];?></th>
          <th>Expires</th>
          <th>Extend</th>
        </tr>
      </thead>
    <?php foreach($JAK_USER_ALL as $v) { ?>
      <tr id="opid<?php echo $v["id"];?>"<?php if ($v["validtill"] < $JAK_CURRENT_DATE) echo ' class="table-danger"';?>>
        <td><?php echo $v["name"];?></td>
        <td><?php echo $v["email"];?></td>
        <td><?php echo $v["username"];?></td>
        <td><a class="btn btn-default btn-sm" href="<?php echo JAK_rewrite::jakParseurl('users', 'edit', $v["id"], $v["opid"]);?>"><i class="fa fa-pencil"></i></a></td>
        <td id="opexpire<?php echo $v["id"];?>"><?php echo JAK_base::jakTimesince($v["validtill"], $jakopsett['dateformat'], $jakopsett['timeformat']);?></td>
        <td><div class="input-group"><select name="extop" id="extop" class="form-control form-control-sm"><?php for ($i=1; $i < 13; $i++) { ?>
          <option value="<?php echo $i;?>" data-price="<?php echo $i*$sett["addops"];?>" data-opid="<?php echo $v["id"];?>"><?php echo $i;?> Month<?php if ($i > 1) echo 's';?> (<?php echo $i*$sett["addops"].' '.$sett["currency"];?>)</option>
        <?php } ?></select><?php if ($sett["paypal"]) { ?><span class="input-group-btn">
        <button class="btn btn-warning btn-sm paypal-op"><i class="jak-loadbtn"></i> <i class="fa fa-paypal"></i></button>
      </span><?php } if ($sett["stripepublic"]) { ?><span class="input-group-btn">
        <button class="btn btn-primary btn-sm stripe-op"><i class="jak-loadbtn"></i> <i class="fa fa-cc-stripe"></i></button>
      </span><?php } if ($sett["twoco"]) { ?><span class="input-group-btn">
        <button class="btn btn-warning btn-sm twoco-op"><i class="jak-loadbtn"></i> <i class="fa fa-credit-card-alt"></i></button>
      </span><?php } ?></div></td>
      </tr>
    <?php } ?>
    </table>
  </div>

  <?php } else { ?>
  <hr>
  <div class="alert alert-warning"><?php echo $sett["moreopmsg"];?></div>
  <?php } ?>

  <?php echo $sett["opwarnmsg"];?>
  </div>
</div>
</div>
</div>
<?php } ?>

<input type="hidden" name="stripeToken" id="stripeToken">
<input type="hidden" name="stripeEmail" id="stripeEmail">
<div id="paypal_form" class="hidden"></div>

<?php } ?>

<?php include_once 'footer.php';?>