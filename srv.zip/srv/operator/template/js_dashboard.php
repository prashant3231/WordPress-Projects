<script src="https://checkout.stripe.com/checkout.js"></script>

<!-- JavaScript for select all -->
<script type="text/javascript">

$('.subscribe').on('click', function(e) {
	var phid = $(this).data("multid");
	$('#paypal-hide-'+phid).toggle();
});

// on click event
$(".coupon-check").on('click', function(e) {
	e.preventDefault();

	$(this).find(".jak-loadbtn").addClass("fa fa-spinner fa-spin");

	var cid = $(this).data("cid");
	var amount = $(this).data("amount");
	var cval = $("#coupon-"+cid).val();

	if (cval.length == 0) {
		$("#coupon-help-"+cid).addClass("text-danger").html("<?php echo $jkl['i32'];?>");
		$(this).find(".jak-loadbtn").removeClass("fa fa-spinner fa-spin");
		return true;
	} else {
		jak_coupon_validation(cid, cval, amount, false, false);
		$(this).find(".jak-loadbtn").removeClass("fa fa-spinner fa-spin");
		return true;
	}
});

// Extend Membership
$('.stripe').on('click', function(e) {

	$(this).find(".jak-loadbtn").addClass("fa fa-spinner fa-spin");

	var subscribe = false;
	var _this = $(this);
	var pid = $(this).data("package");
	var amount = $(this).data("amount");
	var discount = $("#discount-"+pid).val();
	var currency = $(this).data("currency");
	var cval = $("#coupon-"+pid).val();
	var ptitle = $(this).data("title");
	var pdesc = $(this).data("description");
	if ($('#subscribe-'+pid).prop('checked')) {
		subscribe = true;
	}

	// Get the coupon to fix the price
	if (cval.length != 0 && discount.length != 0) {
		$.when(jak_coupon_validation(pid, cval, amount, subscribe, true)).done(function(data) {
			amount = data.newprice;
		});
		amount = discount;
	}

	var stripe_amount = amount*100;

	e.preventDefault();
	var handler = StripeCheckout.configure({
		key: '<?php echo $sett["stripepublic"];?>',
		image: 'payment/img/stripe_logo.png',
		locale: 'auto',
		token: function(token) {
			// You can access the token ID with `token.id`.
			// Get the token ID to your server-side code for use.
			$("#stripeToken").val(token.id);
			$("#stripeEmail").val(token.email);
			var utok = $("input#stripeToken").val();
			var uemail = $("input#stripeEmail").val();

			if (!utok){ 
				return false; 
			} else {
						        		
				$.ajax({
					url: "<?php echo $_SERVER['REQUEST_URI'];?>",
					type: "POST",
					data: "check=paymember&paidhow=stripe&token="+utok+"&email="+uemail+"&pid="+pid+"&cval="+cval+"&sub="+subscribe,
					dataType: "json",
					cache: false
				}).done(function(data) {
							        			
					if (data.status == 1) {
						$.notify({message: data.infomsg}, {type:'success'});
						$('#trialmsg, #expiredmsg').hide();
						$('#memberdate').html(data.date);
						// Finally redirect after 5 seconds
						window.setTimeout(function() {
					        // Move to a new location or you can do something else
					        window.location = '<?php echo BASE_URL;?>';
					    }, 5000);
					} else if (data.status == 2) {
						$.notify({message: data.infomsg}, {type:'success'});
						$('#trialmsg, #expiredmsg').hide();
					} else if (data.status == 3) {
						$.notify({message: data.infomsg}, {type:'success'});
					} else {
						$.notify({message: data.infomsg}, {type:'danger'});
					}
				});

			}
		}
	});

	// Open Checkout with further options:
	handler.open({
		name: ptitle,
		description: pdesc,
		email: '<?php echo $jakuser->getVar("email");?>',
		amount: parseInt(stripe_amount),
		currency: '<?php echo strtolower($sett["currency"]);?>',
		closed: function () {
			$(_this).find(".jak-loadbtn").removeClass("fa fa-spinner fa-spin");
        }
	});
});

// Extend operator accounts
$('#new-op-stripe').on('click', function(e) {

	$(this).find(".jak-loadbtn").addClass("fa fa-spinner fa-spin");

	// This
	var _this = $(this);

	// Get the amount of operators to add
	var ops = $("#newops").find(':selected').val();

	// Get the price
	var amount = $("#newops").find(':selected').data("price");

	var stripe_amount = amount*100;

	e.preventDefault();
	var handler = StripeCheckout.configure({
		key: '<?php echo $sett["stripepublic"];?>',
		image: 'payment/img/stripe_logo.png',
		locale: 'auto',
		token: function(token) {
			// You can access the token ID with `token.id`.
			// Get the token ID to your server-side code for use.
			$("#stripeToken").val(token.id);
			$("#stripeEmail").val(token.email);
			var utok = $("input#stripeToken").val();
			var uemail = $("input#stripeEmail").val();

			if (!utok){ 
				return false; 
			} else {
						        		
				$.ajax({
					url: "<?php echo $_SERVER['REQUEST_URI'];?>",
					type: "POST",
					data: "check=newop&paidhow=stripe&token="+utok+"&email="+uemail+"&ops="+ops,
					dataType: "json",
					cache: false
				}).done(function(data) {
							        			
					if (data.status == 1) {
						window.location = '<?php echo BASE_URL;?>';
					} else {
						$.notify({message: data.infomsg}, {type:'danger'});
					}
				});

			}
		}
	});

	// Open Checkout with further options:
	handler.open({
		name: '<?php echo JAK_TITLE;?>',
		description: '<?php echo $jkl["i55"];?>',
		email: '<?php echo $jakuser->getVar("email");?>',
		amount: parseInt(stripe_amount),
		currency: '<?php echo strtolower($sett["currency"]);?>',
		closed: function () {
			$(_this).find(".jak-loadbtn").removeClass("fa fa-spinner fa-spin");
        }
	});
});

// Extend operator accounts
$('.stripe-op').on('click', function(e) {

	$(this).find(".jak-loadbtn").addClass("fa fa-spinner fa-spin");

	// This
	var _this = $(this);

	// Get the operator to update
	var opid = $("#extop").find(':selected').data("opid");

	// Get the price
	var amount = $("#extop").find(':selected').data("price");

	// Get the months
	var extmonths = $("#extop").val();

	var stripe_amount = amount*100;

	e.preventDefault();
	var handler = StripeCheckout.configure({
		key: '<?php echo $sett["stripepublic"];?>',
		image: 'payment/img/stripe_logo.png',
		locale: 'auto',
		token: function(token) {
			// You can access the token ID with `token.id`.
			// Get the token ID to your server-side code for use.
			$("#stripeToken").val(token.id);
			$("#stripeEmail").val(token.email);
			var utok = $("input#stripeToken").val();
			var uemail = $("input#stripeEmail").val();

			if (!utok){ 
				return false; 
			} else {
						        		
				$.ajax({
					url: "<?php echo $_SERVER['REQUEST_URI'];?>",
					type: "POST",
					data: "check=opextend&paidhow=stripe&token="+utok+"&email="+uemail+"&months="+extmonths+"&opid="+opid,
					dataType: "json",
					cache: false
				}).done(function(data) {
							        			
					if (data.status == 1) {
						$.notify({message: data.infomsg}, {type:'success'});
						$('#opexpire'+opid).html(data.date);
						$('#opid'+opid).removeClass("table-danger");
					} else {
						$.notify({message: data.infomsg}, {type:'danger'});
					}
				});

			}
		}
	});

	// Open Checkout with further options:
	handler.open({
		name: '<?php echo JAK_TITLE;?>',
		description: '<?php echo $jkl["i54"];?>',
		email: '<?php echo $jakuser->getVar("email");?>',
		amount: parseInt(stripe_amount),
		currency: '<?php echo strtolower($sett["currency"]);?>',
		closed: function () {
			$(_this).find(".jak-loadbtn").removeClass("fa fa-spinner fa-spin");
        }
	});
});

// Extend Membership
$('.paypal').on('click', function(e) {

	e.preventDefault();

	$(this).find(".jak-loadbtn").addClass("fa fa-spinner fa-spin");

	var subscribe = false;
	var _this = $(this);
	var pid = $(this).data("package");
	var amount = $(this).data("amount");
	var discount = $("#discount-"+pid).val();
	var currency = $(this).data("currency");
	var cval = $("#coupon-"+pid).val();

	// Get the coupon to fix the price
	if (cval.length != 0 && discount.length != 0) {
		$.when(jak_coupon_validation(pid, cval, amount, subscribe, true)).done(function(data) {
			amount = data.newprice;
		});
		amount = discount;
	}

	$.ajax({
		url: "<?php echo $_SERVER['REQUEST_URI'];?>",
		type: "POST",
		data: "check=paymember&paidhow=paypal&pid="+pid+"&cval="+cval,
		dataType: "json",
		cache: false
	}).done(function(data) {
							        			
		if (data.status == 1) {
			$("#paypal_form").html(data.content);
			$('#gateway_form').submit();
		} else {
			$(_this).find(".jak-loadbtn").removeClass("fa fa-spinner fa-spin");
			$.notify({message: data.infomsg}, {type:'danger'});
		}
	});

});

// Extend Membership
$('.twoco').on('click', function(e) {

	e.preventDefault();

	$(this).find(".jak-loadbtn").addClass("fa fa-spinner fa-spin");

	var subscribe = false;
	var _this = $(this);
	var pid = $(this).data("package");
	var amount = $(this).data("amount");
	var discount = $("#discount-"+pid).val();
	var currency = $(this).data("currency");
	var cval = $("#coupon-"+pid).val();

	// Get the coupon to fix the price
	if (cval.length != 0 && discount.length != 0) {
		$.when(jak_coupon_validation(pid, cval, amount, subscribe, true)).done(function(data) {
			amount = data.newprice;
		});
		amount = discount;
	}

	$.ajax({
		url: "<?php echo $_SERVER['REQUEST_URI'];?>",
		type: "POST",
		data: "check=paymember&paidhow=twoco&pid="+pid+"&cval="+cval,
		dataType: "json",
		cache: false
	}).done(function(data) {
							        			
		if (data.status == 1) {
			$("#paypal_form").html(data.content);
			$('#gateway_form').submit();
		} else {
			$(_this).find(".jak-loadbtn").removeClass("fa fa-spinner fa-spin");
			$.notify({message: data.infomsg}, {type:'danger'});
		}
	});

});

// Extend Membership
$('.free-access').on('click', function(e) {

	e.preventDefault();

	$(this).find(".jak-loadbtn").addClass("fa fa-spinner fa-spin");

	var subscribe = false;
	var _this = $(this);
	var pid = $(this).data("package");
	var amount = $(this).data("amount");
	var discount = $("#discount-"+pid).val();
	var currency = $(this).data("currency");
	var cval = $("#coupon-"+pid).val();

	$.ajax({
		url: "<?php echo $_SERVER['REQUEST_URI'];?>",
		type: "POST",
		data: "check=paymember&paidhow=freeaccess&pid="+pid+"&cval="+cval,
		dataType: "json",
		cache: false
	}).done(function(data) {

		$(_this).find(".jak-loadbtn").removeClass("fa fa-spinner fa-spin");
							        			
		if (data.status == 1) {
			$.notify({message: data.infomsg}, {type:'success'});
			$('#trialmsg, #expiredmsg').hide();
			$('#memberdate').html(data.date);
			// Finally redirect after 5 seconds
			window.setTimeout(function() {
				// Move to a new location or you can do something else
				window.location = '<?php echo BASE_URL;?>';
			}, 5000);

		} else {
			$.notify({message: data.infomsg}, {type:'danger'});
		}
	});

});

// New Operators
$('#new-op-paypal').on('click', function(e) {

	e.preventDefault();

	$(this).find(".jak-loadbtn").addClass("fa fa-spinner fa-spin");

	// This
	var _this = $(this);

	// Get the amount of operators to add
	var ops = $("#newops").find(':selected').val();

	// Get the months
	var extmonths = $("#extop").val();

	$.ajax({
		url: "<?php echo $_SERVER['REQUEST_URI'];?>",
		type: "POST",
		data: "check=newop&paidhow=paypal&ops="+ops,
		dataType: "json",
		cache: false
	}).done(function(data) {
							        			
		if (data.status == 1) {
			$("#paypal_form").html(data.content);
			$('#gateway_form').submit();
		} else {
			$(_this).find(".jak-loadbtn").removeClass("fa fa-spinner fa-spin");
			$.notify({message: data.infomsg}, {type:'danger'});
		}
	});

});

// New Operators
$('#new-op-twoco').on('click', function(e) {

	e.preventDefault();

	$(this).find(".jak-loadbtn").addClass("fa fa-spinner fa-spin");

	// This
	var _this = $(this);

	// Get the amount of operators to add
	var ops = $("#newops").find(':selected').val();

	// Get the months
	var extmonths = $("#extop").val();

	$.ajax({
		url: "<?php echo $_SERVER['REQUEST_URI'];?>",
		type: "POST",
		data: "check=newop&paidhow=twoco&ops="+ops,
		dataType: "json",
		cache: false
	}).done(function(data) {
							        			
		if (data.status == 1) {
			$("#paypal_form").html(data.content);
			$('#gateway_form').submit();
		} else {
			$(_this).find(".jak-loadbtn").removeClass("fa fa-spinner fa-spin");
			$.notify({message: data.infomsg}, {type:'danger'});
		}
	});

});

// Extend Operator access
$('.paypal-op').on('click', function(e) {

	e.preventDefault();

	$(this).find(".jak-loadbtn").addClass("fa fa-spinner fa-spin");

	// This
	var _this = $(this);

	// Get the operator to update
	var opid = $("#extop").find(':selected').data("opid");

	// Get the months
	var extmonths = $("#extop").val();

	$.ajax({
		url: "<?php echo $_SERVER['REQUEST_URI'];?>",
		type: "POST",
		data: "check=opextend&paidhow=paypal&months="+extmonths+"&opid="+opid,
		dataType: "json",
		cache: false
	}).done(function(data) {
							        			
		if (data.status == 1) {
			$("#paypal_form").html(data.content);
			$('#gateway_form').submit();
		} else {
			$(_this).find(".jak-loadbtn").removeClass("fa fa-spinner fa-spin");
			$.notify({message: data.infomsg}, {type:'danger'});
		}
	});

});

// Extend Operator access
$('.twoco-op').on('click', function(e) {

	e.preventDefault();

	$(this).find(".jak-loadbtn").addClass("fa fa-spinner fa-spin");

	// This
	var _this = $(this);

	// Get the operator to update
	var opid = $("#extop").find(':selected').data("opid");

	// Get the months
	var extmonths = $("#extop").val();

	$.ajax({
		url: "<?php echo $_SERVER['REQUEST_URI'];?>",
		type: "POST",
		data: "check=opextend&paidhow=twoco&months="+extmonths+"&opid="+opid,
		dataType: "json",
		cache: false
	}).done(function(data) {
							        			
		if (data.status == 1) {
			$("#paypal_form").html(data.content);
			$('#gateway_form').submit();
		} else {
			$(_this).find(".jak-loadbtn").removeClass("fa fa-spinner fa-spin");
			$.notify({message: data.infomsg}, {type:'danger'});
		}
	});

});

function jak_coupon_validation(id, value, amount, subscribe, checkout) {

	//send the post to .php
	return $.ajax({
		url: "<?php echo $_SERVER['REQUEST_URI'];?>",
		type: "POST",
		data: "check=coupon&pid=" + id + "&coupon=" + value + "&amount=" + amount + "&subscribe=" + subscribe + "&checkout=" + checkout,
		dataType: "json",
		cache: false
	}).done(function(data) {

		if (checkout) {
			if (data.status == 1) {
				return data;
			} else if (data.status == 2) {
				window.location = data.redirect;
			} else {
				$("#coupon-help-"+id).removeClass('text-success').addClass("text-danger").html(data.ctext);
				return false;
			}
		} else {
			if (data.status == 1) {
				$("#discount-"+id).val(data.newprice);
				$("#price-"+id).html(data.newprice);
				$("#coupon-help-"+id).removeClass('text-danger').addClass("text-success").html(data.ctext);
			} else {
				$("#coupon-help-"+id).removeClass('text-success').addClass("text-danger").html(data.ctext);
			}
			return true;
		}
 	});
}
ls.main_url = "<?php echo BASE_URL_ADMIN;?>";
ls.orig_main_url = "<?php echo BASE_URL_ORIG;?>";
ls.main_lang = "<?php echo JAK_LANG;?>";
</script>