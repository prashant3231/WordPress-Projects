<?php include_once 'header.php';?>

<?php if ($addmuser && jak_get_access("usrmanage", $jakuser->getVar("permissions"))) { ?>
<p><a class="btn btn-primary" href="<?php echo JAK_rewrite::jakParseurl('users', 'new');?>"><?php echo $jkl["m7"];?></a></p>
<?php } ?>

<?php if (!$addmuser && jak_get_access("usrmanage", $jakuser->getVar("permissions"), JAK_MAIN_OP)) { ?>
<div class="alert alert-info"><?php echo sprintf($jkl['i14'], $totalAll, $totalavops, $jkl['m4']);?></div>
<?php } ?>

<form method="post" class="jak_form" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
<div class="box">
<div class="box-body no-padding">

<div class="table-responsive">
<table class="table table-striped">
<thead>
<tr>
<th><?php echo $jkl["u"];?></th>
<th><?php echo $jkl["u1"];?></th>
<th><?php echo $jkl["u2"];?></th>
<th></th>
</thead>
<?php if (isset($JAK_USER_ALL) && is_array($JAK_USER_ALL)) foreach($JAK_USER_ALL as $v) { ?>
<tr>
<td><a href="<?php echo JAK_rewrite::jakParseurl('users', 'edit', $v["id"], $v["opid"]);?>"><?php echo $v["name"]; if ($v["extraop"]) echo ' <i class="fa fa-plus"></i>';?></a></td>
<td><?php echo $v["email"];?></td>
<td><a href="<?php echo JAK_rewrite::jakParseurl('users', 'edit', $v["id"], $v["opid"]);?>"><?php echo $v["username"];?></a></td>
<td><a class="btn btn-default btn-sm btn-modal" data-toggle="modal" href="<?php echo JAK_rewrite::jakParseurl('users', 'stats', $v["id"], $v["username"]);?>" data-target="#jakModal"><i class="fa fa-signal"></i></a></td>
<?php } ?>
</table>
</div>

</div>
</div>
<input type="hidden" name="action" id="action">
</form>

<?php if (isset($JAK_PAGINATE)) echo $JAK_PAGINATE;?>
		
<?php include_once 'footer.php';?>