<?php include_once 'header.php';?>

<?php if (JAK_SHOW_IPS) { ?>
	<div class="box">
		<div class="box-header with-border">
			<h3 class="box-title"><?php echo $jkl["g177"];?> (<span class="currentlyonline">0</span>)</h3>
		</div><!-- /.box-header -->
		<div class="box-body">
			<div id="map_canvas"></div>
		</div>
	</div>
<?php } ?>

<div class="box">
	<div class="box-header with-border">
		<h3 class="box-title"><?php echo $jkl["g177"];?> (<span class="currentlyonline">0</span>)</h3>
	</div><!-- /.box-header -->
	<div class="box-body">
		<div id="userOnline"></div>
	</div>
</div>

<?php if (isset($UONLINE_ALL) && is_array($UONLINE_ALL)) { ?>

	<div class="box">
		<div class="box-header with-border">
			<h3 class="box-title"><?php echo $jkl["g105"].' ('.$totalAll.')';?></h3>
		</div><!-- /.box-header -->
		<div class="box-body">
			<div class="table-responsive">
				<table class="table table-striped w-100 d-block d-md-table">
					<tr>
						<th>#</th>
						<th><?php echo $jkl["g224"];?></th>
						<th><?php echo $jkl["g169"];?></th>
						<th><?php echo $jkl["g171"];?></th>
						<th><?php echo $jkl["g172"];?></th>
						<th><?php echo $jkl["g11"];?></th>
						<th><?php echo $jkl["g173"];?></th>
						<th><?php echo $jkl["g174"];?></th>
					</tr>
				</thead>
				<?php foreach($UONLINE_ALL as $v) { ?>
					<tr>
						<td><?php echo $v["id"];?></td>
						<td><img src="<?php echo BASE_URL;?>img/blank.png" class="flag-big flag-<?php echo $v['countrycode'];?>" title="<?php echo $v['country'];?>" alt="<?php echo $v['country'];?>"></td>
						<td><strong><?php echo $jkl["g169"].':</strong> '.$v["referrer"];?></strong><br><?php echo $jkl["g170"].':</strong> '.$v["firstreferrer"];?></td>
						<td><?php echo $v["agent"];?></td>
						<td><?php echo $v["hits"];?></td>
						<td><?php echo $v["ip"];?></a></td>
						<td><?php echo JAK_base::jakTimesince($v['time'], JAK_DATEFORMAT, JAK_TIMEFORMAT);?></td>
						<td><?php echo JAK_base::jakTimesince($v['lasttime'], JAK_DATEFORMAT, JAK_TIMEFORMAT);?></td>
					</tr>
				<?php } ?>
			</table>
		</div>
	</div>
</div>

<?php if ($JAK_PAGINATE) { ?>
	<div class="pagination">
		<?php echo $JAK_PAGINATE;?>
	</div>
<?php } } ?>

<?php include_once 'footer.php';?>