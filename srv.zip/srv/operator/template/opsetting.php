<?php include_once 'header.php';?>

<?php if ($errors) { ?>
<div class="alert alert-danger">
<?php if (isset($errors["e"])) echo $errors["e"];
	  if (isset($errors["e1"])) echo $errors["e1"];
	  if (isset($errors["e2"])) echo $errors["e2"];
	  if (isset($errors["e3"])) echo $errors["e3"];?>
</div>
<?php } if ($success) { ?>
<div class="alert alert-success">
	<?php if (isset($success["e"])) echo $success["e"];?>
</div>
<?php } ?>
<form method="post" class="jak_form" action="<?php echo $_SERVER['REQUEST_URI']; ?>">

<div class="row">
	<div class="col-md-6">
		<div class="box box-primary">
		<div class="box-header with-border">
		  <h3 class="box-title"><?php echo $jkl["g15"];?></h3>
		</div><!-- /.box-header -->
		<div class="box-body">
		<div class="table-responsive">
		<table class="table table-striped">
		<tr>
			<td><?php echo $jkl["g303"];?></td>
			<td><div class="radio"><label><input type="radio" name="jak_holidaym" value="0"<?php if ($jakopsett['holiday_mode'] == 0) { ?> checked="checked"<?php } ?>> <?php echo $jkl["g304"];?></label></div>
			<div class="radio"><label><input type="radio" name="jak_holidaym" value="1"<?php if ($jakopsett['holiday_mode'] == 1) { ?> checked="checked"<?php } ?>> <?php echo $jkl["g1"];?></label></div>
			<div class="radio"><label><input type="radio" name="jak_holidaym" value="2"<?php if ($jakopsett['holiday_mode'] == 2) { ?> checked="checked"<?php } ?>> <?php echo $jkl["g305"];?></label></div></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g16"];?></td>
			<td><input type="text" name="jak_title" class="form-control" value="<?php echo $jakopsett['title'];?>" placeholder="<?php echo $jkl["g16"];?>"></td>
		</tr>
		<tr>
			<td><?php echo $jkl["l5"];?> <a href="javascript:void(0)" class="jakweb-help" data-content="<?php echo $jkl["h"];?>" data-original-title="<?php echo $jkl["t"];?>"><i class="fa fa-question-circle"></i></a></td>
			<td>
			<div class="form-group<?php if (isset($errors["e1"])) echo " has-danger";?>">
				<input type="text" name="jak_email" class="form-control" value="<?php echo $jakopsett['email'];?>" placeholder="<?php echo $jkl["l5"];?>">
			</div>
			</td>
		</tr>
		<tr>
			<td><?php echo $jkl["g22"];?></td>
			<td><select name="jak_lang" class="form-control">
			<?php if (isset($lang_files) && is_array($lang_files)) foreach($lang_files as $lf) { ?><option value="<?php echo $lf;?>"<?php if ($jakopsett['lang'] == $lf) { ?> selected="selected"<?php } ?>><?php echo $lf;?></option><?php } ?>
			</select></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g23"];?></td>
			<td>
			<div class="form-group">
				<input type="text" name="jak_date" class="form-control" value="<?php echo $jakopsett['dateformat'];?>">
			</div>
			</td>
		</tr>
		<tr>
			<td><?php echo $jkl["g24"];?></td>
			<td>
			<div class="form-group">
				<input type="text" name="jak_time" class="form-control" value="<?php echo $jakopsett['timeformat']?>">
			</div>
			</td>
		</tr>
		<tr>
			<td><?php echo $jkl["g25"];?></td>
			<td><select name="jak_timezone" class="form-control">
			<?php include_once "timezoneserver2.php";?>
			</select></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g256"];?></td>
			<td><select name="jak_ringtone" class="form-control play-tone">
			<?php if (isset($sound_files) && is_array($sound_files)) foreach($sound_files as $sfc) { ?><option value="<?php echo $sfc;?>"<?php if ($jakopsett['newclient'] == $sfc) { ?> selected="selected"<?php } ?>><?php echo $sfc;?></option><?php } ?>
			</select></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g257"];?></td>
			<td><select name="jak_msgtone" class="form-control play-tone">
			<?php if (isset($sound_files) && is_array($sound_files)) foreach($sound_files as $sfn) { ?><option value="<?php echo $sfn;?>"<?php if ($jakopsett['newmsg'] == $sfn) { ?> selected="selected"<?php } ?>><?php echo $sfn;?></option><?php } ?>
			</select></td>
		</tr>
		</table>
		</div>
		</div>
		<div class="box-footer">
			<button type="submit" name="save" class="btn btn-primary pull-right"><?php echo $jkl["g38"];?></button>
		</div>
		</div>

		<div class="box box-info">
		<div class="box-header with-border">
		  <h3 class="box-title"><?php echo $jkl["g318"];?></h3>
		</div><!-- /.box-header -->
		<div class="box-body">
		<div class="table-responsive">
		<table class="table table-striped">
		<tr>
			<td><?php echo $jkl["g257"];?></td>
			<td><select name="jak_client_sound" class="form-control play-tone">
			<option value=""<?php if (empty($jakopsett['clientsound'])) echo ' selected="selected"';?>><?php echo $jkl['bw4'];?></option>
			<?php if (isset($sound_files) && is_array($sound_files)) foreach($sound_files as $sfc) { ?><option value="<?php echo $sfc;?>"<?php if ($jakopsett['clientsound'] == $sfc) { ?> selected="selected"<?php } ?>><?php echo $sfc;?></option><?php } ?>
			</select></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g316"];?></td>
			<td><select name="jak_engage_sound" class="form-control play-tone">
			<option value=""<?php if (empty($jakopsett['soundalert'])) echo ' selected="selected"';?>><?php echo $jkl['bw4'];?></option>
			<?php if (isset($sound_files) && is_array($sound_files)) foreach($sound_files as $sfc) { ?><option value="<?php echo $sfc;?>"<?php if ($jakopsett['soundalert'] == $sfc) { ?> selected="selected"<?php } ?>><?php echo $sfc;?></option><?php } ?>
			</select></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g191"];?></td>
			<td><div class="radio"><label><input type="radio" name="showalert" value="1"<?php if ($jakopsett['showalert'] == 1) { ?> checked<?php } ?>> <?php echo $jkl["g19"];?></label></div>
			<div class="radio"><label>
			  <input type="radio" name="showalert" value="0"<?php if ($jakopsett['showalert'] == 0) { ?> checked<?php } ?>> <?php echo $jkl["g18"];?>
			</label></div>
			</td>
		</tr>
		<tr>
			<td><?php echo $jkl["stat_s12"];?></td>
			<td><div class="radio"><label><input type="radio" name="jak_feedback" value="1"<?php if ($jakopsett['feedback'] == 1) { ?> checked="checked"<?php } ?>> <?php echo $jkl["g19"];?></label></div>
			<div class="radio"><label><input type="radio" name="jak_feedback" value="0"<?php if ($jakopsett['feedback'] == 0) { ?> checked="checked"<?php } ?>> <?php echo $jkl["g18"];?></label></div></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g234"];?></td>
			<td><div class="radio"><label><input type="radio" name="jak_trans" value="1"<?php if ($jakopsett['sendtrans'] == 1) { ?> checked="checked"<?php } ?>> <?php echo $jkl["g19"];?></label></div>
			<div class="radio"><label><input type="radio" name="jak_trans" value="0"<?php if ($jakopsett['sendtrans'] == 0) { ?> checked="checked"<?php } ?>> <?php echo $jkl["g18"];?></label></div></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g92"];?></td>
			<td><div class="radio"><label><input type="radio" name="jak_rating" value="1"<?php if ($jakopsett['ratings'] == 1) { ?> checked="checked"<?php } ?>> <?php echo $jkl["g19"];?></label></div>
			<div class="radio"><label><input type="radio" name="jak_rating" value="0"<?php if ($jakopsett['ratings'] == 0) { ?> checked="checked"<?php } ?>> <?php echo $jkl["g18"];?></label></div></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g190"];?></td>
			<td><div class="radio"><label><input type="radio" name="jak_contactredi" value="1"<?php if ($jakopsett['contactredi'] == 1) { ?> checked="checked"<?php } ?>> <?php echo $jkl["g19"];?></label></div>
			<div class="radio"><label><input type="radio" name="jak_contactredi" value="0"<?php if ($jakopsett['contactredi'] == 0) { ?> checked="checked"<?php } ?>> <?php echo $jkl["g18"];?></label></div></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g252"];?></td>
			<td><input type="number" name="jak_redi_contact" class="form-control" min="1" max="30" step="1" value="<?php echo $jakopsett['contacttime'];?>"></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g238"];?></td>
			<td><input type="text" name="url_red" class="form-control" value="<?php echo $jakopsett['contacturl'];?>" placeholder="https://www.yourdomain.com/contactform"></td>
		</tr>
		<tr>
			<td>EU-DSGVO</td>
			<td><textarea name="jak_dsgvo" class="form-control" rows="3"><?php echo $jakopsett['dsgvo'];?></textarea></td>
		</tr>
		</table>
		</div>
		</div>
		<div class="box-footer">
			<button type="submit" name="save" class="btn btn-primary pull-right"><?php echo $jkl["g38"];?></button>
		</div>
		</div>

	</div>
	<div class="col-md-6">
		
		<div class="box">
		<div class="box-header with-border">
		  <h3 class="box-title"><?php echo $jkl["g212"];?></h3>
		</div><!-- /.box-header -->
		<div class="box-body">
		<div class="table-responsive">
		<table class="table table-striped">
		<tr>
			<td><?php echo $jkl["g212"];?></td>
			<td><div class="radio"><label><input type="radio" name="jak_smpt" value="0"<?php if ($jakopsett['emailprotocol'] == 0) { ?> checked="checked"<?php } ?> /> <?php echo $jkl["g204"];?></label></div>
			<div class="radio"><label><input type="radio" name="jak_smpt" value="1"<?php if ($jakopsett['emailprotocol'] == 1) { ?> checked="checked"<?php } ?> /> <?php echo $jkl["g205"];?></label></div></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g206"];?></td>
			<td><input type="text" class="form-control" name="jak_host" value="<?php echo $jakopsett['smtphost'];?>"></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g207"];?></td>
			<td>
			<div class="form-group<?php if ($errors["e2"]) echo " has-danger";?>">
				<input type="text" name="jak_port" class="form-control" value="<?php echo $jakopsett['smtpport']?>" placeholder="25">
			</div></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g208"];?></td>
			<td><div class="radio"><label><input type="radio" name="jak_alive" value="1"<?php if ($jakopsett['smtpalive'] == 1) { ?> checked="checked"<?php } ?> /> <?php echo $jkl["g19"];?></label></div>
			<div class="radio"><label><input type="radio" name="jak_alive" value="0"<?php if ($jakopsett['smtpalive'] == 0) { ?> checked="checked"<?php } ?> /> <?php echo $jkl["g18"];?></label></div></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g209"];?></td>
			<td><div class="radio"><label><input type="radio" name="jak_auth" value="1"<?php if ($jakopsett['smtpauth'] == 1) { ?> checked="checked"<?php } ?> /> <?php echo $jkl["g19"];?></label></div>
			<div class="radio"><label><input type="radio" name="jak_auth" value="0"<?php if ($jakopsett['smtpauth'] == 0) { ?> checked="checked"<?php } ?> /> <?php echo $jkl["g18"];?></label></div></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g219"];?></td>
			<td>
			<input type="text" name="jak_prefix" class="form-control" value="<?php echo $jakopsett['smtpprefix'];?>" placeholder="ssl/tls/true/false">
			</td>
		</tr>
		<tr>
			<td><?php echo $jkl["g210"];?></td>
			<td><input type="text" name="jak_smtpusername" class="form-control" value="<?php echo $jakopsett['smtpuser'];?>" autocomplete="off"></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g211"];?></td>
			<td><input type="password" name="jak_smtppassword" class="form-control" value="<?php echo $jakopsett['smtppass'];?>" autocomplete="off"></td>
		</tr>
		<tr>
			<td><?php echo $jkl["g218"];?></td>
			<td><button type="submit" name="testMail" class="btn btn-success" id="sendTM"><i id="loader" class="fa fa-spinner fa-pulse"></i> <?php echo $jkl["g216"];?></button></td>
		</tr>
		</table>
		</div>
		</div>
		<div class="box-footer">
			<button type="submit" name="save" class="btn btn-primary pull-right"><?php echo $jkl["g38"];?></button>
		</div>
		</div>
	</div>
</div>

</form>

<?php include_once 'footer.php';?>