<?php

/*===============================================*\
|| ############################################# ||
|| # JAKWEB.CH / Version 2.4.4                 # ||
|| # ----------------------------------------- # ||
|| # Copyright 2019 JAKWEB All Rights Reserved # ||
|| ############################################# ||
\*===============================================*/

// Check if the file is accessed only via index.php if not stop the script from running
if (!defined('JAK_ADMIN_PREVENT_ACCESS')) die('You cannot access this file directly.');

// Check if the user has access to this file
if (!JAK_ADMINACCESS) jak_redirect(BASE_URL);

// All the tables we need for this plugin
$errors = array();
$jaktable = 'user';
$jaktable1 = 'user_stats';
$jaktable2 = 'departments';

$insert = '';
$updatepass = $addmuser = false;
$totalavops = (!empty($jakosub) ? $jakosub['operators'] + $jakosub['extraoperators'] : 0);

// Change for 1.0.3
use JAKWEB\JAKsql;

// Now start with the plugin use a switch to access all pages
switch ($page1) {

	// Create new user
	case 'new':

		// No special access, so what you doing here?
		if (!jak_get_access("usrmanage", $jakuser->getVar("permissions"))) jak_redirect(BASE_URL);

		// Let's check if we can add more users
		$totalops = $jakdb->count($jaktable, ["opid" => JAK_USERID]);
		if ($totalavops > $totalops) $addmuser = true;
		
		// No special access, so what you doing here?
		if (!$addmuser) jak_redirect(BASE_URL);
		
		// Get all departments
		$JAK_DEPARTMENTS = $jakdb->select($jaktable2, ["id", "title"], ["opid" => $opcacheid, "ORDER" => ["dorder" => "ASC"]]);
		
		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		    $jkp = $_POST;
		
		    if (empty($jkp['jak_name'])) {
		        $errors['e1'] = $jkl['e7'];
		    }
		    
		    if ($jkp['jak_email'] == '' || !filter_var($jkp['jak_email'], FILTER_VALIDATE_EMAIL)) {
		        $errors['e2'] = $jkl['e3'];
		    }

		    if (jak_field_not_exist(strtolower($jkp['jak_email']), $jaktable, "email")) {
		        $errors['e2'] = $jkl['e18'];
		    }
		    
		    if (!preg_match('/^([a-zA-Z0-9\-_])+$/', $jkp['jak_username'])) {
		    	$errors['e3'] = $jkl['e8'];
		    }
		    
		    if (jak_field_not_exist(strtolower($jkp['jak_username']), $jaktable, "username")) {
		        $errors['e4'] = $jkl['e9'];
		    }
		     
		    if ($jkp['jak_password'] != $jkp['jak_confirm_password']) {
		    	$errors['e5'] = $jkl['e10'];
		    } elseif (strlen($jkp['jak_password']) <= '7') {
		    	$errors['e6'] = $jkl['e11'];
		    } else {
		    	$updatepass = true;
		    }
		    
		    if (count($errors) == 0) {
		    
		    if (!isset($jkp['jak_depid'])) {
		    	$depa = 0;
		    } else {
		    	$depa = join(',', $jkp['jak_depid']);
		    }

		    // Reset
		    $opid = 0;
		    $validtill = '1980-05-06 00:00:00';
		    // what we have to add for the operator
		    if ($addmuser) {
				$opid = JAK_USERID;
				$totaleops = $jakdb->count($jaktable, ["AND" => ["opid" => JAK_USERID, "extraop" => 1]]);
				
				if ($totaleops < $jakosub['extraoperators']) {
					$date = new DateTime();
					// Modify the date
					$date->modify('+1 month');
					$validtill = $date->format('Y-m-d H:i:s');
					$extraop = 1;
				} else {
					$validtill = $jakosub['paidtill'];
					$extraop = 0;
				}
			}
		    
		    $tw_roles = '';
		    if (($addmuser) && $jkp['jak_roles'] && !empty($jkp['jak_roles'])) $tw_roles = join(',', $jkp['jak_roles']);

			$jakdb->insert($jaktable, [
				"opid" => $opid,
				"departments" => $depa,
				"password" => hash_hmac('sha256', $jkp['jak_password'], DB_PASS_HASH),
				"username" => trim($jkp['jak_username']),
				"name" => trim($jkp['jak_name']),
				"email" => filter_var($jkp['jak_email'], FILTER_SANITIZE_EMAIL),
				"responses" => $jkp['jak_responses'],
				"files" => $jkp['jak_files'],
				"operatorlist" => $jkp['jak_chatlist'],
				"transferc" => $jkp['jak_transfer'],
				"chat_latency" => $jkp['jak_latency'],
				"useronlinelist" => $jkp['jak_uolist'],
				"sound" => $jkp['jak_sound'],
				"ringing" => $jkp['jak_ringing'],
				"language" => $jkp['jak_lang'],
				"invitationmsg" => $jkp['jak_inv'],
				"permissions" => $tw_roles,
				"access" => $jkp['jak_access'],
				"validtill" => $validtill,
				"extraop" => $extraop,
				"time" => $jakdb->raw("NOW()")]);

			$lastid = $jakdb->id();
		
			if (!$lastid) {
		    	$_SESSION["errormsg"] = $jkl['i4'];
		    	jak_redirect($_SESSION['LCRedirect']);
			} else {
				$newuserpath = APP_PATH.JAK_FILES_DIRECTORY.'/'.$lastid;
				
				if (!is_dir($newuserpath)) {
					mkdir($newuserpath, 0755);
				    copy(APP_PATH.JAK_FILES_DIRECTORY."/index.html", $newuserpath."/index.html");
				}

				if (!$addmuser) {

					// Create the settings for the operator
					$jakdb->insert("op_settings", ["opid" => $lastid, "title" => "Live Chat", "email" => $jkp["email"], "lang" => JAK_LANG, "dateformat" => "d.m.Y ", "timeformat" => "g:i a", "newclient" => "files/package/standard/sound/birds", "newmsg" => "sound/new_message3", "clientsound" => "sound/hello", "soundalert" => "files/package/standard/sound/owl", "emailprotocol" => 0, "created" => $jakdb->raw("NOW()")]);

					// Insert the chat widget
					$jakdb->insert("chatwidget", ["opid" => $lastid, "title" => "Live Chat", "lang" => JAK_LANG, "widget" => 1, "slideup" => 1, "hideoff" => 0, "buttonimg" => "globe_on.png", "slideimg" => "chatnow_on.png", "floatpopup" => 0, "template" => "standard", "theme_colour" => "standard", "body_colour" => "#ffffff", "h_colour" => "#494949", "c_colour" => "#494949", "time_colour" => "#999999", "link_colour" => "#007ff5", "sidebar_colour" => "#857d7d", "h_font" => "Open+Sans", "c_font" => "Open+Sans", "created" => $jakdb->raw("NOW()")]);

					// Insert the department
                	$jakdb->insert("departments", ["opid" => $lastid, "title" => "My First Department", "description" => "Edit this department to your needs...", "active" => 1, "dorder" => 1, "time" => $jakdb->raw("NOW()")]);

					$jakdb->insert("answers", [["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Enters Chat", "message" => "%operator% enters the chat.", "fireup" => 15, "msgtype" => 2, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Expired", "message" => "This session has expired!", "fireup" => 15, "msgtype" => 4, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Ended", "message" => "%client% has ended the conversation", "fireup" => 15, "msgtype" => 3, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Welcome", "message" => "Welcome %client%, a representative will be with you shortly.", "fireup" => 15, "msgtype" => 5, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Leave", "message" => "has left the conversation.", "fireup" => 15, "msgtype" => 6, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Start Page", "message" => "Please insert your name to begin, a representative will be with you shortly.", "fireup" => 15, "msgtype" => 7, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Contact Page", "message" => "None of our representatives are available right now, although you are welcome to leave a message!", "fireup" => 15, "msgtype" => 8, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Feedback Page", "message" => "We would appreciate your feedback to improve our service.", "fireup" => 15, "msgtype" => 9, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "Quickstart Page", "message" => "Please type a message and hit enter to start the conversation.", "fireup" => 15, "msgtype" => 10, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "WhatsApp Online", "message" => "Please click on a operator below to connect via WhatsApp and get help immediately.", "fireup" => 15, "msgtype" => 26, "created" => $jakdb->raw("NOW()")],
                    ["opid" => $lastid, "department" => 0, "lang" => JAK_LANG, "title" => "WhatsApp Offline", "message" => "We are currently offline however please check below for available operators in WhatsApp, we try to help you as soon as possible.", "fireup" => 15, "msgtype" => 27, "created" => $jakdb->raw("NOW()")]]);

					// Now if we have multi site please update the main database.
					if (!empty(JAKDB_MAIN_NAME) && JAK_MAIN_LOC) {
						// Database connection to the main site
				        $jakdb1 = new JAKsql([
				            // required
				            'database_type' => JAKDB_MAIN_DBTYPE,
				            'database_name' => JAKDB_MAIN_NAME,
				            'server' => JAKDB_MAIN_HOST,
				            'username' => JAKDB_MAIN_USER,
				            'password' => JAKDB_MAIN_PASS,
				            'charset' => 'utf8',
				            'port' => JAKDB_MAIN_PORT,
				            'prefix' => JAKDB_MAIN_PREFIX,
				         
				            // [optional] driver_option for connection, read more from http://www.php.net/manual/en/pdo.setattribute.php
				            'option' => [PDO::ATTR_CASE => PDO::CASE_NATURAL]
				            ]);

				        // We get the settings for the payment
	        			$trialdaysett = $jakdb1->get("settings", "used_value", ["varname" => "trialdays"]);

	        			// Get the current date one week ago.
						$trialdays = date('Y-m-d H:i:s', strtotime("+".$trialdaysett." day"));

				        $jakdb1->insert("users", [ 
							"locationid" => JAK_MAIN_LOC,
							"opid" => $lastid,
							"email" => filter_var($jkp['jak_email'], FILTER_SANITIZE_EMAIL),
							"username" => trim($jkp['jak_username']),
							"password" => hash_hmac('sha256', $jkp['jak_password'], DB_PASS_HASH),
							"signup" => $jakdb->raw("NOW()"),
							"active" => 1,
							"trial" => $trialdays,
	            			"paidtill" => $trialdays,
	            			"lastedit" => $jakdb->raw("NOW()"),
	            			"welcomemsg" => 1]);
					}

				}

				$_SESSION["successmsg"] = $jkl['g14'];
		    	jak_redirect(JAK_rewrite::jakParseurl('users', 'edit', $lastid, JAK_USERID));
		 	}
		 
		 } else {
		    
		   	$errors['e'] = $jkl['e'];
		    $errors = $errors;
		 }
		}
		
		// Call the settings function
		$lang_files = jak_get_lang_files();
		
		// Title and Description
		$SECTION_TITLE = $jkl["m7"];
		$SECTION_DESC = "";
		
		// Include the javascript file for results
		$js_file_footer = 'js_edituser.php';
		
		// Call the template
		$template = 'newuser.php';
		
	break;
	case 'stats':
	
		// Let's go on with the script
			if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['email_feedback'])) {
			    $jkp = $_POST;
			    
			    // Errors in Array
			    $errors = array();
			    
			    if ($jkp['email'] == '' || !filter_var($jkp['email'], FILTER_VALIDATE_EMAIL)) {
			        $errors['email'] = $jkl['e3'];
			    }
			    
			    if (count($errors) > 0) {
			    
			    /* Outputtng the error messages */
			    	if (isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
			    	
			    		header('Cache-Control: no-cache');
			    		die('{"status":0, "errors":'.json_encode($errors).'}');
			    		
			    	} else {
			    	
			    		$errors = $errors;
			    	}
			    	
			    } else {

			    	$result = $jakdb->select($jaktable1, "*", ["userid" => $page2, "ORDER" => ["id" => "ASC"]]);

			    	$total_vote = $jakdb->sum($jaktable1, "vote", ["userid" => $page2]);
			    	$total_support = $jakdb->sum($jaktable1, "support_time", ["userid" => $page2]);
			    	
			    	$subject = $jkl["g81"].' '.$page3;
			    	
			    	$mailchat = '<div style="margin:10px 0px 0px 0px;padding:10px;border:1px solid #A8B9CB;font-family: Verdana, sans-serif;font-size: 13px;
			    	font-weight: 500;letter-spacing: normal;line-height: 1.5em;"><h2>'.$subject.'</h2><ul style="list-style:none;">';
			    	
			    	// Reset var
			    	$count = 0;
			    	if (isset($result) && !empty($result) && is_array($result)) foreach ($result as $row) {
			    		// collect each record into $_data
			    	    $mailchat .= '<li style="border-bottom:1px solid #333"><span style="font-size:11px">'.$row['time'].' - '.$jkl['g86'].':</span><br /><span style="color:#c92e2e">'.$jkl['g85'].': </span>'.$row['vote'].'/5<br />'.$jkl['g54'].': '.$row['name'].'<br />'.$jkl['stat_s12'].': '.$row['comment'].'<br />'.$jkl['l5'].': '.$row['email'].'<br />'.$jkl['g87'].': '.gmdate('H:i:s', $row['support_time']).'</li>';
			    	        	
			    	   $count++;
			    	}
			    	    
			    	$mailchat .= '</ul>';
			    	
			    	$mailchat .= '<h2>'.$jkl["g89"].'</h2>
			    	<p><strong>'.$jkl["g90"].':</strong> '.gmdate('H:i:s', $total_support).'<br /><strong>'.$jkl["g91"].':</strong> '.round(($total_vote / $count), 2).'/5</p></div>';
			    	
			    	$mail = new PHPMailer(); // defaults to using php "mail()"
			    	
			    	if (JAK_SMTP_MAIL) {
			    	
			    		$mail->IsSMTP(); // telling the class to use SMTP
			    		$mail->Host = JAK_SMTPHOST;
			    		$mail->SMTPAuth = (JAK_SMTP_AUTH ? true : false); // enable SMTP authentication
			    		$mail->SMTPSecure = JAK_SMTP_PREFIX; // sets the prefix to the server
			         	$mail->SMTPAutoTLS = false;
			    		$mail->SMTPKeepAlive = (JAK_SMTP_ALIVE ? true : false); // SMTP connection will not close after each email sent
			    		$mail->Port = JAK_SMTPPORT; // set the SMTP port for the GMAIL server
			    		$mail->Username = JAK_SMTPUSERNAME; // SMTP account username
			    		$mail->Password = JAK_SMTPPASSWORD; // SMTP account password
			    		$mail->SetFrom(JAK_EMAIL);
			    		$mail->AddAddress($jkp['email'], $jkp['email']);
			    		
			    	} else {
			    	
			    		$mail->SetFrom(JAK_EMAIL, $jkl["g92"]);
			    		$mail->AddAddress($jkp['email'], $jkp['email']);
			    	
			    	}
			    	
			    	$mail->Subject = $subject;
			    	$mail->MsgHTML($mailchat);
			    	
			    if ($mail->Send()) {
			    	
			    	// Ajax Request
			    	if (isset($_SERVER['HTTP_X_REQUESTED_WITH'])) {
			    	
			    		header('Cache-Control: no-cache');
			    		die(json_encode(array('status' => 1, 'html' => $jkl["g14"])));
			    		
			    	} else {
			    	
			            jak_redirect($_SERVER['HTTP_REFERER']);
			        
			        }
			    } 
			    
			}
		}
	
		// Check if the user exists
		if (is_numeric($page2) && jak_row_exist($page2, $jaktable)) {
		
			$USER_FEEDBACK = array();
			$USER_VOTES = $USER_SUPPORTT = '';

			$USER_FEEDBACK = $jakdb->select($jaktable1, "*", ["userid" => $page2, "ORDER" => ["id" => "ASC"]]);

			$USER_VOTES = $jakdb->sum($jaktable1, "vote", ["userid" => $page2]);
			$USER_SUPPORTT = $jakdb->sum($jaktable1, "support_time", ["userid" => $page2]);
		
		}
	
		// Call the template
		$template = 'userstats.php';
		 		
	break;
	case 'lock':
	
		if (jak_user_exist_deletable($page2)) {

			// Check what we have to do
			$datausrac = $jakdb->get($jaktable, "access", ["id" => $page2]);
			// update the table
			if ($datausrac) {
				$result = $jakdb->update($jaktable, ["access" => 0], ["id" => $page2]);
			} else {
				$result = $jakdb->update($jaktable, ["access" => 1], ["id" => $page2]);
			}

			if (!$result) {
		    	$_SESSION["infomsg"] = $jkl['i'];
		    	jak_redirect($_SESSION['LCRedirect']);
			} else {
			    $_SESSION["successmsg"] = $jkl['g14'];
			    jak_redirect($_SESSION['LCRedirect']);
			}
		
		} else {
		   	$_SESSION["infomsg"] = $jkl['i1'];
		    jak_redirect($_SESSION['LCRedirect']);
		}
		 		
	break;
	case 'edit':
		
		// No special access and not your userid, what you up to?
		if (!jak_get_access("usrmanage", $jakuser->getVar("permissions")) && ($page2 != JAK_USERID || $page3 != $opcacheid)) jak_redirect(BASE_URL);
		
		// Protect the super operators from user manager
		if (!jak_get_access("usrmanage", $jakuser->getVar("permissions")) && in_array($page2, explode(',', JAK_SUPERADMIN))) jak_redirect(BASE_URL);
	
		// Check if the user exists
		if (is_numeric($page2) && ($page2 == JAK_USERID || $page3 == $opcacheid) && jak_row_exist($page2,$jaktable)) {
		
			// Get all departments
			$JAK_DEPARTMENTS = $jakdb->select($jaktable2, ["id", "title"], ["opid" => $opcacheid, "ORDER" => ["dorder" => "ASC"]]);
		
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		    $jkp = $_POST;
		
		    if (empty($jkp['jak_name'])) {
		        $errors['e1'] = $jkl['e7'];
		    }
		    
		    if ($jkp['jak_email'] == '' || !filter_var($jkp['jak_email'], FILTER_VALIDATE_EMAIL)) {
		        $errors['e2'] = $jkl['e3'];
		    }

		    if (jak_field_not_exist_id($jkp['jak_email'], $page2, $jaktable, "email")) {
		        $errors['e2'] = $jkl['e18'];
		    }
		    
		    if (!preg_match('/^([a-zA-Z0-9\-_])+$/', $jkp['jak_username'])) {
		    	$errors['e3'] = $jkl['e8'];
		    }
		    
		    if (jak_field_not_exist_id($jkp['jak_username'], $page2, $jaktable, "username")) {
		        $errors['e4'] = $jkl['e9'];
		    }
		    
		    if (!empty($jkp['jak_password']) || !empty($jkp['jak_confirm_password'])) {    
		    if ($jkp['jak_password'] != $jkp['jak_confirm_password']) {
		    	$errors['e5'] = $jkl['e10'];
		    } elseif (strlen($jkp['jak_password']) <= '7') {
		    	$errors['e6'] = $jkl['e11'];
		    } else {
		    	$updatepass = true;
		    }
		    }
		    
		    // Delete Avatar if yes
		    if (!empty($jkp['jak_delete_avatar'])) {
			    $avatarpi = APP_PATH.JAK_FILES_DIRECTORY.'/index.html';
			    $avatarpid =  str_replace("//","/",$avatarpi);
			    $targetPath = APP_PATH.JAK_FILES_DIRECTORY.'/'.$page2.'/';
			    $removedouble =  str_replace("//","/",$targetPath);
			    foreach(glob($removedouble.'*.*') as $jak_unlink){
			        unlink($jak_unlink);
			        copy($avatarpid, $targetPath . "/index.html");
			    }
			    
			    $jakdb->update($jaktable, ["picture" => "/standard.jpg"], ["id" => $page2]);
		    
		    }
		    
		    if (!empty($_FILES['uploadpp']['name'])) {
		    
		    	if ($_FILES['uploadpp']['name'] != '') {
		    	
		    	$filename = $_FILES['uploadpp']['name']; // original filename
		    	// Fix explode when upload in 3.2
		    	$ls_xtension = pathinfo($filename);
		    	
		    	if ($ls_xtension['extension'] == "jpg" || $ls_xtension['extension'] == "jpeg" || $ls_xtension['extension'] == "png" || $ls_xtension['extension'] == "gif") {

		    	// Get the maximum upload or set to 2
				$postmax = (ini_get('post_max_size') ? filter_var(ini_get('post_max_size'), FILTER_SANITIZE_NUMBER_INT) : "2");
		    	
		    	if ($_FILES['uploadpp']['size'] <= ($postmax * 1000000)) {
		    	
		    	list($width, $height, $type, $attr) = getimagesize($_FILES['uploadpp']['tmp_name']);
		    	$mime = image_type_to_mime_type($type);
		    	
		    	if (($mime == "image/jpeg") || ($mime == "image/pjpeg") || ($mime == "image/png") || ($mime == "image/gif")) {
		    	
		    	// first get the target path
		    	$targetPathd = APP_PATH.JAK_FILES_DIRECTORY.'/'.$page2.'/';
		    	$targetPath =  str_replace("//","/",$targetPathd);

		    	// Create the target path
		    	if (!is_dir($targetPath)) {
		    		mkdir($targetPath, 0755);
		    	    copy(APP_PATH.JAK_FILES_DIRECTORY."/index.html", $targetPath . "/index.html");
		    	
		    	}

		    	// if old avatars exist delete it
		    	foreach(glob($targetPath.'*.*') as $jak_unlink){
		    	    unlink($jak_unlink);
		    	    copy(APP_PATH.JAK_FILES_DIRECTORY."/index.html", $targetPath . "/index.html");
		    	}
		    	
		    	$tempFile = $_FILES['uploadpp']['tmp_name'];
		    	$origName = substr($_FILES['uploadpp']['name'], 0, -4);
		    	$name_space = strtolower($_FILES['uploadpp']['name']);
		    	$middle_name = str_replace(" ", "_", $name_space);
		    	$middle_name = str_replace(".jpeg", ".jpg", $name_space);
		    	$glnrrand = rand(10, 99);
		    	$bigPhoto = str_replace(".", "_" . $glnrrand . ".", $middle_name);
		    	$smallPhoto = str_replace(".", "_t.", $bigPhoto);
		    	    
		    	$targetFile =  str_replace('//','/',$targetPath) . $bigPhoto;
		    	$origPath = '/'.$page2.'/';
		    	$dbSmall = $origPath.$smallPhoto;
		    	
		    	require_once '../include/functions_thumb.php';
		    	// Move file and create thumb     
		    	move_uploaded_file($tempFile,$targetFile);
		    	     
		    	create_thumbnail($targetPath, $targetFile, $smallPhoto, JAK_USERAVATWIDTH, JAK_USERAVATHEIGHT, 80);
		    	     	
		    	// SQL update
		    	$jakdb->update($jaktable, ["picture" => $dbSmall], ["id" => $page2]);
		    	     		
		    	} else {
		    		$errors['e'] = $jkl['e24'].'<br />';
		    		$errors = $errors;
		    	}
		    	
		    	} else {
		    		$errors['e'] = $jkl['e46'].'<br />';
		    		$errors = $errors;
		    	}
		    	
		    	} else {
		    		$errors['e'] = $jkl['e24'].'<br />';
		    		$errors = $errors;
		    	}
		    	
		    	} else {
		    		$errors['e'] = $jkl['e24'].'<br />';
		    		$errors = $errors;
		    	}
		    
		    }
		    
		    if (count($errors) == 0) {
		    
		    if (!isset($jkp['jak_access'])) $jkp['jak_access'] = '1';
		    
		    // We cant deny access for superadmin
		    $useridarray = explode(',', JAK_SUPERADMIN);
		    
		    if (!in_array($page2, $useridarray)) {

		    	$result = $jakdb->update($jaktable, ["access" => $jkp['jak_access']], ["id" => $page2]);
		    }
		    
		    if (!isset($jkp['jak_depid'])) {
		    	$depa = 0;
		    } else {
		    	$depa = join(',', $jkp['jak_depid']);
		    }
		    
		    $bhours = '';
		    $bhours = trim($_REQUEST["bhours"]);
		    
		    // Reset the hours if they not set.
		    if ($bhours == '[{"isActive":false,"timeFrom":null,"timeTill":null,"timeFroma":null,"timeTilla":null},{"isActive":false,"timeFrom":null,"timeTill":null,"timeFroma":null,"timeTilla":null},{"isActive":false,"timeFrom":null,"timeTill":null,"timeFroma":null,"timeTilla":null},{"isActive":false,"timeFrom":null,"timeTill":null,"timeFroma":null,"timeTilla":null},{"isActive":false,"timeFrom":null,"timeTill":null,"timeFroma":null,"timeTilla":null},{"isActive":false,"timeFrom":null,"timeTill":null,"timeFroma":null,"timeTilla":null},{"isActive":false,"timeFrom":null,"timeTill":null,"timeFroma":null,"timeTilla":null}]') $bhours = '';

		    // No sibling update
		    $siblingupd = false;

		    $smsphone = '';
			if (isset($jkp['jak_phone'])) $smsphone = $jkp['jak_phone'];

		    $whatsphone = '';
			if (isset($jkp['jak_whatsphone'])) $whatsphone = $jkp['jak_whatsphone'];
		    
		    if (jak_get_access("usrmanage", $jakuser->getVar("permissions"))) {
				
				$result = $jakdb->update($jaktable, ["departments" => $depa,
				"username" => trim($jkp['jak_username']),
				"name" => trim($jkp['jak_name']),
				"phonenumber" => $smsphone,
				"whatsappnumber" => $whatsphone,
				"pusho_tok" => $jkp['jak_pushot'],
				"pusho_key" => $jkp['jak_pushok'],
				"responses" => $jkp['jak_responses'],
				"files" => $jkp['jak_files'],
				"operatorlist" => $jkp['jak_chatlist'],
				"transferc" => $jkp['jak_transfer'],
				"chat_latency" => $jkp['jak_latency'],
				"useronlinelist" => $jkp['jak_uolist'],
				"sound" => $jkp['jak_sound'],
				"ringing" => $jkp['jak_ringing'],
				"alwaysnot" => $jkp['jak_alwaysnot'],
				"emailnot" => $jkp['jak_emailnot'],
				"language" => $jkp['jak_lang'],
				"invitationmsg" => $jkp['jak_inv'],
				"hours_array" => $bhours,
				"email" => filter_var($jkp['jak_email'], FILTER_SANITIZE_EMAIL)], ["id" => $page2]);
			
			} else {

				// Table to update usually the one belongs to the operator
				$uid = JAK_USERID;
				if (isset($page3) && !empty($page3) && is_numeric($page3) && $jakdb->has($jaktable, ["AND" => ["id" => $page2, "opid" => JAK_USERID]])) {
					$uid = $page2;
					// Sibling update
					$siblingupd = true;
				}

				$result = $jakdb->update($jaktable, ["username" => trim($jkp['jak_username']),
				"name" => trim($jkp['jak_name']),
				"phonenumber" => $smsphone,
				"whatsappnumber" => $whatsphone,
				"pusho_tok" => $jkp['jak_pushot'],
				"pusho_key" => $jkp['jak_pushok'],
				"chat_latency" => $jkp['jak_latency'],
				"useronlinelist" => $jkp['jak_uolist'],
				"sound" => $jkp['jak_sound'],
				"ringing" => $jkp['jak_ringing'],
				"alwaysnot" => $jkp['jak_alwaysnot'],
				"emailnot" => $jkp['jak_emailnot'],
				"language" => $jkp['jak_lang'],
				"invitationmsg" => $jkp['jak_inv'],
				"hours_array" => $bhours,
				"email" => filter_var($jkp['jak_email'], FILTER_SANITIZE_EMAIL)], ["id" => $page2]);
			
			}

			// Finally we update the password
			if ($updatepass) $result = $jakdb->update($jaktable, ["password" => hash_hmac('sha256', $jkp['jak_password'], DB_PASS_HASH)], ["id" => $page2]);

			// Finally update the user permission
			if (jak_get_access("usrmanage", $jakuser->getVar("permissions")) || $siblingupd) {
		    
		        if (!isset($jkp['jak_roles'])) {
		        	$tw_roles = '';
		        } else {
		        	$tw_roles = join(',', $jkp['jak_roles']);
		        }

		        if (JAK_SUPERADMIN && $page2 == JAK_USERID) $tw_roles = "leads,leads_all,off_all,statistic,statistic_all,files,proactive,usrmanage,responses,departments,settings,answers,widget,blacklist";

		        $result = $jakdb->update($jaktable, ["permissions" => $tw_roles], ["id" => $page2]);
		        
		    }
		
		if (!$result) {
		    $_SESSION["infomsg"] = $jkl['i'];
		    jak_redirect($_SESSION['LCRedirect']);
		} else {

			if (!$siblingupd) {

				// We have a username change reset the sessions or we get logged out
				if ($jkp['jak_username'] != $jkp['jak_username_old']) {

					// Set the session
					$_SESSION['jak_username'] = $jkp['jak_username'];

					// Check if cookies are set previous (wrongly) and delete
					if (isset($_COOKIE['jak_lcp_cookname'])) {
						setcookie("jak_lcp_cookname", $jkp['jak_username'], time() + JAK_COOKIE_TIME, JAK_COOKIE_PATH);
					}
				}

				// Now if we have multi site please update the main database.
				if (!empty(JAKDB_MAIN_NAME) && JAK_MAIN_LOC) {
					// Database connection to the main site
				    $jakdb1 = new JAKsql([
				    	// required
				       	'database_type' => JAKDB_MAIN_DBTYPE,
				        'database_name' => JAKDB_MAIN_NAME,
				        'server' => JAKDB_MAIN_HOST,
				        'username' => JAKDB_MAIN_USER,
				        'password' => JAKDB_MAIN_PASS,
				        'charset' => 'utf8',
				        'port' => JAKDB_MAIN_PORT,
				        'prefix' => JAKDB_MAIN_PREFIX,
				         
				        // [optional] driver_option for connection, read more from http://www.php.net/manual/en/pdo.setattribute.php
				        'option' => [PDO::ATTR_CASE => PDO::CASE_NATURAL]
				        ]);

				    // Now let's check if we have a membership change
			    	if (isset($jkp['jak_membership']) && !empty($jkp['jak_membership'])) {

					    // Extend membership
						$paidunix = strtotime($jkp['jak_membership']);

						// get the nice time
			        	$paidtill = date('Y-m-d H:i:s', $paidunix);

			        	// finally update the main database
			            $jakdb1->update("users", [ 
			                "trial" => "1980-05-06 00:00:00",
			                "paidtill" => $paidtill,
			                "payreminder" => 0,
			                "active" => 1,
			                "confirm" => 0,
			                "email" => filter_var($jkp['jak_email'], FILTER_SANITIZE_EMAIL),
							"username" => trim($jkp['jak_username']),
							"lastedit" => $jakdb->raw("NOW()")], ["AND" => ["opid" => $page2, "locationid" => JAK_MAIN_LOC]]);

			            if ($updatepass) $jakdb1->update("users", ["password" => hash_hmac('sha256', $jkp['jak_password'], DB_PASS_HASH)], ["AND" => ["locationid" => JAK_MAIN_LOC, "opid" => $page2]]);

		                // Update the trial time for the user on the widget
			            $result = $jakdb->update("chatwidget", ["validtill" => $paidunix], ["opid" => $page2]);

			            // Now let us delete the define cache file
						$cachewidget = APP_PATH.JAK_CACHE_DIRECTORY.'/opcache'.$page2.'.php';
						if (file_exists($cachewidget)) {
							unlink($cachewidget);
						}

					} else {

						$uid = JAK_USERID;

						$jakdb1->update("users", [ 
						"email" => filter_var($jkp['jak_email'], FILTER_SANITIZE_EMAIL),
						"username" => trim($jkp['jak_username']),
						"lastedit" => $jakdb->raw("NOW()")], ["AND" => ["locationid" => JAK_MAIN_LOC, "opid" => $uid]]);

				    	if ($updatepass) $jakdb1->update("users", ["password" => hash_hmac('sha256', $jkp['jak_password'], DB_PASS_HASH)], ["AND" => ["locationid" => JAK_MAIN_LOC, "opid" => $uid]]);
					}
				}
			} // end siblings update

		    $_SESSION["successmsg"] = $jkl['g14'];
		    jak_redirect($_SESSION['LCRedirect']);
		}
		
		// Output the errors
		} else {
		    
		   	$errors['e'] = $jkl['e'];
		    $errors = $errors;
		}
		}
		
			// Call the settings function
			$lang_files = jak_get_lang_files();
		
			$JAK_FORM_DATA = jak_get_data($page2,$jaktable);
			
			// Title and Description
			$SECTION_TITLE = $jkl["m11"];
			$SECTION_DESC = "";
			
			// Include the javascript file for results
			$js_file_footer = 'js_edituser.php';
			
			$template = 'edituser.php';
		
		} else {
			$_SESSION["errormsg"] = $jkl['i3'];
		    jak_redirect(JAK_rewrite::jakParseurl('users'));
		}
		
		break;
		case 'resethours':
			// Check if the user exists
			if (is_numeric($page2) && ($page2 == JAK_USERID || $page3 == $opcacheid)) {

				$result = $jakdb->update($jaktable, ["hours_array" => ""], ["id" => $page2]);

				$_SESSION["successmsg"] = $jkl['g14'];
		    	jak_redirect(JAK_rewrite::jakParseurl('users', 'edit', $page2, $page3));

			} else {
				$_SESSION["errormsg"] = $jkl['i2'];
		    	jak_redirect(JAK_rewrite::jakParseurl('users'));
			}
		break;
		default:
		
			if ($_SERVER['REQUEST_METHOD'] == 'POST') {

				if (isset($_POST['jak_delock_all'])) {
			    $jkp = $_POST;
			    
			    if (isset($jkp['action']) && $jkp['action'] == "lock") {
				    
					    $lockuser = $jkp['jak_delock_all'];
					    $useridarray = explode(',', JAK_SUPERADMIN);
					
					    for ($i = 0; $i < count($lockuser); $i++) {
					        $locked = $lockuser[$i];
					        // Get the userid / access token
					        $uidacc = explode(":#:", $locked);
					        if (!in_array($uidacc[0], $useridarray)) {
					        	if ($uidacc[1] == 1) {
					        		$query = $jakdb->update($jaktable, ["access" => 0], ["id" => $uidacc[0]]);
					        	} else {
					        		$query = $jakdb->update($jaktable, ["access" => 1], ["id" => $uidacc[0]]);
					        	}
					    	}
					    }
					    
					    if ($query) {
					    	$_SESSION["successmsg"] = $jkl['g14'];
			    			jak_redirect($_SESSION['LCRedirect']);
			    		}
				  
				 	$_SESSION["infomsg"] = $jkl['i1'];
		    		jak_redirect($_SESSION['LCRedirect']);
			    
			    }
			    
			    if (isset($jkp['delete']) && $jkp['action'] == "delete") {
			    
					    $lockuser = $jkp['jak_delock_all'];
					    $useridarray = explode(',', JAK_SUPERADMIN);
					
					    for ($i = 0; $i < count($lockuser); $i++) {
					        $locked = $lockuser[$i];
					        // Get the userid / access token
					        $uidacc = explode(":#:", $locked);
					        if (!in_array($uidacc[0], $useridarray)) {
					        	// Now we remove everything from this user and the user itself
								$jakdb->delete("op_settings", ["opid" => $uidacc[0]]);
								$jakdb->delete("chatwidget", ["opid" => $uidacc[0]]);
								$sessionid = $jakdb->get("sessions", "id", ["operatorid" => $uidacc[0]]);
					    		$jakdb->delete("transcript", ["convid" => $sessionid]);
					   			$jakdb->delete("sessions", ["operatorid" => $uidacc[0]]);
					   			$contactid = $jakdb->get("contacts", "id", ["operatorid" => $uidacc[0]]);
					    		$jakdb->delete("contactsreply", ["contactid" => $contactid]);
					   			$jakdb->delete("contacts", ["operatorid" => $uidacc[0]]);
					   			$jakdb->delete("answers", ["opid" => $uidacc[0]]);
					   			$jakdb->delete("bot_question", ["opid" => $uidacc[0]]);
					   			$jakdb->delete("responses", ["opid" => $uidacc[0]]);
					   			$jakdb->delete("autoproactive", ["opid" => $uidacc[0]]);
					   			$jakdb->delete("checkstatus", ["convid" => $sessionid]);
					   			$jakdb->delete("files", ["opid" => $uidacc[0]]);
					   			$jakdb->delete("urlblacklist", ["opid" => $uidacc[0]]);
					   			$jakdb->delete($jaktable2, ["opid" => $uidacc[0]]);
								$query = $jakdb->delete($jaktable, ["id" => $uidacc[0]]);
					    	}
					    }
					        
					    if ($query) {
						    $_SESSION["successmsg"] = $jkl['g14'];
				    		jak_redirect($_SESSION['LCRedirect']);
				    	}
			  
			 		$_SESSION["infomsg"] = $jkl['i1'];
		    		jak_redirect($_SESSION['LCRedirect']);
			    
			    }

			}

			    $_SESSION["infomsg"] = $jkl['i'];
		    	jak_redirect($_SESSION['LCRedirect']);
			    
			}
			 
			if (jak_get_access("usrmanage", $jakuser->getVar("permissions"), JAK_MAIN_OP)) {
				$JAK_USER_ALL = jak_get_user_all($jaktable, $opcacheid, "meandsibling");

				// Let's check if we can add more users
				$totalAll = count($JAK_USER_ALL);
				if ($totalavops > $totalAll) $addmuser = true;

			} else {
				$JAK_USER_ALL = jak_get_user_all($jaktable, JAK_USERID, false);
			}
			
			// Title and Description
			$SECTION_TITLE = $jkl["m4"];
			$SECTION_DESC = "";
			
			// Include the javascript file for results
			$js_file_footer = 'js_user.php';
			
			// Call the template
			$template = 'user.php';
}
?>