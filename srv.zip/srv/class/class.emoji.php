<?php
require_once(__DIR__ . '/emoji/RulesetInterface.php');
require_once(__DIR__ . '/emoji/ClientInterface.php');
require_once(__DIR__ . '/emoji/Client.php');
require_once(__DIR__ . '/emoji/Ruleset.php');
require_once(__DIR__ . '/emoji/Emojione.php');
?>