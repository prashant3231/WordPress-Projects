{
	"sProcessing":   "Henter...",
	"sLengthMenu":   "Vis _MENU_ linjer",
	"sZeroRecords":  "Ingen linjer matcher s&oslash;gningen",
	"sInfo":         "Viser _START_ til _END_ af _TOTAL_ linjer",
	"sInfoEmpty":    "Viser 0 til 0 af 0 linjer",
	"sInfoFiltered": "(filtreret fra _MAX_ linjer)",
	"sInfoPostFix":  "",
	"sSearch":       "S&oslash;g:",
	"sUrl":          "",
	"oPaginate": {
	    "sFirst":    "F&oslash;rste",
	    "sPrevious": "Forrige",
	    "sNext":     "N&aelig;ste",
	    "sLast":     "Sidste"
	}
}