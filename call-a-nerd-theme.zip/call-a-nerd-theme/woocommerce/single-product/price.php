<?php
/**
 * Single Product Price, including microdata for SEO
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/price.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;

?><?php  if ( is_plugin_active( 'woocommerce-germanized/woocommerce-germanized.php' ) ) {
                                  //plugin is activated
?><p class="wc-gzd-additional-info tax-info mid-visible"><?php
                                   if ( wc_gzd_get_gzd_product( $product )->get_tax_info() ) : ?>
                                            <?php //echo wc_gzd_get_gzd_product( $product )->get_tax_info(); ?>
                                        <?php elseif ( get_option( 'woocommerce_gzd_small_enterprise' ) == 'yes' ) : ?>
                                            <?php echo " ".wc_gzd_get_small_business_product_notice(); ?>
                                        <?php endif; 

                                        if ( wc_gzd_get_gzd_product( $product )->get_shipping_costs_html() ) : ?>
                                            <?php echo " ".wc_gzd_get_gzd_product( $product )->get_shipping_costs_html();?>
								<?php endif;?></p><?php
                                    } ?>
<p class="price"><?php echo $product->get_price_html(); ?></p>
