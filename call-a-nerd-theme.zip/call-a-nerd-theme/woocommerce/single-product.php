<?php
/**
 * The Template for displaying all single products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

get_header(); ?>

<?php 

$featureplacemet=get_post_meta($post->ID, "featureplacemet", true); 
 $width_desc_product=get_post_meta($post->ID, "width_desc_product", true); 

$featuresize=get_post_meta($post->ID, "featuresize", true);

$layout=get_post_meta($post->ID, "layout", true);
$page_title_position=get_post_meta($post->ID,'page_title_position', true);
  ?>
<?php 
if($page_title_position==''){
$page_title_position=of_get_option('page_title_position');    
}
if($featuresize==''){
$featuresize=of_get_option('post_feature_size');    
}
 
if($width_desc_product==''){
$width_desc_product=of_get_option('shop_detail_description');    
}

if($layout==''){
$layout=of_get_option('shop_detail_layout');    
}
$breadcrumbs = "";
$terms = get_the_terms( $post->ID, 'product_cat' );
//print_r($terms);
$cat_name = "";
$cat_url = "";
$i=0;
if(!empty($terms))
foreach($terms as $cat){
	if($i==0){
		$cat_name= $cat->name;
		$cat_url = get_term_link( $cat->term_id );
	}
$i++;
}
if($cat_name!="" && $cat_name!="Uncategorized"){
	$cat_breadcrumb = '<a href="'.$cat_url.'">'.$cat_name.'</a> / ';
}else{
	$cat_breadcrumb = "";
}
if(of_get_option('shop_page_title')){
        $shop_title=of_get_option('shop_page_title');   
        $shop_url = get_permalink( woocommerce_get_page_id( 'shop' ) );
        $breadcrumbs .=    '<a href="'.site_url().'">'. __('Home','call-a-nerd-theme')."</a> / "; 
        $breadcrumbs .=   '<a href="'.$shop_url.'">'. __($shop_title,'call-a-nerd-theme').'</a>'; 
        //$breadcrumbs .=    $cat_breadcrumb; 
        //$breadcrumbs .=   get_the_title();   
}


 ?>

<div class="sub-header">
    <div class="container">
        <?php if ( apply_filters( 'woocommerce_show_page_title', true ) ) : ?>
            <h1 class="woocommerce-products-header__title page-title"><?php echo $shop_title; ?></h1>
        <?php endif; ?>
        <?php if(of_get_option('shop_page_title')): ?>
       		<nav class="woocommerce-breadcrumb"><?php echo $breadcrumbs; ?></nav>
        <?php else:?>
        	<nav class="woocommerce-breadcrumb"><?php echo $breadcrumbs; ?></nav>
        <?php endif; ?>
    </div>
</div>



	<div class="container">
		
    	<div class="row">
<?php             if($layout=='without-sidebar'){  $class='col-md-12'; }  
            else if($layout=='with-sidebar') {  $class='col-md-9'; }
            else if($layout=='with-sidebar-left'){ $class='col-md-9 pull-right'; }     ?>
            
        	<div class="content-left <?php echo $class ?>">

				<?php
					/**
					 * woocommerce_before_main_content hook.
					 *
					 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
					 * @hooked woocommerce_breadcrumb - 20
					 */
					do_action( 'woocommerce_before_main_content' );
				?>

		<?php while ( have_posts() ) : the_post(); ?>
              
			<?php wc_get_template_part( 'content', 'single-product' ); ?>

		<?php endwhile; // end of the loop. ?>



	<?php
		/**
		 * woocommerce_after_main_content hook.
		 *
		 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
		 */
		do_action( 'woocommerce_after_main_content' );


	?>

</div>
<?php if($layout=='with-sidebar' || $layout=='with-sidebar-left'){ ?>
        <div class="content-right col-md-3 sidebar  <?php echo (($layout=='with-sidebar-left')?'pull-left':'') ?>"> 
                <?php
                    /**
                    * woocommerce_sidebar hook.
                    *
                    * @hooked woocommerce_get_sidebar - 10
                    */
	if(of_get_option('shop_detail_page_sidebar')!=''){ dynamic_sidebar(of_get_option('shop_detail_page_sidebar'));}else{
                    do_action( 'woocommerce_sidebar' );}
                ?>
            </div>
            <?php   } ?>
</div>

<hr />
<?php if($width_desc_product=='full'){?>
</div>
<?php }?>
<?php 
	
	do_action( 'woocommerce_after_single_product_summary' ); if($width_desc_product=='box'){?>
<style>#content .container{overflow:hidden;}</style></div>
<?php }
		get_footer();

/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */
?>