<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.6.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
global $product;
// Ensure visibility
if ( empty( $product ) || ! $product->is_visible() ) {
	return;
}
?>
<style>p.wc-gzd-additional-info{display: none;}p.wc-gzd-additional-info.mid-visible{display: block;}</style>
<li <?php post_class(); ?>>
	<?php
	/**
	 * woocommerce_before_shop_loop_item hook.
	 *
	 * @hooked woocommerce_template_loop_product_link_open - 10
	 */
	do_action( 'woocommerce_before_shop_loop_item' );
	/**
	 * woocommerce_before_shop_loop_item_title hook.
	 *
	 * @hooked woocommerce_show_product_loop_sale_flash - 10
	 * @hooked woocommerce_template_loop_product_thumbnail - 10
	 */
	?><div class="related-add-to-cart"><?php add_action('woocommerce_before_shop_loop_item_title','woocommerce_template_loop_add_to_cart');
	do_action( 'woocommerce_before_shop_loop_item_title' );?></div><?php
	/**
	 * woocommerce_shop_loop_item_title hook.
	 *
	 * @hooked woocommerce_template_loop_product_title - 10
	 */
	do_action( 'woocommerce_shop_loop_item_title' );
	/**
	 * woocommerce_after_shop_loop_item_title hook.
	 *
	 * @hooked woocommerce_template_loop_rating - 5
	 * @hooked woocommerce_template_loop_price - 10
	 */
	do_action( 'woocommerce_after_shop_loop_item_title' );
	if ( is_plugin_active( 'woocommerce-germanized/woocommerce-germanized.php' ) ) {
                                  //plugin is activated
	?><p class="wc-gzd-additional-info tax-info mid-visible"><?php
                                   if ( wc_gzd_get_gzd_product( $product )->get_tax_info() ) : ?>
                                            <?php //echo wc_gzd_get_gzd_product( $product )->get_tax_info(); ?>
                                        <?php elseif ( get_option( 'woocommerce_gzd_small_enterprise' ) == 'yes' ) : ?>
                                            <?php echo " ".wc_gzd_get_small_business_product_notice(); ?>
                                        <?php endif; 

                                        if ( wc_gzd_get_gzd_product( $product )->get_shipping_costs_html() ) : ?>
                                            <?php echo " ".wc_gzd_get_gzd_product( $product )->get_shipping_costs_html();?>
								<?php endif;?></p><?php
                                    }
	  
	
	
	
	
	/**
	 * woocommerce_after_shop_loop_item hook.
	 *
	 * @hooked woocommerce_template_loop_product_link_close - 5
	 * @hooked woocommerce_template_loop_add_to_cart - 10
	 */
	remove_action('woocommerce_after_shop_loop_item','woocommerce_template_loop_add_to_cart');
	do_action( 'woocommerce_after_shop_loop_item' );
	?>
</li>