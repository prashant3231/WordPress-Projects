<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

get_header(); 

include_once( ABSPATH . 'wp-admin/includes/plugin.php' ); 

global $post;
$banner='';$featuresize='';$headlinepos='';
$queried_object = get_queried_object();

 if(isset($queried_object->term_id) && $queried_object->term_id!=''){
	 $md=get_term_meta($queried_object->term_id,'thumbnail_id',true);
	 if(is_product_tag())$md=get_term_meta($queried_object->term_id,'category-image-id',true);
	  $src=wp_get_attachment_image_src($md,'full',true);

	if(isset($src) && $src!=''){
	     $banner=$src[0];
	}
	$Shop=$queried_object->name;
	$metadata=get_option('taxonomy_term_'.$queried_object->term_id);
	 $featuresize=$metadata['term_featuresize'];
	 if($featuresize=='none')$featuresize=of_get_option('shop_category_page_feature_size');
	 $headlinepos=$metadata['catpage_title_position'];
	 if($headlinepos=='')$headlinepos=of_get_option('shop_category_title_position');
 }
 else{
    
    $featuresize=of_get_option('shop_page_feature_size');   
    $banner=site_url().of_get_option('shop_banner_image');
$headlinepos=of_get_option('shop_title_position');
 }
if(of_get_option('shop_page_title')){
    $Shop=of_get_option('shop_page_title');        
}else{
    $Shop = "Shop";
}
$breadcrumbs = "";
if(is_product_category() || is_product_tag()){
    $shop_url = get_permalink( woocommerce_get_page_id( 'shop' ) );
    $breadcrumbs = "<a href='".site_url()."'>".__('Home','call-a-nerd-theme')."</a> / ";
    $breadcrumbs .= "<a href='".$shop_url."'>".__($Shop,'call-a-nerd-theme')."</a> / ";
    $breadcrumbs .= single_term_title("", false); 
	$Shop= single_term_title("", false);
}else{
    $breadcrumbs = "<a href='".site_url()."'>".__('Home','call-a-nerd-theme')."</a> / ";
    $breadcrumbs .= __($Shop,'call-a-nerd-theme');
}



if($featuresize =='full' && $banner!=''){ ?>
<div class="sub-header sub-header-bg" style="background-image:url(<?php echo $banner  ?>)">
    <?php if($headlinepos=='image_center'){?><div class="page-title">
        <h1><?php echo __($Shop,'call-a-nerd-theme'); ?></h1>
    </div><?php }?>
</div>
 <?php if($headlinepos=='image_under'){?>
    <div class="container">
		<h1 class="page-title"><?php echo __($Shop,'call-a-nerd-theme'); ?></h1></div>
    <?php }?>
<?php   }  else if($featuresize =='nofeature' || ($featuresize =='content' && of_get_option('shop_layout')!='without-sidebar') || $featuresize=='' || $banner=='') { ?>
<div class="sub-header">
    <div class="container">
        <h1 class="page-title"><?php    echo __($Shop,'call-a-nerd-theme'); ?></h1>
       <!-- <?php if ( apply_filters( 'woocommerce_show_page_title', true ) ) : ?>
            <h1 class="woocommerce-products-header__title page-title"><?php woocommerce_page_title(); ?></h1>
        <?php endif; ?>-->
        <nav class="woocommerce-breadcrumb"><?php echo  $breadcrumbs; ?></nav>
    </div>
</div>


<?php   } ?>

  <?php if($featuresize =='box' && $banner!=''){ ?>
				    <div class="sub-header sub-header-bg container" style="background-image:url(<?php echo $banner  ?>)">
				        <?php if($headlinepos=='image_center'){?><div class="page-title">
				            <h1><?php echo __($Shop,'call-a-nerd-theme'); ?></h1>
				        </div><?php }?>
</div>
 <?php if($headlinepos=='image_under'){?>
			<div class="container"> <h1 class="page-title"><?php echo __($Shop,'call-a-nerd-theme'); ?></h1></div>
    <?php }?>     
                <?php } ?>
    <div class="container">
        <div class="row">
              

        <?php 
$queried_object = get_queried_object();

 if(isset($queried_object->term_id) && $queried_object->term_id!=''){
	 $metadata=get_option('taxonomy_term_'.$queried_object->term_id);
	$sidebarpos=$metadata['term_layout'];
	 if($sidebarpos=='')$sidebarpos=of_get_option('shop_category_layout');
	 if($sidebarpos=='without-sidebar'){  $class='col-md-12'; }  
            else if($sidebarpos=='with-sidebar') {  $class='col-md-9'; }
            else if($sidebarpos=='with-sidebar-left'){ $class='col-md-9 pull-right'; }
 }else{
            if(of_get_option('shop_layout')=='without-sidebar'){  $class='col-md-12'; }  
            else if(of_get_option('shop_layout')=='with-sidebar') {  $class='col-md-9'; }
            else if(of_get_option('shop_layout')=='with-sidebar-left'){ $class='col-md-9 pull-right'; }    } ?>
        <div class="content-left <?php echo $class ?> " >
        
			<?php
            /**
            * woocommerce_before_main_content hook.
            *
            * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
            * @hooked woocommerce_breadcrumb - 20
            * @hooked WC_Structured_Data::generate_website_data() - 30
            */
            do_action( 'woocommerce_before_main_content' );
            ?>
        
            
             <?php if($featuresize =='content' && $banner!=''){ ?>
				    <div class="sub-header sub-header-bg" style="background-image:url(<?php echo $banner  ?>)">
				         <?php if($headlinepos=='image_center'){?><div class="page-title">
				            <h1><?php echo __($Shop,'call-a-nerd-theme'); ?></h1>
				        </div><?php }?>
</div>
 <?php if($headlinepos=='image_under'){?>
			<div class="container"> <h1 class="page-title"><?php echo __($Shop,'call-a-nerd-theme'); ?></h1></div>
    <?php }?>          
             <?php } ?>
<div class='catdes'><?php
			/**
			 * woocommerce_archive_description hook.
			 *
			 * @hooked woocommerce_taxonomy_archive_description - 10
			 * @hooked woocommerce_product_archive_description - 10
			 */
			do_action( 'woocommerce_archive_description' );
	?></div>

        	<?php wp_reset_query(); if ( have_posts() ) : ?>
        
			<?php
            /**
            * woocommerce_before_shop_loop hook.
            *
            * @hooked wc_print_notices - 10
            * @hooked woocommerce_result_count - 20
            * @hooked woocommerce_catalog_ordering - 30
            */
            do_action( 'woocommerce_before_shop_loop' );
            ?>

        <div class="product-wrapper">
          
            
        
        <?php woocommerce_product_loop_start(); ?>
        
        
        <?php while ( have_posts() ) : the_post(); ?>
        
        <?php if(!get_post_type()){
?>
                <li>
                    <a href="">
                        <?php global $product; echo get_post_type();
    if( $product->is_on_sale() ) {?>
                        <span class="sale"><?php echo __('Sale!','call-a-nerd-theme');?></span><?php }?>

                        <div class="product-detail-image">
                            <a href='<?php the_permalink() ?>'>
                            <img src="<?php echo get_the_post_thumbnail_url($post->ID,'shop_catalog');	 ?>" class="hover-image" alt="">
                            <img src="<?php echo get_the_post_thumbnail_url($post->ID,'shop_catalog');	 ?>" alt="">
                            </a>

                            <div class="product-buttons">
                            <div class="product-buttons-box">
<form class="cart" method="post" enctype="multipart/form-data">
        <input type="hidden" class="input-text qty text" step="1" min="1" max="" name="quantity" value="1" title="Menge" size="4" pattern="[0-9]*" inputmode="numeric">
    
        <button type="submit" name="add-to-cart" value="<?php echo get_the_ID() ?>" class="button product_type_simple add_to_cart_button single_add_to_cart_button button"><?php echo __('Add to cart','call-a-nerd-theme');?></button>

            </form>
                                
                            </div>
                        </div>
                        
                        </div>

                        <div class="product-info-box">
                            <h3 class="product-title"><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h3>
                            <div class="price">
                              <?php   global $product; ?>
                               
 <?php   echo  $product->get_price_html(); ?>
                       <?php  if ( is_plugin_active( 'woocommerce-germanized/woocommerce-germanized.php' ) ) {
                                  //plugin is activated
?><p class="wc-gzd-additional-info tax-info"><?php
                                   if ( wc_gzd_get_gzd_product( $product )->get_tax_info() ) : ?>
                                            <?php //echo wc_gzd_get_gzd_product( $product )->get_tax_info(); ?>
                                        <?php elseif ( get_option( 'woocommerce_gzd_small_enterprise' ) == 'yes' ) : ?>
                                            <?php echo " ".wc_gzd_get_small_business_product_notice(); ?>
                                        <?php endif; 

                                        if ( wc_gzd_get_gzd_product( $product )->get_shipping_costs_html() ) : ?>
                                            <?php echo " ".wc_gzd_get_gzd_product( $product )->get_shipping_costs_html();?>
								<?php endif;?></p><?php
                                    } ?>


                               
                            </div>
                            
                        
                            <div class="product_des">
                                <p><?php the_excerpt() ?></p>
                            </div>
                        </div>

                        
                    </a>
                </li>
<?php   }     
         endwhile; // end of the loop. ?> <?php woocommerce_product_loop_end(); ?>
         
			<ul class="products">
            
        
        <?php //woocommerce_product_loop_start(); ?>
        
        
        <?php while ( have_posts() ) : the_post(); ?>
        
        <?php if(get_post_type()=='product'){
?>
               <li >
                    <a href="">
                        <?php global $product; //echo get_post_type();
    if( $product->is_on_sale() ) {?>
                        <span class="sale"><?php echo __('Sale!','call-a-nerd-theme');?></span><?php }?>

                        <div class="product-detail-image">
                            <a href='<?php the_permalink() ?>'>
                            <img src="<?php echo get_the_post_thumbnail_url($post->ID,'shop_catalog');	 ?>" class="hover-image" alt="">
                            <img src="<?php echo get_the_post_thumbnail_url($post->ID,'shop_catalog');	 ?>" alt="">
                            </a>

                            <div class="product-buttons">
                            <div class="product-buttons-box">
<form class="cart" method="post" enctype="multipart/form-data">
        <input type="hidden" class="input-text qty text" step="1" min="1" max="" name="quantity" value="1" title="Menge" size="4" pattern="[0-9]*" inputmode="numeric">
    
        <button type="submit" name="add-to-cart" value="<?php echo get_the_ID() ?>" class="button product_type_simple add_to_cart_button single_add_to_cart_button button"><?php echo __('Add to cart','call-a-nerd-theme');?></button>

            </form>
                                
                            </div>
                        </div>
                        
                        </div>

                        <div class="product-info-box">
                            <h3 class="product-title"><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h3>
                            <div class="price">
                              <?php   global $product; ?>
                               
 <?php   echo  $product->get_price_html(); ?>
                       <?php  if ( is_plugin_active( 'woocommerce-germanized/woocommerce-germanized.php' ) ) {
                                  //plugin is activated
?><p class="wc-gzd-additional-info tax-info"><?php
                                   if ( wc_gzd_get_gzd_product( $product )->get_tax_info() ) : ?>
                                            <?php //echo wc_gzd_get_gzd_product( $product )->get_tax_info(); ?>
                                        <?php elseif ( get_option( 'woocommerce_gzd_small_enterprise' ) == 'yes' ) : ?>
                                            <?php echo " ".wc_gzd_get_small_business_product_notice(); ?>
                                        <?php endif; 

                                        if ( wc_gzd_get_gzd_product( $product )->get_shipping_costs_html() ) : ?>
                                            <?php echo " ".wc_gzd_get_gzd_product( $product )->get_shipping_costs_html();?>
								<?php endif;?></p><?php
                                    } ?>


                               
                            </div>
                            
                        
                            <div class="product_des">
                                <p><?php the_excerpt() ?></p>
                            </div>
                        </div>

                        
                    </a>
                </li>
<?php   }     
         endwhile; // end of the loop. ?> <?php //woocommerce_product_loop_end(); ?>
         </ul>
         </div>
        
       
        
        <?php
        /**
        * woocommerce_after_shop_loop hook.
        *
        * @hooked woocommerce_pagination - 10
        */
        do_action( 'woocommerce_after_shop_loop' );
        ?>
        
        <?php elseif ( ! woocommerce_product_subcategories( array( 'before' => woocommerce_product_loop_start( false ), 'after' => woocommerce_product_loop_end( false ) ) ) ) : ?>
        
        <?php
        /**
        * woocommerce_no_products_found hook.
        *
        * @hooked wc_no_products_found - 10
        */
        do_action( 'woocommerce_no_products_found' );
        ?>
        
        <?php endif; ?>
        
        <?php
        /**
        * woocommerce_after_main_content hook.
        *
        * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
        */
        do_action( 'woocommerce_after_main_content' );
        ?>
        </div>

    <?php $queried_object = get_queried_object();

 
			if(isset($queried_object->term_id) && $queried_object->term_id!=''){
				 $metadata=get_option('taxonomy_term_'.$queried_object->term_id);
	$sidebarpos=$metadata['term_layout'];
	 if($sidebarpos=='')$sidebarpos=of_get_option('shop_category_layout');
				if($sidebarpos=='with-sidebar' || $sidebarpos=='with-sidebar-left'){ ?>
        <div class="content-right col-md-3 sidebar  <?php echo (($sidebarpos=='with-sidebar-left')?'pull-left':'') ?>"> 
                <?php
                    /**
                    * woocommerce_sidebar hook.
                    *
                    * @hooked woocommerce_get_sidebar - 10
                    */
                    get_sidebar();
                ?>
            </div>
            <?php   }}
			elseif(of_get_option('shop_layout')=='with-sidebar' || of_get_option('shop_layout')=='with-sidebar-left'){ ?>
        <div class="content-right col-md-3 sidebar  <?php echo ((of_get_option('shop_layout')=='with-sidebar-left')?'pull-left':'') ?>"> 
                <?php
                    /**
                    * woocommerce_sidebar hook.
                    *
                    * @hooked woocommerce_get_sidebar - 10
                    */
                    get_sidebar();
                ?>
            </div>
            <?php   } ?>
        </div>
    </div><!-- #container -->
<?php get_footer(); ?>
