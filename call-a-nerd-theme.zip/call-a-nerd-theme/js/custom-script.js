jQuery(document).ready(function(){

 setTimeout(function(){
 	 jQuery("#ucp_rate_notice2 .notice-dismiss").on("click",function(e){
	  	e.preventDefault();
		 var data = {
				'action': 'dismiss_firstinstall'
			};
			jQuery.post(ajaxurl, data, function(response) {
			});
		})
	 jQuery("#weekly_meesage .notice-dismiss").on("click",function(e){
	  	e.preventDefault();
		 var data = {
				'action': 'dismiss_weeklyinstall'
			};
			jQuery.post(ajaxurl, data, function(response) {
				//alert('Got this from the server: ' + response);
			});
		})
 	},500)	
 	
 jQuery(".first_install_forever").on("click",function(e){
 	e.preventDefault();
 	jQuery(".first_install_msg").hide();
 	var data = {
				'action': 'dismiss_firstinstall'
			};
			jQuery.post(ajaxurl, data, function(response) {
			});
 	return true;
 })
jQuery(".first_install_forever_lk .notice-dismiss").on("click",function(e){
 	e.preventDefault();
 	jQuery(".first_install_forever_lk").hide();
 	var data = {
				'action': 'dismiss_firstinstall_lk'
			};
			jQuery.post(ajaxurl, data, function(response) {
			});
 	return true;
 })
 jQuery(".weekly_install_forever").on("click",function(e){
 	e.preventDefault();
 	jQuery(".weekly_install_msg").hide();
 	var data = {
				'action': 'dismiss_weeklyinstall_forever'
			};
			jQuery.post(ajaxurl, data, function(response) {
			});
 	return true;
 })
  jQuery("#weekly_meesage_for_free .notice-dismiss").on("click",function(e){
 	e.preventDefault();
 	//alert("dfsdfs");return;
 	jQuery(".content_for_free").hide();
 	var data = {
				'action': 'dismiss_contentfreetheme_forever'
			};
			jQuery.post(ajaxurl, data, function(response) {
			});
 	return true;
 })

 	
})

