/*king composer custom translation*/
jQuery(document).ready(function(){
	jQuery(document).on("click",".kc-model.row-container-control ul li.sl-note",function(){
		console.log("ddd");
		jQuery(".kc-params-popup ul li.kc-tab-general-general").text("ss");

	})
    
});

/*end*/