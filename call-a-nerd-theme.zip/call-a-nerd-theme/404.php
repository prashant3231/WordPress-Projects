<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package CaN
 */

get_header(); ?>

	<div id="primary" class="content-area content-area-with-sidebar container">
		<main id="main" class="site-main" role="main">

			<section class="error-404 not-found">
				

				<div class="page-content">
					<div class='content-left sidebar col-md-9 <?php echo $t ?>'>
					<header class="page-header">
						<h1 class="page-title"><?php if(get_locale()=='de_DE' || get_locale()=='de_DE_formal' || get_locale()=='de_CH' || get_locale()=='de_CH_informal'){ esc_html_e( 'Diese Seite wurde leider nicht gefunden', 'call-a-nerd-theme' );}else{esc_html_e( 'Oops! That page can&rsquo;t be found.', 'call-a-nerd-theme' );} ?></h1>
					</header><!-- .page-header -->
					<p><?php if(get_locale()=='de_DE' || get_locale()=='de_DE_formal' || get_locale()=='de_CH' || get_locale()=='de_CH_informal'){ esc_html_e( 'Wir haben auch noch viele andere tolle Inhalte. Einfach oben im Menü auf eine Kategorie oder unten auf die vorgeschriebenen Inhalte unten klicken. Oder stattdessen lieber etwas suchen?', 'call-a-nerd-theme' );}else{esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'call-a-nerd-theme' );} ?></p>

					<div class="search_wrapper" style="min-height:100px;">
							<?php
								get_search_form();

								
							?>
						</div>
						<h4>
						<?php if(get_locale()=='de_DE' || get_locale()=='de_DE_formal' || get_locale()=='de_CH' || get_locale()=='de_CH_informal'){ esc_html_e( 'Neueste Beiträge', 'call-a-nerd-theme' );}else{esc_html_e( 'Suggested posts', 'call-a-nerd-theme' );} ?>
						</h4>
						<?php $del_recent_posts = new WP_Query();
    $del_recent_posts->query('showposts=5&orderby=rand&post_status=publish');
						?><ul class="posts-recent"><?php
        while ($del_recent_posts->have_posts()) : $del_recent_posts->the_post(); ?>
						
							
						
            <li class="post-col">
                <a href="<?php esc_url(the_permalink()); ?>">
                    <?php the_post_thumbnail(array(150,150)); ?>
                </a>
                <a href="<?php esc_url(the_permalink()); ?>">
                        <?php esc_html(the_title()); ?>
                   </a>
            </li>
        <?php endwhile;?></ul><?php
    wp_reset_postdata();?>
					</div>

					<div class='content-right col-md-3 sidebar'>
						<?php
							the_widget( 'WP_Widget_Recent_Posts' );

							// Only show the widget if site has multiple categories.
							if ( can_categorized_blog() ) :
						?>
						<div class="widget widget_categories">
							<h2 class="widget-title"><?php if(get_locale()=='de_DE' || get_locale()=='de_DE_formal' || get_locale()=='de_CH' || get_locale()=='de_CH_informal'){ esc_html_e( 'Beliebteste Kategorien', 'call-a-nerd-theme' );}else{esc_html_e( 'Most Used Categories', 'call-a-nerd-theme' );} ?></h2>
							<ul>
							<?php
								wp_list_categories( array(
									'orderby'    => 'count',
									'order'      => 'DESC',
									'show_count' => 1,
									'title_li'   => '',
									'number'     => 10,
								) );
							?>
							</ul>
						</div><!-- .widget -->

						<?php
							endif;

							/* translators: %1$s: smiley */
							$archive_content = '<p>' . sprintf( esc_html__( 'Try looking in the monthly archives. %1$s', 'call-a-nerd-theme' ), convert_smilies( ':)' ) ) . '</p>';
							the_widget( 'WP_Widget_Archives', 'dropdown=1', "after_title=</h2>$archive_content" );

							the_widget( 'WP_Widget_Tag_Cloud' );
						?>
					</div>
				</div><!-- .page-content -->
			</section><!-- .error-404 -->

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
