<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package CaN
 */

get_header(); ?>

<?php   

if(of_get_option('page_title_position')=='image_center'){
$w=12;
}
else if(of_get_option('page_title_position')!='image_center'){
$w=12;
}

 ?>

 <?php   
$featuresize=of_get_option('blog_page_feature_size');    

if($featuresize =='full' && of_get_option('blog_banner_image')!=''){ ?>
<div class="sub-header sub-header-bg" style="background-image:url(<?php echo site_url().of_get_option('blog_banner_image')  ?>)">
   <?php if(of_get_option('blogpage_title_position')=='image_center'){?> <div class="page-title">
        <h1><?php echo __('Blog','call-a-nerd-theme'); ?></h1>
    </div><?php }?>
</div> <?php if(of_get_option('blogpage_title_position')=='image_under'){?> 
        
			<div class="container"><h1 class="page-title"><?php echo __('Blog','call-a-nerd-theme'); ?></h1></div>
    <?php }?>
<?php   }  else if($featuresize =='box' && of_get_option('blog_banner_image')!='') { ?>
<div  class="sub-header sub-header-bg  container" style="background-image:url(<?php echo site_url().of_get_option('blog_banner_image')  ?>)">
    <?php if(of_get_option('blogpage_title_position')=='image_center'){?> <div class="page-title">
        <h1><?php echo __('Blog','call-a-nerd-theme'); ?></h1>
	</div><?php }?>
</div>
  <?php if(of_get_option('blogpage_title_position')=='image_under'){?> 
			<div class="container"><h1 class="page-title"><?php echo __('Blog','call-a-nerd-theme'); ?></h1></div>
    <?php }?>  

<?php   }  else if($featuresize =='nofeature') { ?>
<div class="sub-header">
    <div class="container">
        <h1 class="page-title"><?php echo __('Blog','call-a-nerd-theme');?></h1>
     
        <nav class="woocommerce-breadcrumb"><a href="<?php echo site_url();?>"><?php echo __('Home','call-a-nerd-theme');?></a>&nbsp;/&nbsp;<?php echo __('Blog','call-a-nerd-theme');?></nav>
    </div>
</div>
    

<?php   } ?>


<?php $blogseitendesign=of_get_option('blogseitendesign'); $blogseitendesigna=explode('-',$blogseitendesign); ?>
<div id="blog-template-type-<?php  echo $blogseitendesigna[1] ?>">

     <?php  $ec=((of_get_option('blog_layout')=='without-sidebar' || of_get_option('blog_layout')=='')?'sw':'') ?>   
	<div class="container blog-post <?php  echo $ec ?>">
    	<div class="row">

                
    
<?php             if(of_get_option('blog_layout')=='without-sidebar'){  $class='col-md-12'; }  
            else if(of_get_option('blog_layout')=='with-sidebar') {  $class='col-md-9'; }
            else if(of_get_option('blog_layout')=='with-sidebar-left'){ $class='col-md-9 pull-right'; }     ?>

            <div class="bp-listing content-left <?php echo $class ?>">
				<?php if($featuresize =='content' && of_get_option('blog_banner_image')!=''){ ?>
    <div class="sub-header sub-header-bg" style="background-image:url(<?php echo site_url().of_get_option('blog_banner_image')  ?>)">
        <?php if(of_get_option('blogpage_title_position')=='image_center'){?><div class="page-title">
            <h1><?php echo __('Blog','call-a-nerd-theme'); ?></h1>
        </div> <?php }?>   
    </div>
             <?php if(of_get_option('blogpage_title_position')=='image_under'){?> 
			<div class="container">
				<h1 class="page-title"><?php echo __('Blog','call-a-nerd-theme'); ?></h1></div>
				
    <?php }?>   
                <?php } ?>
                    <div class="blog-group"><?php if(of_get_option('blogseitendesign')=='template-1'){?><div class="row"><?php $counter = 1;while(have_posts()){ the_post(); ?> 
              
              <?php get_template_part( 'blog/content', of_get_option('blogseitendesign') ); ?>
           
						<?php  if($counter % 2 === 0) :?>
        </div><div class="row">
      <?php endif; ?>
					   <?php $counter++;} ?></div><?php }else{ ?><?php while(have_posts()){ the_post(); ?> 
              
              <?php get_template_part( 'blog/content', of_get_option('blogseitendesign') ); ?>
           
						
					   <?php } ?><?php } ?></div>
                       
            <?php 
$big = 999999999; // need an unlikely integer

the_posts_pagination( array( 'mid_size'  => 2 ) );

             ?>	

             		<?php /*
            if ( have_posts() ) :
    			
                if ( is_home() && ! is_front_page() ) : ?>
                    <!--<header>
                        <h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
                    </header>-->
    
                <?php
                endif;
    
             
                while ( have_posts() ) : the_post();
    
                    
					 the_post_thumbnail();
                    get_template_part( 'template-parts/content', get_post_format() );
    
                endwhile;
    
                the_posts_navigation();
    
            else :
    
                get_template_part( 'template-parts/content', 'none' );
    
            endif; */?>
        </div>
<?php if(of_get_option('blog_layout')=='with-sidebar' || of_get_option('blog_layout')=='with-sidebar-left'){ ?>
        <div class="content-right col-md-3 sidebar  <?php echo ((of_get_option('blog_layout')=='with-sidebar-left')?'pull-left':'') ?>"> 
        	<?php get_sidebar(); ?>
        </div>
        <?php   } ?>
        </div>
	</div><!-- container -->
    </div>

<?php
get_footer();
