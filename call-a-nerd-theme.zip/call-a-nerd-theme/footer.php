<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CaN
 */
?>
<script type="text/javascript">
	/*jQuery(window).load(function() {
	
		jQuery('.sub-header.sub-header-bg').parent().addClass('bgOverlay');
		jQuery('.feature-image').parent().addClass('bgOverlay');
	});*/

	jQuery('.sub-header.sub-header-bg').parent().addClass('bgOverlay');
	jQuery('.feature-image').parent().addClass('bgOverlay');

</script>
<?php
$showfooter=true;
if ( function_exists( 'is_cart' ) && function_exists( 'is_checkout' ) ) {
if(is_cart() || is_checkout()){$showfooter=false;}}
if($showfooter){
$instance=array();
?>

	</div><!-- #content -->

	<footer id="colophon" class="site-footer" role="contentinfo">
<div class="container">
<?php 	if(!is_active_sidebar('footer-sidebar')){ ?>	

<?php 

$nowi=of_get_option('number_of_widgets');

switch($nowi){
	case 2:
	$fc='col-sm-6';
	break;
	case 3:
	$fc='col-sm-4';
	break;
	case 4:
	$fc='col-sm-3';
	break;
	default:
	$fc='col-sm-3';

}

$args=array('before_widget' => '<div class="widget '.$fc.'">'); 

$text='<a href="<?php echo home_url() ?>"><img src="'.site_url().of_get_option('logo_uploader') .'" alt=""></a>'
?>

<?php the_widget( 'WP_Widget_Text', 'text='.$text, $args ); ?> 
 <?php the_widget( 'WP_Widget_Archives', $instance, $args ); ?> 
 <?php if($nowi==3 || $nowi==''){ ?>
 <?php the_widget( 'WP_Widget_Recent_Posts', $instance, $args ); ?> 	
 	<?php } ?>
 <?php if($nowi==4 || $nowi==''){ ?>
  <?php 	the_widget( 'WP_Widget_Search', $instance, $args );  ?>
	<?php } ?>
  
 

<?php 	} else { ?>
		<?php 	$nowi=of_get_option('number_of_widgets');  ?>		
		<?php 	switch($nowi){
	case 2:
	$fc='col-sm-6';
	break;
	case 3:
	$fc='col-sm-4';
	break;
	case 4:
	$fc='col-sm-3';
	break;
	default:
	$fc='col-sm-3';

}

 ?>
		<div class='widgetsection <?php 	echo $fc ?>'><?php 	dynamic_sidebar('footer-sidebar'); ?></div>
		
		<div class='widgetsection <?php 	echo $fc ?>'><?php 	dynamic_sidebar('footer-sidebar-2'); ?></div>
		<?php if($nowi>=3 || $nowi==''){ ?>
		<div class='widgetsection <?php 	echo $fc ?>'><?php 	dynamic_sidebar('footer-sidebar-3'); ?></div>
		<?php 	}  ?>
		<?php if($nowi==4 || $nowi==''){ ?>
		<div class='widgetsection <?php 	echo $fc ?>'><?php 	dynamic_sidebar('footer-sidebar-4'); ?></div>
		<?php 	} ?>

		<?php 	}  ?>
		</div>
		<div class='clearfix'></div>	
		
		<div class="site-info" style="display: none;">
			<a href="<?php echo esc_url( __( 'https://wordpress.org/', 'call-a-nerd-theme' ) ); ?>"><?php
				/* translators: %s: CMS name, i.e. WordPress. */
				printf( esc_html__( 'Proudly powered by %s', 'call-a-nerd-theme' ), 'Callanerd' );
			?></a>
			<span class="sep"> | </span>
			<?php
				/* translators: 1: Theme name, 2: Theme author. */
				printf( esc_html__( 'Theme: %1$s by %2$s.', 'call-a-nerd-theme' ), 'Call a Nerd Theme', '<a href="http://callanerd.de">Callanerd</a>' );
			?>
		</div><!-- .site-info -->
			
	</footer><!-- #colophon -->
</div><!-- #page -->
<?php }?>


<?php wp_footer();?>

</body>
</html>
