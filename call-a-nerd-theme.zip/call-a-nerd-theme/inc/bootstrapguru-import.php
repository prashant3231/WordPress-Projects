
<?php
echo "tst";
 class bootstrapguru_import extends WP_Import
{
    function check()
    {
    	
		$lp=get_page_by_path('rest');
		$bg=get_page_by_path('can-blog');
		update_option('show_on_front','page');
		update_option('page_for_posts',$bg->ID);
		update_option('page_on_front',$lp->ID);
    }
}
 ?>