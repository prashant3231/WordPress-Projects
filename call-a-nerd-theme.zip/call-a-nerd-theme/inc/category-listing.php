<?php
if(get_locale()=='de_DE' || get_locale()=='de_DE_formal' || get_locale()=='de_CH' || get_locale()=='de_CH_informal'){/**
 * Template Name: Beitrags Kategorie Liste
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package CaN
 */}else{
/**
 * Template Name: Category listing
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package CaN
 */
}

get_header(); ?>


<div class="sub-header">
    <div class="container">
        <h1 class="page-title"><?php  the_title() ?></h1>     
    </div>
</div>
    

<div id="blog-template-type-1">


	<div class="container blog-post">


    	<div class="row">
            <div class="bp-listing content-left col-sm-9">
<div class="blog-group">
                <?php   
                $cats=get_categories();
        
                foreach($cats as $value){
                                       ?>
                 <article class="post type-post status-publish format-standard  hentry category-allgemein">
                <div>
                    <header class="entry-header">
                         
                        <?php                  
                        $cat_id = $value->term_id;
                        $image_id = get_term_meta( $cat_id, 'category-image-id', true );
                        if($image_id!=''){
                                $imgsrc= wp_get_attachment_image_src( $image_id, array(560,310) );    
                                $imgsrc=$imgsrc[0]; ?>
                                <figure>
                                        <a href="<?php echo home_url() ?>/category/<?php     echo $value->slug  ?>"><img src="<?php   echo $imgsrc ?>"/></a>
                                 </figure>
                        <?php }  else { ?>
                            <a href='<?php echo home_url() ?>/category/<?php     echo $value->slug  ?>' ><img src='<?php echo esc_url( get_template_directory_uri("template_directory") ) ?>/images/no-image.jpg' />  </a>
   
                        <?php } ?>
                        
                     </header>

                                        <div class="entry-content clearfix">
                        <h2 class="post-title"><a href='<?php echo home_url() ?>/category/<?php     echo $value->slug  ?>'><?php echo $value->name; ?></a></h2>
                        <div class="post-desc col-sm-12">
                                        <?php   echo $value->category_describtion; ?>
                        </div>
                        </div>        
                     </div>
                </article>       

                <?php  } ?>
				</div>
        </div>

        <div class="content-right col-md-3 sidebar"> 
            <?php get_sidebar(); ?>
        </div>
        </div>
    </div><!-- container -->
    </div>

    
        </div>
	</div><!-- container -->

<?php
get_footer();
