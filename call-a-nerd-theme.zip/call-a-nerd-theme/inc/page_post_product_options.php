<?php 

function adding_custom_meta_boxes( $post_type, $post ) {
    add_meta_box( 
        'feature-image-placement',
        __( 'Featured image', 'call-a-nerd-theme' ),
        'feature_image_placement',
        array('page','post'),
        'side',
        'default'
    );

    add_meta_box( 		
        'Layout',
        __( 'Sidebar Position', 'call-a-nerd-theme' ),
        'Layout',
        array('post','product'),
        'side',
        'default'
    );

	add_meta_box( 		
        'width-desc-product',
        __( 'Width of the description', 'call-a-nerd-theme' ),
        'width_desc_product',
        array('product'),
        'side',
        'default'
    );

	
    add_meta_box( 
        'page_title_position',
        __( 'Position of main headline (h1)', 'call-a-nerd-theme' ),
        'page_title_position',
        array('page','post','product'),
        'side',
        'default'
    );

   
     
    add_meta_box( 
        'related-post',
        __( 'Related posts', 'call-a-nerd-theme'  ),
        'related_post',
        array('post'),
        'side',
        'default'
    );
}
add_action( 'add_meta_boxes', 'adding_custom_meta_boxes', 10, 2 );

function save_feature_box($post_id, $post, $update)
{
    if (isset($_POST["featuresize"]))
    update_post_meta($post_id,'featuresize',$_POST["featuresize"]);
    if (isset($_POST["headertype"]))
    update_post_meta($post_id,'headertype',$_POST["headertype"]);
	if (isset($_POST["relatedpost"]))
        update_post_meta($post_id,'relatedpost',$_POST["relatedpost"]);
	if (isset($_POST["layout"]))
                update_post_meta($post_id,'layout',$_POST["layout"]);
	if (isset($_POST["width_desc_product"]))
                update_post_meta($post_id,'width_desc_product',$_POST["width_desc_product"]);
	if (isset($_POST["excluderelatedpost"]))
    update_post_meta($post_id,'excluderelatedpost',$_POST["excluderelatedpost"]);
	if (isset($_POST["page_title_position"]))
    update_post_meta($post_id,'page_title_position',$_POST["page_title_position"]);
    
	}

add_action("save_post", "save_feature_box", 10, 3);

function feature_image_placement( $post, $metabox ) {
?>
<div>
            <label for="featuresize"><?php echo __( 'Image size', 'call-a-nerd-theme' ) ?></label><br>
            <select name="featuresize">
                <?php echo $featuresize=get_post_meta($post->ID, "featuresize", true); ?>
                 <option value='' <?php echo ( $featuresize==''?'selected':'') ?>><?php echo __( 'Like Theme setting', 'call-a-nerd-theme' ) ?></option>
               
                <option value='full' <?php echo ($featuresize=='full'?'selected':'') ?>><?php echo __( 'Fullwidth', 'call-a-nerd-theme' ) ?></option>
                <option value='box' <?php echo ($featuresize=='box'?'selected':'') ?>><?php echo __( '1170 pixel width', 'call-a-nerd-theme' ) ?></option>
                <option value='content' <?php echo ($featuresize=='content'?'selected':'') ?>><?php echo __( '1080 pixel width', 'call-a-nerd-theme' ) ?></option>
				
               <option value='nofeature' <?php echo ( $featuresize=='nofeature'?'selected':'') ?>><?php echo __( 'No featured image', 'call-a-nerd-theme' ) ?></option>
                </select>
                <br>

             <label for="headertype"><?php echo __( 'Header Design', 'call-a-nerd-theme' ) ?></label><br>
            <select name="headertype">
                <?php $headertype=get_post_meta($post->ID, "headertype", true); ?>
                <option value='' <?php echo ( $headertype==''?'selected':'') ?>><?php echo __( 'Like Theme setting', 'call-a-nerd-theme' ) ?></option>
                <option value='solid' <?php echo ($headertype=='solid'?'selected':'') ?>><?php echo __( 'Solid and separate', 'call-a-nerd-theme' ) ?></option>
                <option value='tao' <?php echo ($headertype=='tao'?'selected':'') ?>><?php echo __( 'Transparent and overlay', 'call-a-nerd-theme' ) ?></option>
            </select>

</div>
<?php
}

function layout( $post, $metabox ) { ?>


            <select name="layout">
                <?php $layout=get_post_meta($post->ID, "layout", true); ?>
                <option value='' <?php echo ($layout==''?'selected':'') ?>><?php echo __( 'Like Theme setting', 'call-a-nerd-theme' ) ?></option>  
                <option value='without-sidebar' <?php echo ($layout=='without-sidebar'?'selected':'') ?>><?php echo __( 'No Sidebar', 'call-a-nerd-theme' ) ?></option>
                <option value='with-sidebar-left' <?php echo ($layout=='with-sidebar-left'?'selected':'') ?>><?php echo __( 'Sidebar left', 'call-a-nerd-theme' ) ?></option>
                <option value='with-sidebar' <?php echo ($layout=='with-sidebar'?'selected':'') ?>><?php echo __( 'Sidebar right', 'call-a-nerd-theme' ) ?></option>
            </select>


<?php }

function width_desc_product( $post, $metabox ) { ?>


            <select name="width_desc_product">
                <?php $width_desc_product=get_post_meta($post->ID, "width_desc_product", true); ?>
                <option value='' <?php echo ($width_desc_product==''?'selected':'') ?>><?php echo __( 'Like Theme setting', 'call-a-nerd-theme' ) ?></option>  
                <option value='full' <?php echo ($width_desc_product=='full'?'selected':'') ?>><?php echo __( 'fullwidth', 'call-a-nerd-theme' ) ?></option>
                <option value='box' <?php echo ($width_desc_product=='box'?'selected':'') ?>><?php echo __( 'with in container', 'call-a-nerd-theme' ) ?></option>
            </select>


<?php }


function page_title_position( $post, $metabox ) { ?>
<?php $page_title_position=get_post_meta($post->ID, "page_title_position", true); ?>
<select class="of-input" name="page_title_position" id="page_title_position"><option value="" <?php echo ($page_title_position==''?'selected':'') ?>><?php echo __( 'Like Theme setting', 'call-a-nerd-theme' ) ?></option>
<option value="image_under" <?php echo ($page_title_position=='image_under'?'selected':'') ?>><?php echo __( 'Below the image', 'call-a-nerd-theme' ) ?></option>
<option <?php echo ($page_title_position=='image_center'?'selected':'') ?>  value="image_center"><?php echo __( 'On image centered', 'call-a-nerd-theme' ) ?></option>
<option <?php echo ($page_title_position=='hide'?'selected':'') ?>  value="hide"><?php echo __( 'Hide', 'call-a-nerd-theme' ) ?></option>
</select>
<?php }



function related_post( $post, $metabox ) {
    $relatedpost=get_post_meta($post->ID, "relatedpost", true);
    $excluderelatedpost=get_post_meta($post->ID, "excluderelatedpost", true);

?>
<div>
            <label for="featuresize"><?php echo __('Show/Hide Related Post','call-a-nerd-theme');?></label><br>

            <select  name="relatedpost">
            
            <option  value='0' <?php if($relatedpost=='0')echo "selected"; ?>><?php echo __('Show related posts','call-a-nerd-theme');?></option>
            <option  value='1' <?php if($relatedpost=='1')echo "selected"; ?>><?php echo __("Don't show related Posts",'call-a-nerd-theme');?></option>
            <option  value='' <?php if($relatedpost=='')echo "selected"; ?>><?php echo __('Like Theme Options','call-a-nerd-theme');?></option>
            </select><br>
            <input type="checkbox" name="excluderelatedpost" value='1' <?php echo ($excluderelatedpost=='1'?'checked':'') ?>> 

            <?php   if($_GET['post_type']!='page' || get_post_type($post->ID)!='page'){ ?>    
            <label for="featuresize"><?php echo __("Don't Show this post as related post on other pages",'call-a-nerd-theme');?></label><br>
             <?php  } ?>
</div>
<?php
}

// A callback function to add a custom field to our "presenters" taxonomy  
function presenters_taxonomy_custom_fields($tag) {  
   // Check for existing taxonomy meta for the term you're editing  
    $t_id = $tag->term_id; // Get the ID of the term you're editing  
    $term_meta = get_option( "taxonomy_term_$t_id" ); // Do the check  
?>  
              <tr class="form-field">
<th scope="row" valign="top"><label for="layout"><?php echo __( 'Sidebar position', 'call-a-nerd-theme' ) ?></label></th>
<td>

             <?php $term_meta=get_option('taxonomy_term_'.$t_id);
             ?>   
            <select name="term_meta[term_layout]">
                    <?php   $term_layout=$term_meta['term_layout'] ?> 
                 <option value='' <?php echo ($term_layout==''?'selected':'') ?>><?php echo __( 'Like Theme setting', 'call-a-nerd-theme' ) ?></option> 
                <option value='without-sidebar' <?php echo ($term_layout=='without-sidebar'?'selected':'') ?>><?php echo __( 'No Sidebar', 'call-a-nerd-theme' ) ?></option>
                <option value='with-sidebar' <?php echo ($term_layout=='with-sidebar'?'selected':'') ?>><?php echo __( 'Sidebar right', 'call-a-nerd-theme' ) ?></option>
                <option value='with-sidebar-left' <?php echo ($term_layout=='with-sidebar-left'?'selected':'') ?>><?php echo __( 'Sidebar left ', 'call-a-nerd-theme' ) ?></option>
                
            </select></td>
</tr>
<tr class="form-field">
<th scope="row" valign="top">
                 <label for="featuresize"><?php echo __( 'Image size', 'call-a-nerd-theme' ) ?></label></th><td>
            <select name="term_meta[term_featuresize]">
                <?php $term_featuresize=$term_meta['term_featuresize'] ?>
				<option value='none' <?php echo ( $term_featuresize=='none'?'selected':'') ?>><?php echo __( 'Like Theme setting', 'call-a-nerd-theme' ) ?></option>
                <option value='full' <?php echo ($term_featuresize=='full'?'selected':'') ?> <?php echo ($term_featuresize==''?'selected':'') ?>><?php echo __( 'Fullwidth', 'call-a-nerd-theme' ) ?></option>
                <option value='box' <?php echo ($term_featuresize=='box'?'selected':'') ?>><?php echo __( '1170 pixel width', 'call-a-nerd-theme' ) ?></option>  <?php if($tag->taxonomy!='product_cat' && $tag->taxonomy!='product_tag'){?>
                <option value='content' <?php echo ($term_featuresize=='content'?'selected':'') ?>><?php echo __( '1080 pixel width', 'call-a-nerd-theme' ) ?></option><?php }?>
                <option value='nofeature' <?php echo ( $term_featuresize=='nofeature'?'selected':'') ?>><?php echo __( 'No featured image', 'call-a-nerd-theme' ) ?></option>
                
                   
	</select></td></tr>


    <?php if($tag->taxonomy!='product_cat' && $tag->taxonomy!='product_tag'){?><tr class="form-field">
<th scope="row" valign="top"><label for="headertype"><?php echo __( 'Page design', 'call-a-nerd-theme' ) ?></label></th><td>
            <select name="term_meta[template]">
                    <?php   $term_layout=$term_meta['template'] ?>
                <option value='template-1' <?php echo ($term_layout=='template-1'?'selected':'') ?>><?php echo __( 'Two posts side by side', 'call-a-nerd-theme' ) ?></option>
                <option value='template-2' <?php echo ($term_layout=='template-2'?'selected':'') ?>><?php echo __( 'One post at full width', 'call-a-nerd-theme' ) ?></option>
                    <option value='template-3' <?php echo ($term_layout=='template-3'?'selected':'') ?>><?php echo __( 'Picture left text right', 'call-a-nerd-theme' ) ?></option>>
                <option value='' <?php echo ($term_layout==''?'selected':'') ?>><?php echo __( 'Like Theme setting', 'call-a-nerd-theme' ) ?></option>  
		</select></td></tr><?php }?><tr class="form-field">
<th scope="row" valign="top"><label for="headertype"><?php echo __( 'Position of main headline (h1)', 'call-a-nerd-theme' ) ?></label></th><td>
            <select name="term_meta[catpage_title_position]">
                    <?php   $term_layout=$term_meta['catpage_title_position'] ?>
				 <option value='' <?php echo ($term_layout==''?'selected':'') ?>><?php echo __( 'Like Theme setting ', 'call-a-nerd-theme' ) ?></option>
                <option value='image_center' <?php echo ($term_layout=='image_center'?'selected':'') ?> <?php echo ($term_layout==''?'selected':'') ?>><?php echo __( 'On image centered', 'call-a-nerd-theme' ) ?></option>
                <option value='image_under' <?php echo ($term_layout=='image_under'?'selected':'') ?>><?php echo __( 'Below the image', 'call-a-nerd-theme' ) ?></option>
                 
			</select></td></tr>


            <style type="text/css">
                .catc label {
    vertical-align: top;
    text-align: left;
    padding: 20px 10px 20px 0;
    width: 200px;
    line-height: 1.3;
    font-weight: 600;
    color: #000;
}
.catc input, .catc select {
    width: 66%;
    float: left;
    display: inline-block;
    clear: right;
}
.catc label {
    width: 27%;
    float: left;
    display: inline-block;
}

            </style>


<?php  
} 

function save_taxonomy_custom_fields( $term_id ) {  
    if ( isset( $_POST['term_meta'] ) ) {  
        $t_id = $term_id;  
        $term_meta = get_option( "taxonomy_term_$t_id" );  
        $cat_keys = array_keys( $_POST['term_meta'] );  
            foreach ( $cat_keys as $key ){  
            if ( isset( $_POST['term_meta'][$key] ) ){  
                $term_meta[$key] = $_POST['term_meta'][$key];  
            }  
        }  

        //save the option array  
        update_option( "taxonomy_term_$t_id", $term_meta );  
    }  
}  

// Add the fields to the "presenters" taxonomy, using our callback function  
add_action( 'product_tag_edit_form_fields', 'presenters_taxonomy_custom_fields', 1, 2 );  
add_action( 'product_tag_add_form_fields', 'presenters_taxonomy_custom_fields', 1, 2 );

// Save the changes made on the "presenters" taxonomy, using our callback function  
add_action( 'edited_product_tag', 'save_taxonomy_custom_fields', 10, 2 ); 
add_action( 'created_product_tag', 'save_taxonomy_custom_fields', 10, 2 ); 

// Add the fields to the "presenters" taxonomy, using our callback function  
add_action( 'product_cat_edit_form_fields', 'presenters_taxonomy_custom_fields', 1, 2 );  
add_action( 'product_cat_add_form_fields', 'presenters_taxonomy_custom_fields', 1, 2 );

// Save the changes made on the "presenters" taxonomy, using our callback function  
add_action( 'edited_product_cat', 'save_taxonomy_custom_fields', 10, 2 ); 
add_action( 'created_product_cat', 'save_taxonomy_custom_fields', 10, 2 );  


// Add the fields to the "presenters" taxonomy, using our callback function  
add_action( 'category_edit_form_fields', 'presenters_taxonomy_custom_fields', 1, 2 );  
add_action( 'category_add_form_fields', 'presenters_taxonomy_custom_fields', 1, 2 );

// Save the changes made on the "presenters" taxonomy, using our callback function  
add_action( 'edited_category', 'save_taxonomy_custom_fields', 10, 2 ); 
add_action( 'created_category', 'save_taxonomy_custom_fields', 10, 2 );  



// Add the fields to the "presenters" taxonomy, using our callback function  
add_action( 'post_tag_edit_form_fields', 'presenters_taxonomy_custom_fields', 1, 2 );  
add_action( 'post_tag_add_form_fields', 'presenters_taxonomy_custom_fields', 1, 2 );

// Save the changes made on the "presenters" taxonomy, using our callback function  
add_action( 'edited_post_tag', 'save_taxonomy_custom_fields', 10, 2 ); 
add_action( 'created_post_tag', 'save_taxonomy_custom_fields', 10, 2 );  

add_action( 'add_meta_boxes', 'background_color_image_add_meta_box' );
if ( ! function_exists( 'background_color_image_add_meta_box' ) ) {
function background_color_image_add_meta_box(){
add_meta_box( 
        'background_color_image',
        __( 'Background Selection' ,'call-a-nerd-theme'),
        'background_color_image_meta_box',
        array('page','post','product'),
        'side',
        'default'
    );
	}
}

add_action( 'admin_enqueue_scripts', 'background_color_image_backend_scripts');
if ( ! function_exists( 'background_color_image_backend_scripts' ) ){
function background_color_image_backend_scripts( $hook ) {
wp_enqueue_style( 'wp-color-picker');
wp_enqueue_script( 'wp-color-picker');
}
}

function admin_scripts() {
        wp_enqueue_script('media-upload');
        wp_enqueue_script('thickbox');
    }

    function admin_styles() {
        wp_enqueue_style('thickbox');
    }
    add_action('admin_print_scripts', 'admin_scripts');
    add_action('admin_print_styles', 'admin_styles');

if ( ! function_exists( 'background_color_image_meta_box' ) ) {
	function background_color_image_meta_box( $post ) {
		$custom = get_post_custom( $post->ID );
		
		wp_nonce_field( 'background_color_image_meta_box', 'background_color_image_meta_box_nonce' );
		
        $value = ( isset( $custom['background_type'][0] ) ) ? $custom['background_type'][0] : ''; 
		$background_color = ( isset( $custom['background_color'][0] ) ) ? $custom['background_color'][0] : '';
		$background_texture_style = ( isset( $custom['background_texture_style'][0] ) ) ? $custom['background_texture_style'][0] : '';

        ?>
        <label for="wdm_new_field"><?php echo __( 'Select Global Background Color/Texture' ,'call-a-nerd-theme' ); ?>:</label>
        <br />  
        <input type="radio" name="background_type" id="background_type_lthemeop" value="lthemeop" <?php if($value=='lthemeop')echo "checked"; else echo "checked"; ?> ><?php echo __( 'Like Theme Options' ,'call-a-nerd-theme');?><br />
        <input type="radio" name="background_type" id="background_type_color" value="bcolor" <?php if($value=='bcolor')echo "checked"; ?> ><?php echo __( 'Background Color' ,'call-a-nerd-theme');?><br />
        <input type="radio" name="background_type" id="background_type_image" value="bimage" <?php if($value=='bimage')echo "checked"; ?> ><?php echo __( 'Background Texture' ,'call-a-nerd-theme');?><br />
		<script>
		jQuery(document).ready(function($){
		    $('.color_field').each(function(){
        		$(this).wpColorPicker();
    		    });
		});
		</script>
		<div class="pagebox" id="background_color_box">
		    <p><?php echo __( 'Background Color' ,'call-a-nerd-theme');?>:</p>
		    <input class="color_field" type="hidden" name="background_color" value="<?php echo $background_color; ?>"/>
		</div><?php 
    global $wpdb;
     $strFile = get_post_meta($post -> ID, $key = 'podcast_file', true);
     $media_file = get_post_meta($post -> ID, $key = '_wp_attached_file', true);
		if($strFile=='')$strFile=( isset( $custom['podcast_file'][0] ) ) ? $custom['podcast_file'][0] : '';
		if($media_file=='')$media_file=( isset( $custom['_wp_attached_file'][0] ) ) ? $custom['_wp_attached_file'][0] : '';
		
    if (!empty($media_file)) {
        $strFile = $media_file;
    } ?>


    <script type = "text/javascript">

        // Uploading files
        var file_frame;
		 jQuery('#remove_image_button').live('click', function(podcast) { jQuery('#podcast_file').attr('value','');});
    jQuery('#upload_image_button').live('click', function(podcast) {

        podcast.preventDefault();

        // If the media frame already exists, reopen it.
        if (file_frame) {
            file_frame.open();
            return;
        }

        // Create the media frame.
        file_frame = wp.media.frames.file_frame = wp.media({
            title: jQuery(this).data('uploader_title'),
            button: {
                text: jQuery(this).data('uploader_button_text'),
            },
            multiple: false // Set to true to allow multiple files to be selected
        });

        // When a file is selected, run a callback.
        file_frame.on('select', function(){
            // We set multiple to false so only get one image from the uploader
            attachment = file_frame.state().get('selection').first().toJSON();

            // here are some of the variables you could use for the attachment;
            //var all = JSON.stringify( attachment );      
            //var id = attachment.id;
            //var title = attachment.title;
            //var filename = attachment.filename;
            var url = attachment.url;
            //var link = attachment.link;
            //var alt = attachment.alt;
            //var author = attachment.author;
            //var description = attachment.description;
            //var caption = attachment.caption;
            //var name = attachment.name;
            //var status = attachment.status;
            //var uploadedTo = attachment.uploadedTo;
            //var date = attachment.date;
            //var modified = attachment.modified;
            //var type = attachment.type;
            //var subtype = attachment.subtype;
            //var icon = attachment.icon;
            //var dateFormatted = attachment.dateFormatted;
            //var editLink = attachment.editLink;
            //var fileLength = attachment.fileLength;

            var field = document.getElementById("podcast_file");

            field.value = url; //set which variable you want the field to have
        });

        // Finally, open the modal
        file_frame.open();
    });


    </script>



    <div id="background_image_box">
<label><?php echo __('Background Texture', 'call-a-nerd-theme');?>:</label><br><img src="<?php if($strFile)echo site_url().$strFile; else echo get_template_directory_uri() .'/images/noimage.png'; ?>" style="width: 50px;height:50px;"/>
        <table>
        <tr valign = "top">
        <td width= "70%">
        <input type = "text" placeholder="<?php echo __('Background Texture', 'call-a-nerd-theme');?>"
    name = "podcast_file"
    id = "podcast_file"
			   value = "<?php echo $strFile; ?>" style="width:100px;"/></td><td width="10%"><input id = "upload_image_button"
    type = "button"
    value = "<?php echo __('Upload','call-a-nerd-theme');?>">
        </td><td width="10%"><input id = "remove_image_button"
    type = "button"
    value = "<?php echo __('Remove','call-a-nerd-theme');?>">
        </td> </tr> </table> <input type = "hidden"
    name = "img_txt_id"
    id = "img_txt_id"
    value = "" />
		<label><?php echo __('Background Texture Style', 'call-a-nerd-theme');?>:</label><select name="background_texture_style" id="background_texture_style">
		<option value="fixed" <?php if($background_texture_style=='fixed')echo "selected"; ?>><?php echo __('Fixed','call-a-nerd-theme');?></option>
		<option value="repeat" <?php if($background_texture_style=='repeat')echo "selected"; ?>><?php echo __('Repeating','call-a-nerd-theme');?></option>
		<option value="no-repeat" <?php if($background_texture_style=='no-repeat' || $background_texture_style=='' || !$background_texture_style)echo "selected"; ?>><?php echo __('Stretched','call-a-nerd-theme');?></option>
		</select>
        </div>  <script>jQuery("#background_color_box").slideUp();jQuery("#background_image_box").slideUp();if (jQuery("#background_type_lthemeop:checked").val()) {jQuery("#background_color_box").slideUp();jQuery("#background_image_box").slideUp();}if (jQuery("#background_type_color:checked").val()) {jQuery("#background_color_box").slideDown();}if (jQuery("#background_type_image:checked").val()) {jQuery("#background_image_box").slideDown();}jQuery("#background_type_lthemeop").click(function(){jQuery("#background_color_box").slideUp();jQuery("#background_image_box").slideUp();
});jQuery("#background_type_color").click(function(){jQuery("#background_color_box").slideDown();jQuery("#background_image_box").slideUp();
});jQuery("#background_type_image").click(function(){jQuery("#background_image_box").slideDown();jQuery("#background_color_box").slideUp();}); </script>   <?php
    

	}
}

if ( ! function_exists( 'background_color_image_save_meta_box' ) ) {
	function background_color_image_save_meta_box( $post_id ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return $post_id;
		}
		if( !current_user_can( 'edit_pages' ) ) {
			return;
		}
		if(defined('DOING_AJAX')) {
            return;
        }
		if($post->post_type == 'revision') {
            return;
        }
		if ( !isset( $_POST['background_type'] ) || !wp_verify_nonce( $_POST['background_color_image_meta_box_nonce'], 'background_color_image_meta_box' ) ) {
			return;
		}
		
		 // Sanitize user input.
        $background_type = ( isset( $_POST['background_type'] ) ? sanitize_html_class( $_POST['background_type'] ) : '' );
		update_post_meta( $post_id, 'background_type', $background_type );
		
		$background_color = (isset($_POST['background_color']) && $_POST['background_color']!='') ? $_POST['background_color'] : '';
		update_post_meta($post_id, 'background_color', $background_color);
		// We'll put it into an array to make it easier to loop though.
		$podcast_file = get_post_meta($post -> ID, $key = 'podcast_file', true);
     $media_file = get_post_meta($post -> ID, $key = '_wp_attached_file', true);
		if($podcast_file=='')$podcast_file=( isset( $custom['podcast_file'][0] ) ) ? $custom['podcast_file'][0] : '';
		if($media_file=='')$media_file=( isset( $custom['_wp_attached_file'][0] ) ) ? $custom['_wp_attached_file'][0] : '';
		
    if (!empty($media_file)) {
        $podcast_file = $media_file;
    }
		if(isset($_REQUEST['podcast_file']))
		$podcast_file=str_replace(site_url()."/", "/", $_REQUEST['podcast_file']);
    $podcasts_meta['podcast_file'] = $podcast_file;
    // Add values of $podcasts_meta as custom fields

    foreach($podcasts_meta as $key => $value) {
        
        $value = implode(',', (array) $value);
        if ( $value) { // If the custom field already has a value it will update
            update_post_meta($post_id, $key, $value);
        } else { // If the custom field doesn't have a value it will add
            add_post_meta($post_id, $key, $value);
        }
        if (!$value)delete_post_meta($post_id, $key); // Delete if blank value
    }
	
	 // Sanitize user input.
       $background_texture_style = ( isset( $_POST['background_texture_style'] ) ? sanitize_html_class( $_POST['background_texture_style'] ) : '' );
		update_post_meta( $post_id, 'background_texture_style', $background_texture_style );
    
	}
}
 
add_action( 'save_post', 'background_color_image_save_meta_box' );