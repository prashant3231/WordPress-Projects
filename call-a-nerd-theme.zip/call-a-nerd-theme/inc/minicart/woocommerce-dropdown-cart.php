<?php


class WooCommerce_Widget_DropdownCart extends WP_Widget {

    var $default_values = array(
        'title' => '',
        'hide_if_empty' => 1,
        'show_on_checkout' => 0,
        'popup_align' => 'left'
    );

    function __construct() {

        /* Widget settings. */
        $widget_options = array(
            'classname' => 'widget_shopping_mini_cart dropdown-cart',
            'description' => __( "Display the cart content", 'call-a-nerd-theme' )
        );

        /* Create the widget. */
        parent::__construct( 'widget_shopping_mini_cart', __( 'WooCommerce Dropdown Cart', 'call-a-nerd-theme' ), $widget_options );
    }


    function widget( $args, $instance ) {
if(of_get_option('show_hide_top_cart')=='show'){
        $instance = wp_parse_args($instance, $this->default_values);

        if(empty($instance['show_on_checkout']) && (is_cart() || is_checkout())){
            return;
        }

        $woocommerce = WC();

        $before_widget = $after_widget = $before_title = $after_title = '';
        extract( $args, EXTR_OVERWRITE );


        $hide_if_empty = empty( $instance['hide_if_empty'] )  ? 0 : 1;
        $popup_align = $instance['popup_align'] == 'left'?'left':'right';

        echo $before_widget;

        $title = apply_filters('widget_title', $instance['title']);
        if ( $title )
            echo $before_title . $title .$after_title;

        $cart_contents_count = $woocommerce->cart->get_cart_contents_count();

        $item_text = __('item', 'call-a-nerd-theme');
        $items_text = __('items', 'call-a-nerd-theme');

        ?>

        <div class="widget_shopping_mini_cart_content" id="<?php echo $this->id ?>-content">
            
                <div class="dropdown-cart-button <?php echo $hide_if_empty ? 'hide_dropdown_cart_widget_if_empty' : '' ?>" style="<?php echo $hide_if_empty && sizeof( $woocommerce->cart->get_cart() ) == 0 ? "display:block;":"" ?>">
                    <a href="#" class="dropdown-total">
					
						<?php if(of_get_option('top_cart_display')=='number')echo $cart_contents_count; else echo "<style>a.dropdown-total .woocommerce-Price-amount.amount{margin-left:90%;}</style>".$woocommerce->cart->get_cart_total(); ?>
					</a>
                    <div class="dropdown dropdown-<?php echo $popup_align ?>">
                        <?php woocommerce_mini_cart(); ?>
                        <div class="clear"></div>
                    </div>

                </div>
           <script>jQuery('div.dropdown-cart-button').on('mouseenter', function(){
        jQuery('.dropdown-cart-button .dropdown').stop(true, false).fadeIn({ duration: '500', queue: false }).css('display', 'none').slideDown('500');
    });jQuery('div.dropdown-cart-button').on('mouseleave', function(){
        jQuery('.dropdown-cart-button .dropdown').stop(true, false).fadeOut({ duration: '500', queue: false }).slideUp('500');
    });jQuery('a.dropdown-total').on('click', function(){location.href='<?php global $woocommerce;
echo $aUrl = $woocommerce->cart->get_cart_url();?>';});</script>
        </div>
        <?php
        echo $after_widget;
}
    }


    /**
     * update function.
     *
     * @see WP_Widget->update
     * @access public
     * @param array $new_instance
     * @param array $old_instance
     * @return array
     */
    function update( $new_instance, $old_instance ) {
        $instance['title'] = strip_tags( stripslashes( $new_instance['title'] ) );
        $instance['hide_if_empty'] = empty( $new_instance['hide_if_empty'] ) ? 0 : 1;
        $instance['show_on_checkout'] = empty( $new_instance['show_on_checkout'] ) ? 0 : 1;
        $instance['popup_align'] = $new_instance['popup_align'];
        return $instance;
    }


    /**
     * form function.
     *
     * @see WP_Widget->form
     * @access public
     * @param array $instance
     * @return void
     */
    function form( $instance ) {

        $instance = wp_parse_args($instance, $this->default_values);

        $hide_if_empty = empty( $instance['hide_if_empty'] ) ? 0 : 1;
        $show_on_checkout = empty( $instance['show_on_checkout'] ) ? 0 : 1;
        ?>
        <p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'call-a-nerd-theme') ?></label>
            <input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" value="<?php if (isset ( $instance['title'])) {echo esc_attr( $instance['title'] );} ?>" /></p>

        <p><input type="checkbox" class="checkbox" id="<?php echo esc_attr( $this->get_field_id('hide_if_empty') ); ?>" name="<?php echo esc_attr( $this->get_field_name('hide_if_empty') ); ?>"<?php checked( $hide_if_empty ); ?> />
            <label for="<?php echo $this->get_field_id('hide_if_empty'); ?>"><?php _e( 'Hide if cart is empty', 'call-a-nerd-theme' ); ?></label></p>

        <p><input type="checkbox" class="checkbox" id="<?php echo esc_attr( $this->get_field_id('show_on_checkout') ); ?>" name="<?php echo esc_attr( $this->get_field_name('show_on_checkout') ); ?>"<?php checked( $show_on_checkout ); ?> />
            <label for="<?php echo $this->get_field_id('show_on_checkout'); ?>"><?php _e( 'Show this widget on cart/checkout pages', 'call-a-nerd-theme' ); ?></label></p>
        <p>
            <label for="<?php echo $this->get_field_id('popup_align') ?>"><?php _e('Popup align:', 'call-a-nerd-theme') ?></label>
            <select name="<?php echo $this->get_field_name('popup_align') ?>" id="<?php echo $this->get_field_id('popup_align') ?>" class="widefat">
                <option value="left" <?php selected('left', $instance['popup_align']) ?>><?php _e('Left', 'call-a-nerd-theme') ?></option>
                <option value="right" <?php selected('right', $instance['popup_align']) ?>><?php _e('Right', 'call-a-nerd-theme') ?></option>
            </select>
        </p>
    <?php
    }



}

function register_WooCommerce_Widget_DropdownCart() {
    if(class_exists('Woocommerce')) {
        register_widget('WooCommerce_Widget_DropdownCart');
    }
}

add_action( 'widgets_init', 'register_WooCommerce_Widget_DropdownCart' );

function register_script_WooCommerce_Widget_DropdownCart() {
    if(class_exists('Woocommerce')) {
        if( !is_admin() ){
            wp_enqueue_script('jquery');

            $suffix = !WP_DEBUG ? '.min' : ''; 
            wp_enqueue_style('jquery-dropdown-cart', get_template_directory_uri('template_directory').'/inc/minicart/css/style'.$suffix.'.css');



        }
    }
}
add_action( 'wp_enqueue_scripts', 'register_script_WooCommerce_Widget_DropdownCart' );

add_action( 'plugins_loaded', 'woocommerce_ddc_load_textdomain' );
function woocommerce_ddc_load_textdomain(){
    $domain = "call-a-nerd-theme";

    $locale = apply_filters('plugin_locale', get_locale(), $domain);
    load_textdomain($domain, WP_LANG_DIR.'/'.$domain.'-'.$locale.'.mo');
    load_plugin_textdomain( $domain, false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
}
