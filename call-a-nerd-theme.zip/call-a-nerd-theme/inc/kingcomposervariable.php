<?php 

$kingcomposer['column']=array(
				array(
					'screens' => "any",
					'Typography2' => array(
						array('property' => 'color', 'label' => 'Farbe'),
						array('property' => 'font-size', 'label' => 'Schriftgröße'),
						array('property' => 'font-weight', 'label' => 'Schriftstärke'),
						array('property' => 'font-style', 'label' => 'Schriftstil'),
						array('property' => 'font-family', 'label' => 'Schriftfamilie'),
						array('property' => 'text-align', 'label' => 'Textausrichtung'),
						array('property' => 'text-shadow', 'label' => 'Text Schatten'),
						array('property' => 'text-transform', 'label' => 'Textumwandlung'),
						array('property' => 'text-decoration', 'label' => 'Textdekoration'),
						array('property' => 'line-height', 'label' => 'Zeilenhöhe'),
						array('property' => 'letter-spacing', 'label' => 'Wortabstand'),
						array('property' => 'overflow', 'label' => 'Überlauf'),
						array('property' => 'word-break', 'label' => 'Wortbruch'),
					),

					//Background group
					'Background' => array(
						array('property' => 'background', 'label' => 'Hintergrundfarbe'),
					),

					//Box group
					'Box' => array(

						array('property' => 'width', 'label' => 'Breite'),
						array('property' => 'margin', 'label' => 'Marge'),
						array('property' => 'padding', 'label' => 'Innenabstand'),
						array('property' => 'border', 'label' => 'Rand'),
						array('property' => 'height', 'label' => 'Höhe'),
						array('property' => 'border-radius', 'label' => 'Rand Radius'),
						array('property' => 'float', 'label' => 'Float'),
						array('property' => 'display', 'label' => 'Display'),
						array('property' => 'box-shadow', 'label' => 'Box Schatten'),
						array('property' => 'opacity', 'label' => 'Opacity'),
					),

					//Custom code css
					'Custom' => array(
						array('property' => 'custom', 'label' => 'Custom CSS')
					)
				),
				array(
					"screens" => "1024,999,767,479",
					'Typography' => array(

						array('property' => 'font-size', 'label' => 'Schriftgröße'),
						array('property' => 'text-align', 'label' => 'Textausrichtung'),
						array('property' => 'line-height', 'label' => 'Zeilenhöhe'),
						array('property' => 'overflow', 'label' => 'Überlauf'),
						array('property' => 'word-break', 'label' => 'Wortbruch'),
						array('property' => 'custom', 'label' => 'Custom CSS')
					),

					//Background group
					'Background' => array(
						array('property' => 'background-color' ,'label' => 'Hintergrundfarbe' ),
					),

					//Box group
					'Box' => array(
						array('property' => 'width', 'label' => 'Breite'),
						array('property' => 'margin', 'label' => 'Marge'),
						array('property' => 'padding', 'label' => 'Innenabstand'),
						array('property' => 'border', 'label' => 'Rand'),
						array('property' => 'height', 'label' => 'Höhe'),
						array('property' => 'border-radius', 'label' => 'Rand Radius'),
						array('property' => 'float', 'label' => 'Float'),
						array('property' => 'display', 'label' => 'Display'),
					),

					'Custom' => array(
						array('property' => 'custom', 'label' => 'Custom CSS')
					)
				)
			);

 ?>