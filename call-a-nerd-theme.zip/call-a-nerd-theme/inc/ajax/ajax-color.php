<?php 
add_action( 'wp_ajax_get_color', 'my_action' );
add_action( 'wp_ajax_nopriv_get_color', 'my_action' );



function my_action() {
	global $wpdb; // this is how you get access to the database
	require get_template_directory() . '/inc/includes/default-color.php';
	$colorschome=json_decode(get_option('all_color_scheme'),true);
	echo json_encode($colorschome[$_POST['color']]);
	
	die();
}



add_action( 'wp_ajax_my_scheme', 'my_scheme' );
add_action( 'wp_ajax_nopriv_my_scheme', 'my_scheme' );

function my_scheme() {
	global $wpdb; // this is how you get access to the database
	$colorschome=json_decode(get_option('all_color_scheme'),true);
	$all_color_scheme_pair=json_decode(get_option('all_color_scheme_pair'),true);

			$choosecolor=$_POST['choosecolor'];
			$all_color_scheme_pair[$_POST['choosecolor']]=$_POST['choosename'];

			unset($_POST['choosename']);
			unset($_POST['choosecolor']);
			unset($_POST['my_scheme']);
			
			$colorschome[$choosecolor]=$_POST;
			
			update_option('all_color_scheme',json_encode($colorschome));
			update_option('all_color_scheme_pair',json_encode($all_color_scheme_pair));


	die();
}
add_action( 'wp_ajax_addpost', 'addpost' );
add_action( 'wp_ajax_nopriv_addpost', 'addpost' );

function addpost() {
	$options=get_option('options-framework-theme');
	$list_cui=$options['list_cui'];
	$list_cui[]=$_POST['newpost'];
    $options['list_cui']=$list_cui;
    update_option('options-framework-theme',$options);
         flush_rewrite_rules();
die;
}