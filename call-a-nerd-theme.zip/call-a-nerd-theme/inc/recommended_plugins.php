<?php require_once get_template_directory() . '/inc/includes/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'my_theme_register_required_plugins' );
 
function my_theme_register_required_plugins() {
 
 /**
 * Array of plugin arrays. Required keys are name and slug.
 * If the source is NOT from the .org repo, then source is also required.
 */
 $plugins = array(
 array(
 'name'     => 'Fastest Cache - Das meiner Meinung nach schnellste Caching Plugin', // The plugin name
 'slug'     => 'wp-fastest-cache', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/wp-fastest-cache.0.9.0.0.zip', // The plugin source
 'required' => true, // If false, the plugin is only 'recommended' instead of required
 'version' => '0.9.0.0', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
 
   array(
 'name'     => 'King Composer - Visual Editor', // The plugin name
 'slug'     => 'kingcomposer', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/kingcomposer.zip', // The plugin source
 'required' => true, // If false, the plugin is only 'recommended' instead of required
 'version' => '2.9', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
	 array(
 'name'     => 'Yoast SEO - Suchmaschinenoptimierung', // The plugin name
 'slug'     => 'wordpress-seo', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/wordpress-seo.12.7.1.zip', // The plugin source
 'required' => true, // If false, the plugin is only 'recommended' instead of required
 'version' => '12.7.1', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
  array(
 'name'     => 'Wordfence Security - Anti Virus Scanner', // The plugin name
 'slug'     => 'wordfence', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/wordfence.7.4.2.zip', // The plugin source
 'required' => true, // If false, the plugin is only 'recommended' instead of required
 'version' => '7.4.2', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
 
 array(
 'name'     => 'WP Smush - automatically optimize images to the ideal size during upload', // The plugin name
 'slug'     => 'wp-smushit', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/wp-smushit.3.3.2.zip', // The plugin source
 'required' => true, // If false, the plugin is only 'recommended' instead of required
 'version' => '3.3.2', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
 
 array(
 'name'     => 'Anti Spam Bee- Auto Anti Spam', // The plugin name
 'slug'     => 'antispam-bee', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/antispam-bee.2.9.1.zip', // The plugin source
 'required' => true, // If false, the plugin is only 'recommended' instead of required
 'version' => '2.9.1', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
 
  array(
 'name'     => 'Disable Gutenberg - Gutenberg blockiert den King Composer und muss deaktiviert werden', // The plugin name
 'slug'     => 'disable-gutenberg', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/disable-gutenberg.2.0.zip', // The plugin source
 'required' => true, // If false, the plugin is only 'recommended' instead of required
 'version' => '2.0', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
	 array(
 'name'     => 'EU Cookie Law - Cookiebanner', // The plugin name
 'slug'     => 'eu-cookie-law', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/eu-cookie-law.zip', // The plugin source
 'required' => true, // If false, the plugin is only 'recommended' instead of required
 'version' => '3.1', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
 
 array(
 'name'     => 'Updraft - automatic backups', // The plugin name
 'slug'     => 'updraftplus', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/updraftplus.1.16.21.zip', // The plugin source
 'required' => true, // If false, the plugin is only 'recommended' instead of required
 'version' => '1.16.21', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented 
	'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
),
 
 array(
 'name'     => 'Disable Comments (optional)', // The plugin name
 'slug'     => 'disable-comments', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/disable-comments.zip', // The plugin source
 'required' => false, // If false, the plugin is only 'recommended' instead of required
 'version' => '1.10.2', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
 
  array(
 'name'     => 'Contact Form 7 - Contact Forms (optional)', // The plugin name
 'slug'     => 'contact-form-7', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/contact-form-7.5.1.6.zip', // The plugin source
 'required' => false, // If false, the plugin is only 'recommended' instead of required
 'version' => '5.1.6', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
 
 array(
 'name'     => 'Shariff for WordPress (Optional)', // The plugin name
 'slug'     => 'shariff', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/shariff.4.6.3.zip', // The plugin source
 'required' => false, // If false, the plugin is only 'recommended' instead of required
 'version' => '4.6.3', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
 
 array(
 'name'     => 'Under Construction (Optional)', // The plugin name
 'slug'     => 'under-construction-page', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/under-construction-page.3.65.zip', // The plugin source
 'required' => false, // If false, the plugin is only 'recommended' instead of required
 'version' => '3.65', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
	 
 array(
 'name'     => 'WooCommerce (Optional)', // The plugin name
 'slug'     => 'woocommerce', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/woocommerce.3.8.1.zip', // The plugin source
 'required' => false, // If false, the plugin is only 'recommended' instead of required
 'version' => '3.8.1', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
	 array(
 'name'     => 'WooCommerce Germanized (Optional)', // The plugin name
 'slug'     => 'woocommerce-germanized', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/woocommerce-germanized.3.0.8.zip', // The plugin source
 'required' => false, // If false, the plugin is only 'recommended' instead of required
 'version' => '3.0.8', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
	  array(
 'name'     => 'kk Star Ratings (Optional)', // The plugin name
 'slug'     => 'kk-star-ratings', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/kk-star-ratings.4.1.2.zip', // The plugin source
 'required' => false, // If false, the plugin is only 'recommended' instead of required
 'version' => '4.1.2', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
 
 array(
 'name'     => 'SendinBlue Subscribe Form And WP SMTP (Optional)', // The plugin name
 'slug'     => 'mailin', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/mailin.zip', // The plugin source
 'required' => false, // If false, the plugin is only 'recommended' instead of required
 'version' => '2.9.9', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
 
 array(
 'name'     => 'a3 lazy load - Bessere Ladezeit durch Selektive Bildladung (optional)', // The plugin name
 'slug'     => 'a3-lazy-load', // The plugin slug (typically the folder name)
 'source'   => 'https://downloads.wordpress.org/plugin/a3-lazy-load.2.0.0.zip', // The plugin source
 'required' => false, // If false, the plugin is only 'recommended' instead of required
 'version' => '2.0.0', // E.g. 1.0.0. If set, the active plugin must be this version or higher, otherwise a notice is presented
 'force_activation' => false, // If true, plugin is activated upon theme activation and cannot be deactivated until theme switch
 'force_deactivation' => false, // If true, plugin is deactivated upon theme switch, useful for theme-specific plugins
 'external_url' => '', // If set, overrides default API URL and points to an external URL
'is_callable'        => '', // If set, this callable will be be checked for availability to determine if a plugin is active.
 ),
 );
 
 // Change this to your theme text domain, used for internationalising strings
 $theme_text_domain = 'call-a-nerd-theme';
 
 /**
 * Array of configuration settings. Amend each line as needed.
 * If you want the default strings to be available under your own theme domain,
 * leave the strings uncommented.
 * Some of the strings are added into a sprintf, so see the comments at the
 * end of each line for what each argument will be.
 */
 $config = array(
 'domain'       => $theme_text_domain,         // Text domain - likely want to be the same as your theme.
 'default_path' => '',                         // Default absolute path to pre-packaged plugins
 'parent_slug' => 'themes.php', // Default parent menu slug
 'menu'         => 'install-required-plugins', // Menu slug
 'has_notices'       => true,                       // Show admin notices or not
 'is_automatic'     => false,    // Automatically activate plugins after installation or not
 'message' => '', // Message to output right before the plugins table
 'strings'      => array(
			'page_title'                      => __( 'Install Required Plugins', 'call-a-nerd-theme' ),
			'menu_title'                      => __( 'Install Plugins', 'call-a-nerd-theme' ),
			/* translators: %s: plugin name. */
			'installing'                      => __( 'Installing Plugin: %s', 'call-a-nerd-theme' ),
			/* translators: %s: plugin name. */
			'updating'                        => __( 'Updating Plugin: %s', 'call-a-nerd-theme' ),
			'oops'                            => __( 'Something went wrong with the plugin API.', 'call-a-nerd-theme' ),
			'notice_can_install_required'     => _n_noop(
				/* translators: 1: plugin name(s). */
				'This theme requires the following plugin: %1$s.',
				'This theme requires the following plugins: %1$s.',
				'call-a-nerd-theme'
			),
			'notice_can_install_recommended'  => _n_noop(
				/* translators: 1: plugin name(s). */
				'This theme recommends the following plugin: %1$s.',
				'This theme recommends the following plugins: %1$s.',
				'call-a-nerd-theme'
			),
			'notice_ask_to_update'            => _n_noop(
				/* translators: 1: plugin name(s). */
				'The following plugin needs to be updated to its latest version to ensure maximum compatibility with this theme: %1$s.',
				'The following plugins need to be updated to their latest version to ensure maximum compatibility with this theme: %1$s.',
				'call-a-nerd-theme'
			),
			'notice_ask_to_update_maybe'      => _n_noop(
				/* translators: 1: plugin name(s). */
				'There is an update available for: %1$s.',
				'There are updates available for the following plugins: %1$s.',
				'call-a-nerd-theme'
			),
			'notice_can_activate_required'    => _n_noop(
				/* translators: 1: plugin name(s). */
				'The following required plugin is currently inactive: %1$s.',
				'The following required plugins are currently inactive: %1$s.',
				'call-a-nerd-theme'
			),
			'notice_can_activate_recommended' => _n_noop(
				/* translators: 1: plugin name(s). */
				'The following recommended plugin is currently inactive: %1$s.',
				'The following recommended plugins are currently inactive: %1$s.',
				'call-a-nerd-theme'
			),
			'install_link'                    => _n_noop(
				'Begin installing plugin',
				'Begin installing plugins',
				'call-a-nerd-theme'
			),
			'update_link' 					  => _n_noop(
				'Begin updating plugin',
				'Begin updating plugins',
				'call-a-nerd-theme'
			),
			'activate_link'                   => _n_noop(
				'Begin activating plugin',
				'Begin activating plugins',
				'call-a-nerd-theme'
			),
			'return'                          => __( 'Return to Required Plugins Installer', 'call-a-nerd-theme' ),
			'plugin_activated'                => __( 'Plugin activated successfully.', 'call-a-nerd-theme' ),
			'activated_successfully'          => __( 'The following plugin was activated successfully:', 'call-a-nerd-theme' ),
			/* translators: 1: plugin name. */
			'plugin_already_active'           => __( 'No action taken. Plugin %1$s was already active.', 'call-a-nerd-theme' ),
			/* translators: 1: plugin name. */
			'plugin_needs_higher_version'     => __( 'Plugin not activated. A higher version of %s is needed for this theme. Please update the plugin.', 'call-a-nerd-theme' ),
			/* translators: 1: dashboard link. */
			'complete'                        => __( 'All plugins installed and activated successfully. %1$s', 'call-a-nerd-theme' ),
			'dismiss'                         => __( 'Dismiss this notice', 'call-a-nerd-theme' ),
			'notice_cannot_install_activate'  => __( 'There are one or more required or recommended plugins to install, update or activate.', 'call-a-nerd-theme' ),
			'contact_admin'                   => __( 'Please contact the administrator of this site for help.', 'call-a-nerd-theme' ),

			'nag_type'                        => '', // Determines admin notice type - can only be one of the typical WP notice classes, such as 'updated', 'update-nag', 'notice-warning', 'notice-info' or 'error'. Some of which may not work as expected in older WP versions.
		),
 );
 
 tgmpa( $plugins, $config );
 
}
?>