/**
 * Custom scripts needed for the colorpicker, image button selectors,
 * and navigation tabs.
 */

jQuery(document).ready(function($) {

$('.cuilink').click(function(e){
e.preventDefault();
$(this).parent().find('input').show();

});

		$('#importfile').change(function(){
			var file = document.getElementById("importfile").files[0];
			if (file) {
			    var reader = new FileReader();
			    reader.readAsText(file, "UTF-8");
			    reader.onload = function (evt) {
			        document.getElementById("importtext").innerHTML = evt.target.result;
			    }

			}
		})
	$('#ancclick').click(function(){
		var numItems = $('.cuilist').length;
		numItems=numItems+1;
if ($("body").hasClass("locale-de-de") || $("body").hasClass("locale-de-ch") || $("body").hasClass("locale-de-ch-informal") || $("body").hasClass("locale-de-de-formal"))var msg="'Bist du sicher?'";
		else
		var msg="'Are you sure?'";
		if($('anc').val()!=''){	
				var str='<div class="cuilist"><br>'+numItems+'  <a onclick="return confirm('+msg+')" href="?page=options-callanerd&amp;deletep=1&amp;id=0" class="delete"> delete</a><br><br><input class="of-input"  name="options-framework-theme[list_cui]['+numItems+']" type="text" value="'+$('#anc').val()+'"></div>'
				$('#section-list_cui .option .controls .oldlist').append(str);	
			}
	});	
		$('body').on('click','#tabs .ui-tabs-nav a',function(){
			var hr=$(this).attr('href');
			var s=$('input[name="_wp_http_referer"]').val();
			if(s.indexOf('#')!=-1){
				s = s.substring(0, s.indexOf('#'));
			}
			$('input[name="_wp_http_referer"]').val(s+hr);	
		})
		
		$('#section-themecolor label').each(function(){
			var f=$(this).attr('for');
			fa=f.split('-');
			$(this).css('background','#'+fa[4]);
		})
		$('.cp').change(function(){
			var cp=jQuery(this).val();
			jQuery(this).parent().find('.ci').val(cp);
		})

		$('#addpost').click(function(event){
			event.preventDefault();
			data={};
			data['newpost']=$('#newpost').val();
			data['action']='addpost';

			$.post('admin-ajax.php',data,function(result){
				location.reload();
			})
		});	
		$('#savecolor').click(function(event){
			
			if($('#choosename').val()!='' && $('#choosecolor').val()!=''){
			data={};
						data['choosename']=$('#choosename').val();
			data['choosecolor']=$('#choosecolor').val().replace('#','');


			$('#tabs input[type="text"]').each(function(){
				data[$(this).attr('id')]=$(this).val().replace('#','');

			});



			data['action']='my_scheme';
			$.post('admin-ajax.php',data,function(result){
				location.reload();
			})
			}else{if ($("body").hasClass("locale-de-de") || $("body").hasClass("locale-de-ch") || $("body").hasClass("locale-de-ch-informal") || $("body").hasClass("locale-de-de-formal"))var conmsg="Bitte füllen Sie die Felder Name und Farbe so aus, wie sie benötigt werden!";
		else
			var conmsg="Please fill the name and color fields as they are required!";
		alert(conmsg);return false;}

		})
function getLang()
{
 if (navigator.languages != undefined) 
 return navigator.languages[0]; 
 else 
 return navigator.language;
}
    $( "#tabs" ).tabs();

    $('#section-themecolor .controls label').click(function(){
		if ($("body").hasClass("locale-de-de") || $("body").hasClass("locale-de-ch") || $("body").hasClass("locale-de-ch-informal") || $("body").hasClass("locale-de-de-formal"))var conmsg="Wollen Sie wirklich ein neues Farbprofil wählen und das alte überschreiben?";
		else
			var conmsg="Do you really to pick new and overwrite old color profile?";
		
var resultcon = confirm(conmsg);

if(resultcon){
    	$('div#section-example_colorpicker_tab').prepend('<div class="loader"></div>');
    	var dc=$(this).attr('for');
    	var dcar=dc.split('-');
    	dc=dcar[4];
    	var data={};
    	data['action']= 'get_color';
    	data['color']=dc;
    	$.post('admin-ajax.php',data,function(result){
    		var obj = jQuery.parseJSON(result);
    		 Object.keys(obj).map(function(k) { 
    		 		$('#'+k).val('#'+obj[k]).change();
    		 		$('#'+k).css('background','#'+obj[k]);
    		  });
    		 jQuery('.loader').remove();

    	})
}else{
	var dc=$(this).attr('for');
$('#'+dc).attr('style','display: none;');
}
    })

	// Loads the color pickers
	$('.of-color').wpColorPicker();

	// Image Options
	$('.of-radio-img-img').click(function(){
		$(this).parent().parent().find('.of-radio-img-img').removeClass('of-radio-img-selected');
		$(this).addClass('of-radio-img-selected');
	});

	$('.of-radio-img-label').hide();
	$('.of-radio-img-img').show();
	$('.of-radio-img-radio').hide();

	// Loads tabbed sections if they exist
	if ( $('.nav-tab-wrapper').length > 0 ) {
		options_framework_tabs();
	}

	function options_framework_tabs() {

		var $group = $('.group'),
			$navtabs = $('.nav-tab-wrapper a'),
			active_tab = '';

		// Hides all the .group sections to start
		$group.hide();

		// Find if a selected tab is saved in localStorage
		if ( typeof(localStorage) != 'undefined' ) {
			active_tab = localStorage.getItem('active_tab');
		}

		// If active tab is saved and exists, load it's .group
		if ( active_tab != '' && $(active_tab).length ) {
			$(active_tab).fadeIn();
			$(active_tab + '-tab').addClass('nav-tab-active');
		} else {
			$('.group:first').fadeIn();
			$('.nav-tab-wrapper a:first').addClass('nav-tab-active');
		}

		// Bind tabs clicks
		$navtabs.click(function(e) {

			e.preventDefault();

			// Remove active class from all tabs
			$navtabs.removeClass('nav-tab-active');

			$(this).addClass('nav-tab-active').blur();

			if (typeof(localStorage) != 'undefined' ) {
				localStorage.setItem('active_tab', $(this).attr('href') );
			}

			var selected = $(this).attr('href');

			$group.hide();
			$(selected).fadeIn();

		});
	}

});