/**
 * Custom scripts needed for the colorpicker, image button selectors,
 * and navigation tabs.
 */

jQuery(document).ready(function($) {

$('.cuilink').click(function(e){
e.preventDefault();
$(this).parent().find('input').show();

});

		$('#importfile').change(function(){
			var file = document.getElementById("importfile").files[0];
			if (file) {
			    var reader = new FileReader();
			    reader.readAsText(file, "UTF-8");
			    reader.onload = function (evt) {
			        document.getElementById("importtext").innerHTML = evt.target.result;
			    }

			}
		})

		$('.remove-file').val('Ändern');

		$('body').on('click','#tabs .ui-tabs-nav a',function(){
			var hr=$(this).attr('href');
			var s=$('input[name="_wp_http_referer"]').val();
			if(s.indexOf('#')!=-1){
				s = s.substring(0, s.indexOf('#'));
			}
			$('input[name="_wp_http_referer"]').val(s+hr);	
		})
		
		$('#section-themecolor label').each(function(){
			var f=$(this).attr('for');
			fa=f.split('-');
			$(this).css('background','#'+fa[4]);
		})
		$('.cp').change(function(){
			var cp=jQuery(this).val();
			jQuery(this).parent().find('.ci').val(cp);
		})

		$('#addpost').click(function(event){
			event.preventDefault();
			data={};
			data['newpost']=$('#newpost').val();
			data['action']='addpost';

			$.post('admin-ajax.php',data,function(result){
				location.reload();
			})
		});	
		$('#savecolor').click(function(){
			data={};
						data['choosename']=$('#choosename').val();
			data['choosecolor']=$('#choosecolor').val();


			$('#tabs input[type="text"]').each(function(){
				data[$(this).attr('id')]=$(this).val();

			});



			data['action']='my_scheme';
			$.post('admin-ajax.php',data,function(result){
				location.reload();
			})


		})

    $( "#tabs" ).tabs();

    $('#section-themecolor .controls label').click(function(){

    	$('div#section-example_colorpicker_tab').prepend('<div class="loader"></div>');
    	var dc=$(this).attr('for');
    	var dcar=dc.split('-');
    	dc=dcar[4];
    	var data={};
    	data['action']= 'get_color';
    	data['color']=dc;

    	$.post('admin-ajax.php',data,function(result){
    		var obj = jQuery.parseJSON(result);
    		 Object.keys(obj).map(function(k) { 
    		 		$('#'+k).val(obj[k]).change();
    		 		$('#'+k).css('background','#'+obj[k]);
    		  });
    		 jQuery('.loader').remove();

    	})

    })

	// Loads the color pickers
	$('.of-color').wpColorPicker();

	// Image Options
	$('.of-radio-img-img').click(function(){
		$(this).parent().parent().find('.of-radio-img-img').removeClass('of-radio-img-selected');
		$(this).addClass('of-radio-img-selected');
	});

	$('.of-radio-img-label').hide();
	$('.of-radio-img-img').show();
	$('.of-radio-img-radio').hide();

	// Loads tabbed sections if they exist
	if ( $('.nav-tab-wrapper').length > 0 ) {
		options_framework_tabs();
	}

	function options_framework_tabs() {

		var $group = $('.group'),
			$navtabs = $('.nav-tab-wrapper a'),
			active_tab = '';

		// Hides all the .group sections to start
		$group.hide();

		// Find if a selected tab is saved in localStorage
		if ( typeof(localStorage) != 'undefined' ) {
			active_tab = localStorage.getItem('active_tab');
		}

		// If active tab is saved and exists, load it's .group
		if ( active_tab != '' && $(active_tab).length ) {
			$(active_tab).fadeIn();
			$(active_tab + '-tab').addClass('nav-tab-active');
		} else {
			$('.group:first').fadeIn();
			$('.nav-tab-wrapper a:first').addClass('nav-tab-active');
		}

		// Bind tabs clicks
		$navtabs.click(function(e) {

			e.preventDefault();

			// Remove active class from all tabs
			$navtabs.removeClass('nav-tab-active');

			$(this).addClass('nav-tab-active').blur();

			if (typeof(localStorage) != 'undefined' ) {
				localStorage.setItem('active_tab', $(this).attr('href') );
			}

			var selected = $(this).attr('href');

			$group.hide();
			$(selected).fadeIn();

		});
	}

});