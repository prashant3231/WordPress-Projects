<?php
/* First Install Message*/

$validation = get_option('key_validated')=='1'?'Valid':'Invalid';
$show_ad='';
if($validation=="Valid"){
	$show_ad = get_option('show_ad');
}

$first_install_pro_lost_button = "";
$weekly_install_pro_lost_button = "";
if(get_locale()=='de_DE' || get_locale()=='de_DE_formal' || get_locale()=='de_CH' || get_locale()=='de_CH_informal'){
  $button_name = "Diese Nachricht für immer ausblenden";
}else{
  $button_name = "Hide this message forever";
}
if($validation=="Valid"){
  $first_install_pro_lost_button = '<a href="javascript:void(0);" class=" first_install_forever">'.$button_name.'</a>';
  $weekly_install_pro_lost_button = '<a href="javascript:void(0);" class=" weekly_install_forever">'.$button_name.'</a>';
}
function my_update_notice() {if(get_locale()=='de_DE' || get_locale()=='de_DE_formal' || get_locale()=='de_CH' || get_locale()=='de_CH_informal'){
  global $first_install_pro_lost_button;

    ?><div id="ucp_rate_notice2" class="notice-info notice my-not is-dismissible first_install_msg"><p><img class="callogo" src="<?php echo get_template_directory_uri();?>/images/mini-banner-PSD.png">
<?php echo 'Viel Spaß mit dem Call a Nerd Theme. Über <a href="https://callanerd.help/category/wordpress-theme" target="_blank">diesen Link</a> findest du Tutorials und die Theme Erklärung in Text und Video Form. Das King Composer Plugin sollte immer installiert und aktiviert sein, weil sonst das Theme nicht ordentlich funktioniert. Die Liste der vom Theme empfohlenen Plugins findest du über diesen Link: <a href="'.site_url().'/wp-admin/themes.php?page=install-required-plugins">Hier klicken</a> um die vorgeschlagenen Plugins zu installieren und aktivieren. Über <a href="'.site_url().'/wp-admin/admin.php?page=kingcomposer">diesen Link</a> kannst du den visuellen King Composer Editor auch für Beiträge und Produkte aktivieren. Die Themeoptionen findest du über <a href="'.site_url().'/wp-admin/admin.php?page=options-callenered">diesen Link</a>.</p><p>Falls du nicht weiterkommst, Fragen oder Verbesserungsvorschläge hast klicke auf <a href="https://callanerd.help/forum" target="_blank">diesen Link</a> zu unserem Forum. Dort kannst du uns deine Fragen und Verbesserungswünsche schreiben. Es kann bei Browsern wie Safari oder Internet Explorern zu Fehlern kommen, z.B. dass man sich nicht einloggen kann. Wir empfehlen die neuste Version des Chrome oder Firefox als Browser für die WordPress Bedienung. Das Problem besteht weil diese Browser moderne Webstandards die WordPress benutzt zum Teil nicht mehr unterstützen. Das liegt an den Browser und nicht am Theme, weil es allgemein bei WordPress auftritt.</p><p>Bei Themen wie Suchmaschinenoptimierung kurz SEO, Geschwindigkeit und Design Optimierung deiner Webseite können wir dir gerne weiterhelfen. Die Problemanalyse und Aufwanseinschätzung ist immer gratis. Danach kostet die Soforthilfe immer nur 16,50 € je 10 Minuten + MwSt. Wir können dich auch über Bildschirmübertragung und Telefon schulen bzw. deine Webseite zusammen verbessern. Die eigenständige Umsetzung von Projekten gibt es zu einem Stundensatz von 79 € + MwSt. Call a Nerd die persönliche WordPress und WooCommerce Agentur aus Köln und ist auch spezialisiert auf die Entwicklung von eigenen Erweiterungen und die Konfiguration und Weiterentwicklung von bestehenden Plugins.</p><p>Kontaktdaten:<br> • Webseite: <a href="https://callanerd.help" target="_blank">callanerd.help</a><br> • Telefon: <a href="tel:022048649860">02204 8649 860</a><br> • WhatsApp: <a href="https://api.whatsapp.com/send?phone=01785584066">0178 5584066</a><br> • E-Mail: <a href="emailto:info@callanerd.help">info@callanerd.help</a><br> • Skype: <a href="callto:flextexmex">flextexmex</a></p>'; echo "<br/><div>".$first_install_pro_lost_button.'</div>'; ?></div><?php }else{ ?><div id="ucp_rate_notice2" class="notice-info notice is-dismissible"><p><img class="callogo" src="<?php echo get_template_directory_uri();?>/images/mini-banner-PSD.png">
	<?php 
	echo 'Have fun with the Call a Nerd theme. Following <a href="https://callanerd.help/category/wordpress-theme" target="_blank">this link</a> you will find tutorials and the theme explanation in text and video form. The King Composer plugin should always be installed and activated, otherwise the theme will not work properly. You can find the list of plugins recommended by the theme: <a href="'.site_url().'/wp-admin/themes.php?page=install-required-plugins">Click here</a> to install and activate the suggested plugins. Through <a href="'.site_url().'/wp-admin/admin.php?page=kingcomposer">this link</a> you can also activate the visual King Composer Editor for posts and products. The theme options can be found via <a href="'.site_url().'/wp-admin/admin.php?page=options-callenered">this link</a>.</p><p>If you get stuck, have questions or suggestions for improvement click on <a href="https://callanerd.help/forum" target="_blank">this link</a> to our forum. There you can write us your questions and suggestions for improvement. In browsers such as Safari or Internet Explorer errors can happen, e.g. that you can not log in. We recommend Chrome or Firefox as a browser for the operation of WordPress. This problem happens because these browsers no longer support modern web standards that WordPress uses. That\'s because of the browser and not because of the theme, it is happening in all WordPress pages.</p><p>For topics like search engine optimization short SEO, speed and design optimization of your website, we can help you. The problem analysis is always free. Afterwards the emergency aid only costs € 16.50 per 10 minutes + VAT. We can also give you a workshop via screen transfer and telephone or improve your website directly together. The independent development of projects is available at an hourly rate of 79 € + VAT. Call a Nerd the personal WordPress and WooCommerce agency from Cologne and is also specialized in the development of own extensions and the configuration and customization of existing plugins.</p>
<p>Contact details:<br> • Website: <a href="https://callanerd.help" target="_blank">callanerd.help</a><br> • Telephone: <a href="tel:022048649860">02204 8649 860</a><br> • WhatsApp: <a href="https://api.whatsapp.com/send?phone=01785584066">0178 5584066</a><br> • E-Mail: <a href="emailto:info@callanerd.help">info@callanerd.help</a><br> • Skype: <a href="callto:flextexmex">flextexmex</a></p>';
	 echo "<br/><div>".$first_install_pro_lost_button.'</div>';?></div><?php

  
   } }
if(!wp_get_theme('call-a-nerd-theme'))update_option('notice_flag_first',0);
$theme_installed_date = get_option("theme_installed_date");
$today = date('Y-m-d');
$interval =  strtotime($today)-strtotime($theme_installed_date);
$days = floor($interval / 86400); // 1 day
//echo update_option('notice_flag_first',1);die;
if(get_option('notice_flag_first')!=0){
  if($days > 7) {
      /*hide amdin notices*/
      update_option('notice_flag_first',0);
  }else{
    /*show amdin notices*/
	  if($show_ad!='1')add_action( 'admin_notices', 'my_update_notice' );
  }
} 
function general_admin_notice(){

    global $weekly_install_pro_lost_button;
   
    if(get_locale()=='de_DE' || get_locale()=='de_DE_formal' || get_locale()=='de_CH' || get_locale()=='de_CH_informal'){
         echo '<div id="weekly_meesage" class="notice-info weekly_install_msg notice is-dismissible">
             <p><img class="callogo" src="'.get_template_directory_uri().'/images/mini-banner-PSD.png">Viel Spaß mit dem Call a Nerd Theme. Über <a href="https://callanerd.help/category/wordpress-theme" target="_blank">diesen Link</a> findest du Tutorials und die Theme Erklärung in Text und Video Form. Das King Composer Plugin sollte immer installiert und aktiviert sein, weil sonst das Theme nicht ordentlich funktioniert. Die Liste der vom Theme empfohlenen Plugins findest du über diesen Link: <a href="'.site_url().'/wp-admin/themes.php?page=install-required-plugins">Hier klicken</a> um die vorgeschlagenen Plugins zu installieren und aktivieren. Über <a href="'.site_url().'/wp-admin/admin.php?page=kingcomposer">diesen Link</a> kannst du den visuellen King Composer Editor auch für Beiträge und Produkte aktivieren. Die Themeoptionen findest du über <a href="'.site_url().'/wp-admin/admin.php?page=options-callenered">diesen Link</a>.</p><p>Falls du nicht weiterkommst, Fragen oder Verbesserungsvorschläge hast klicke auf <a href="https://callanerd.help/forum" target="_blank">diesen Link</a> zu unserem Forum. Dort kannst du uns deine Fragen und Verbesserungswünsche schreiben. Es kann bei Browsern wie Safari oder Internet Explorern zu Fehlern kommen, z.B. dass man sich nicht einloggen kann. Wir empfehlen die neuste Version des Chrome oder Firefox als Browser für die WordPress Bedienung. Das Problem besteht weil diese Browser moderne Webstandards die WordPress benutzt zum Teil nicht mehr unterstützen. Das liegt an den Browser und nicht am Theme, weil es allgemein bei WordPress auftritt.</p><p>Bei Themen wie Suchmaschinenoptimierung kurz SEO, Geschwindigkeit und Design Optimierung deiner Webseite können wir dir gerne weiterhelfen. Die Problemanalyse und Aufwanseinschätzung ist immer gratis. Danach kostet die Soforthilfe immer nur 16,50 € je 10 Minuten + MwSt. Wir können dich auch über Bildschirmübertragung und Telefon schulen bzw. deine Webseite zusammen verbessern. Die eigenständige Umsetzung von Projekten gibt es zu einem Stundensatz von 79 € + MwSt. Call a Nerd die persönliche WordPress und WooCommerce Agentur aus Köln und ist auch spezialisiert auf die Entwicklung von eigenen Erweiterungen und die Konfiguration und Weiterentwicklung von bestehenden Plugins.</p><p>Kontaktdaten:<br> • Webseite: <a href="https://callanerd.help" target="_blank">callanerd.help</a><br> • Telefon: <a href="tel:022048649860">02204 8649 860</a><br> • WhatsApp: <a href="https://api.whatsapp.com/send?phone=01785584066">0178 5584066</a><br> • E-Mail: <a href="emailto:info@callanerd.help">info@callanerd.help</a><br> • Skype: <a href="callto:flextexmex">flextexmex</a></p>
              
        <div class="" style="margin-bottom:5px;">'.$weekly_install_pro_lost_button.'</div> </div>'; }else{
		echo '<div id="weekly_meesage" class="notice-info notice is-dismissible">
             <p><img class="callogo" src="'.get_template_directory_uri().'/images/mini-banner-PSD.png">Have fun with the Call a Nerd theme. Following <a href="https://callanerd.help/category/wordpress-theme" target="_blank">this link</a> you will find tutorials and the theme explanation in text and video form. The King Composer plugin should always be installed and activated, otherwise the theme will not work properly. You can find the list of plugins recommended by the theme: <a href="'.site_url().'/wp-admin/themes.php?page=install-required-plugins">Click here</a> to install and activate the suggested plugins. Through <a href="'.site_url().'/wp-admin/admin.php?page=kingcomposer">this link</a> you can also activate the visual King Composer Editor for posts and products. The theme options can be found via <a href="'.site_url().'/wp-admin/admin.php?page=options-callenered">this link</a>.</p><p>If you get stuck, have questions or suggestions for improvement click on <a href="https://callanerd.help/forum" target="_blank">this link</a> to our forum. There you can write us your questions and suggestions for improvement. In browsers such as Safari or Internet Explorer errors can happen, e.g. that you can not log in. We recommend Chrome or Firefox as a browser for the operation of WordPress. This problem happens because these browsers no longer support modern web standards that WordPress uses. That\'s because of the browser and not because of the theme, it is happening in all WordPress pages.</p><p>For topics like search engine optimization short SEO, speed and design optimization of your website, we can help you. The problem analysis is always free. Afterwards the emergency aid only costs € 16.50 per 10 minutes + VAT. We can also give you a workshop via screen transfer and telephone or improve your website directly together. The independent development of projects is available at an hourly rate of 79 € + VAT. Call a Nerd the personal WordPress and WooCommerce agency from Cologne and is also specialized in the development of own extensions and the configuration and customization of existing plugins.</p>
<p>Contact details:<br> • Website: <a href="https://callanerd.help" target="_blank">callanerd.help</a><br> • Telephone: <a href="tel:022048649860">02204 8649 860</a><br> • WhatsApp: <a href="https://api.whatsapp.com/send?phone=01785584066">0178 5584066</a><br> • E-Mail: <a href="emailto:info@callanerd.help">info@callanerd.help</a><br> • Skype: <a href="callto:flextexmex">flextexmex</a></p>



  <br/><div class="" style="margin-bottom:5px;">'.$weekly_install_pro_lost_button.'</div>

         </div>';
		
	}
    
}
$theme_installed_date = get_option("theme_installed_date");
$today = date('Y-m-d');
$interval =  strtotime($today)-strtotime($theme_installed_date);
$days = floor($interval / 86400);
$check_forver_closed = 1;
$check_forver_closed = get_option("weeklyinstall_forever");
//add_action('admin_notices', 'general_admin_notice');
if(get_option("weeklyinstall_forever")!==FALSE){
  //echo "exits";die;
}else{
  //echo "does not";die;
  if(get_option("current_weekly_stop_date")!=date('Y-m-d')){
    if(get_option("weekly_viewing_date")==date('Y-m-d')){
      if($show_ad!='1')add_action('admin_notices', 'general_admin_notice');
    }else if($days % 7==0){
      if($show_ad!='1')add_action('admin_notices', 'general_admin_notice');
    }
  }
}
//die; 

/*Free Theme*/
function general_admin_notice_pro(){
   
    if(get_locale()=='de_DE' || get_locale()=='de_DE_formal' || get_locale()=='de_CH' || get_locale()=='de_CH_informal'){
         echo '<div id="weekly_meesage_for_free" class="notice-info notice is-dismissible content_for_free"><p><img class="callogo" src="'.get_template_directory_uri().'/images/logo-c.jpg">Sie nutzen aktuell das kostenlose Call a Nerd Basis Theme. Sie können das Theme auch bequem zum Premium Theme updaten und erhalten diese Premium Features:</p><p>• Revolution Slider inklusive (normal ab 25$)<br>Der animierte Text oben auf <a href="https://callanerd.help/wordpress-theme/" target="_blank">https://callanerd.help/wordpress-theme/</a> oder die Animation auf der Call a Nerd Startseite wurden auch mit dem Revolution Slider erstellt. Keine Angst du musst nicht alles selbst erstellen sondern kannst auch vielen hochwertigen Vorlagen wählen. Danach musst du nur noch den Text oder die Bilder einfach tauschen.</p><p>• Live Frontend Editor (normal 39$)<br>Viele Theme Besitzer die den Editor benutzt haben beschreiben es als eine völlig neue und einzigartige Art und Weise eine Webseite zu erstellen. Einmal benutzt will man es nicht mehr missen. Jetzt Video das Frontend Live Editor Video anschauen: <a href="https://callanerd.help/wordpress-theme/" target="_blank">https://callanerd.help/wordpress-theme/</a></p><p>• Kein Theme Frontend Link</p><p>• Premium Theme Support und Hilfe</p><p>Das Premium Theme kostet 59 € für 6 Monate, danach 29 € für 6 Monate. Keine Sorge danach ist die normale Webseite natürlich immer noch erreichbar, aber Updates des Premium Theme sind nur mit für Lizenzkunden erhältlich. Mehr Informationen über das Premium Theme auf: <a href="https://callanerd.help/wordpress-theme/" target="_blank">https://callanerd.help/wordpress-theme/</a></p></div>';}else{
		echo '<div id="weekly_meesage_for_free" class="notice-info notice is-dismissible content_for_free"><p><img class="callogo" src="'.get_template_directory_uri().'/images/logo-c.jpg">You are currently using the free Call a Nerd Basis Theme. You can also update the theme to the premium theme version and get these premium features:</p><p>• Revolution Slider included (normal from $ 25)<br>The animated text on the slider <a href="https://callanerd.help/wordpress-theme/" target="_blank">https://callanerd.help/wordpress-theme/</a> or the animation on the Call a Nerd homepage were also created with the Revolution Slider. Do not worry, you do not have to create everything yourself but you can choose one of the many high quality templates. Then you just can easily swap the text or the pictures and you are done.</p><p>• Live Frontend Editor (normal $ 39)<br>Many premium theme owners who have used the live editor describe it as a completely new and unique way to create a website. Once used, you do not want to miss it anymore. Watch the frontend live editor video now: <a href="https://callanerd.help/wordpress-theme/" target="_blank">https://callanerd.help/wordpress-theme/</a></p><p>• No theme frontend link</p><p>• Premium theme support and help</p><p>The premium theme costs 59 € for 6 months, after that then 29 € for 6 month. Don\'t worry, the website will be still available after, but updates of the premium theme are only available for licensed customers. You find more information about the premium theme at: <a href="https://callanerd.help/wordpress-theme/" target="_blank">https://callanerd.help/wordpress-theme/</a></p>
</div>';
		
	} 
}
if($validation=="Invalid"){
  $theme_installed_date = get_option("theme_installed_date");
  //$theme_installed_date = "2018-02-24";
  $today = date('Y-m-d');
  $interval =  strtotime($today)-strtotime($theme_installed_date);
  $days = floor($interval / 86400);
  if(get_option("current_weekly_stop_non_premium_date")!=date('Y-m-d')){
    if(get_option("weekly_viewing_non_premium_date")==date('Y-m-d')){
      add_action('admin_notices', 'general_admin_notice_pro');
    }else if($days % 7==0){
      add_action('admin_notices', 'general_admin_notice_pro');
    }
  }
  //add_action('admin_notices', 'general_admin_notice_pro'); 
}
