<?php   // Our custom post type function

add_action('init', 'cuifunction');
function cuifunction(){
 $options=get_option('options-framework-theme'); 
	if(isset($options['list_cui']))
        $list_cui=$options['list_cui'];


if(isset($_GET['deletep']) && $_GET['deletep']==1 && $_GET['id']!='' ){
  if (($key = array_search($_GET['id'], $list_cui)) !== false) {
    unset($list_cui[$key]);
    }
    $options['list_cui']=$list_cui;
    update_option('options-framework-theme',$options);wp_redirect(admin_url()."admin.php?page=options-callanerd");
}

 $options=get_option('options-framework-theme'); 
	if(isset($options['list_cui']))
        $list_cui=$options['list_cui'];


// Hooking up our function to theme setup
//add_action( 'init', 'create_posttype' );
if(isset($list_cui) && !empty($list_cui)){
foreach ($list_cui as $key => $value) {
    
    $slug=substr(sanitize_title($value),0, 19);
if($value){
    register_post_type($slug,
    // CPT Options
        array(
            'labels' => array(
                'name' => $value,
                'singular_name' => $value
            ),
 'public' => true,
    'publicly_queryable' => true,
    'has_archive' => true,
    'show_ui' => true,
    'query_var' => true,
    'rewrite' => true,
    'capability_type' => 'post',
    'hierarchical' => false,
    'menu_position' => 10,
			
	'supports' => array('thumbnail','editor','title','excerpt')		

        )
    );
	 register_taxonomy(  
        $slug.'_cat',  //The name of the taxonomy. Name should be in slug form (must not contain capital letters or spaces). 
        $slug,        //post type name
        array(  
            'hierarchical' => true,  
            'label' => $value.' Category',  //Display name
			'show_ui'           => true,
        'show_admin_column' => true,
            'query_var' => true,
            'rewrite' => array(
                'slug' => $slug.'_cat', // This controls the base slug that will display before each term
                'with_front' => true // Don't display the category base before 
            )
        )  
    );  
}
 }
}
}



 ?>