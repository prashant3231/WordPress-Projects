<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package CaN
 */

get_header(); ?>

<?php   

if(of_get_option('page_title_position')=='image_center'){
$w=12;
}
else if(of_get_option('page_title_position')!='image_center'){
$w=12;
}
// Get body classes as array
$body_classes = get_body_class();
 ?>
<div id="blog-template-type-3" class="blog-type-3 with-header-img">
    
    <div class="sub-header sub-header-bg" style="background-image:url(<?php echo of_get_option('blog_banner_image')  ?>)">
        <div class="page-title">
            <h1><?php echo "Blog"; ?></h1>
        </div>
    </div>
                
                
	<div class="container blog-post">
    	<div class="row">             
    
<?php             if(of_get_option('blog_layout')=='without-sidebar'){  $class='col-md-12'; }  
            else if(of_get_option('blog_layout')=='with-sidebar') {  $class='col-md-9'; }
            else if(of_get_option('blog_layout')=='with-sidebar-left'){ $class='col-md-9 pull-right'; }     ?>

            <div class="content-left <?php echo $class ?> bp-listing">
                    <?php while(have_posts()){ the_post(); ?> 
            <?php $thum=((has_post_thumbnail() && of_get_option('page_title_position')=='image_center')?'has-post-thumbnail':'no-thumbnail'); ?>
            <article class="post type-post status-publish format-standard <?php echo $thum ?> hentry category-allgemein">
                <div>
                	<header class="entry-header">
                        
                         <figure>        
                               <?php if(isset($term_layout))
									$sidebar=$term_layout;
									else
									$sidebar='';
		  if($sidebar=='')of_get_option('blog_layout'); if($sidebar=='with-sidebar'){ ?>
                           
                           <?php if(has_post_thumbnail()){ ?>
                            <a href="<?php the_permalink() ?>"><?php the_post_thumbnail(array(385,214)) ?>  </a>
                           <?php } else { ?>
                            <a href="<?php the_permalink() ?>"><img src="<?php 
                            echo esc_url( get_template_directory_uri('template_directory') )

                             ?>/images/no-image.jpg">  </a>
                            <?php } ?>
                            <?php  } else { ?>
                             <?php if(has_post_thumbnail()){ ?>
                            <a href="<?php the_permalink() ?>"><?php the_post_thumbnail(array(515,286)) ?>  </a>
                           <?php } else { ?>
                            <a href="<?php the_permalink() ?>"><img src="<?php echo esc_url( get_template_directory_uri('template_directory') ) ?>/images/no-image.jpg">  </a>
                            <?php } ?>

                            <?php   } ?>
                        </figure>
                       
                    </header><!-- .entry-header -->
                    <div class="entry-content clearfix">
                        <h2 class="post-title"><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h2>
                        <div class="post-desc col-sm-<?php    echo $w  ?> " <?php if(in_array("blog", $body_classes) && of_get_option('blog_hide_e')=="Hide")echo "style='display: none;'"; ?> <?php if((is_category() || is_tag()) && of_get_option('blogcategorytag_hide_e')=="Hide")echo "style='display: none;'"; ?>>
                           
                            <?php if(of_get_option('showmetdata')==1){ ?>
                                <ul class="post-meta">
                                  
                                    <li><i class="fa fa-user" aria-hidden="true"></i><?php echo get_the_author_link(); ?></li>
                                    <li><i class="fa fa-comments" aria-hidden="true"></i><a href="<?php the_permalink() ?>"><?php comments_number() ?></a></li>
                                    <li><i class="fa fa-folder" aria-hidden="true"></i><?php if(get_post_type()=='post'){the_category(',');}else{$terms = get_the_terms( $post->ID , get_post_type().'_cat' ); 
                    foreach ( $terms as $term ) {
                        $term_link = get_term_link( $term, get_post_type().'_cat' );
                        if( is_wp_error( $term_link ) )
                        continue;
                    echo '<a href="' . $term_link . '">' . $term->name . '</a>';
                    } } ?></li>
                            
                                </ul>
                                <?php } ?>
                             <p><?php echo content(50); ?></p>
                          
                        </div>
                       
                        <div class="author-info pull-left" >
                           <strong> <p <?php if(in_array("blog", $body_classes) && of_get_option('blog_hide_ap')=="Hide")echo "style='display: none;'"; ?> <?php if((is_category() || is_tag()) && of_get_option('blogcategorytag_hide_ap')=="Hide")echo "style='display: none;'"; ?>><?php echo __('Author','call-a-nerd-theme');?>: <?php echo get_the_author_link(); ?> | <?php echo __('Published');?>: <?php  the_time('d.m.Y') ?></p>
                            <p <?php if(in_array("blog", $body_classes) && of_get_option('blog_hide_c')=="Hide")echo "style='display: none;'"; ?> <?php if((is_category() || is_tag()) && of_get_option('blogcategorytag_hide_c')=="Hide")echo "style='display: none;'"; ?>><?php echo __('Categories','call-a-nerd-theme');?>: <?php if(get_post_type()=='post'){the_category(',');}else{$terms = get_the_terms( $post->ID , get_post_type().'_cat' ); 
                    foreach ( $terms as $term ) {
                        $term_link = get_term_link( $term, get_post_type().'_cat' );
                        if( is_wp_error( $term_link ) )
                        continue;
                    echo '<a href="' . $term_link . '">' . $term->name . '</a>';
                    } } ?></strong>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </article>
           <?php } ?>
           
            <div class="nav-previous alignleft"><?php next_posts_link( 'Older posts' ); ?></div>
            <div class="nav-next alignright"><?php previous_posts_link( 'Newer posts' ); ?></div>
		
        </div>
<?php if(of_get_option('blog_layout')=='with-sidebar' || of_get_option('blog_layout')=='with-sidebar-left'){ ?>
        <div class="content-right col-md-3 sidebar  <?php echo ((of_get_option('blog_layout')=='with-sidebar-left')?'pull-left':'') ?>"> 
        	<?php get_sidebar(); ?>
        </div>
        <?php   } ?>
        </div>
	</div><!-- container -->
</div>
<?php
get_footer();
