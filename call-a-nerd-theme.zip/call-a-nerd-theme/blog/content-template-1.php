<?php 
$queried_object = get_queried_object();
// Get body classes as array
$body_classes = get_body_class();

 if($queried_object->term_id!=''){
    $queried_object = get_queried_object();
    $metadata=get_option('taxonomy_term_'.$queried_object->term_id); 
    
    if($metadata['template']==''){  
        $metadata['template']='template-3';
    }

    $catpage_title_position=$metadata['catpage_title_position'];
    if($catpage_title_position==''){
        $catpage_title_position=of_get_option('blog_cat_title_position');
    }
    $blogpage_title_position=(($catpage_title_position!='')?$catpage_title_position:'image_center');
 }
 else{
    $blogpage_title_position=((of_get_option('blogpage_title_position')!='')?of_get_option('blogpage_title_position'):'image_center');  
 }


$thum=((has_post_thumbnail() && $blogpage_title_position=='image_center')?'has-post-thumbnail':'no-thumbnail'); ?>
            
<article class="post type-post status-publish format-standard <?php echo $thum ?> hentry category-allgemein">
                <div>
                    <header class="entry-header">
                        
                        <figure>        
                               <?php if(isset($term_layout))
									$sidebar=$term_layout;
									else
									$sidebar='';
		  if($sidebar=='')of_get_option('blog_layout'); if($sidebar=='with-sidebar'){ ?>
                           
                           <?php if(has_post_thumbnail()){ ?>
                            <a href="<?php the_permalink() ?>"><?php the_post_thumbnail(array(415,230)) ?>  </a>
                           <?php } else { ?>
                            <a href="<?php the_permalink() ?>"><img src="<?php echo esc_url( get_template_directory_uri('template_directory') )?>/images/no-image.jpg">  </a>
                            <?php } ?>
                            <?php  } else { ?>
                             <?php if(has_post_thumbnail()){ ?>
                            <a href="<?php the_permalink() ?>"><?php the_post_thumbnail(array(560,310)) ?>  </a>
                           <?php } else { ?>
                            <a href="<?php the_permalink() ?>"><img src="<?php echo esc_url( get_template_directory_uri('template_directory') ) ?>/images/no-image.jpg">  </a>
                            <?php } ?>

                            <?php   } ?>
                        </figure>
                        
                         <?php if($blogpage_title_position=='image_center' && $thum=='has-post-thumbnail'){ ?>
                        <h2><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h2>
                        <?php } ?>

                    </header><!-- .entry-header -->
                    <div class="entry-content clearfix">
                         <?php if($blogpage_title_position!='image_center' || $thum=='no-post-thumbnail'){ ?>
                        <h2 class="post-title"><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h2>
                        <?php } ?>                       

                         <div class="post-desc col-sm-<?php    echo $w  ?> " <?php if(in_array("blog", $body_classes) && of_get_option('blog_hide_e')=="Hide")echo "style='display: none;'"; ?> <?php if((is_category() || is_tag()) && of_get_option('blogcategorytag_hide_e')=="Hide")echo "style='display: none;'"; ?>>
                        
                            <?php if(of_get_option('showmetdata')==1){ ?>
                                <ul class="post-meta">
                                  
                                    <li><i class="fa fa-user" aria-hidden="true"></i><?php echo get_the_author_link(); ?></li>
                                    <li><i class="fa fa-comments" aria-hidden="true"></i><a href="<?php the_permalink() ?>"><?php comments_number() ?></a></li>
                                    <li><i class="fa fa-folder" aria-hidden="true"></i><?php if(get_post_type()=='post'){the_category(',');}else{$terms = get_the_terms( $post->ID , get_post_type().'_cat' ); 
                    foreach ( $terms as $term ) {
                        $term_link = get_term_link( $term, get_post_type().'_cat' );
                        if( is_wp_error( $term_link ) )
                        continue;
                    echo '<a href="' . $term_link . '">' . $term->name . '</a>';
                    } } ?></li>
                            
                                </ul>
                                <?php } ?>
                             <p><?php echo content(50); ?></p>
                          
                        </div>
						
                        <div class="author-info text-center pull-left" >
                            <strong><p <?php if(in_array("blog", $body_classes) && of_get_option('blog_hide_ap')=="Hide")echo "style='display: none;'"; ?> <?php if((is_category() || is_tag()) && of_get_option('blogcategorytag_hide_ap')=="Hide")echo "style='display: none;'"; ?>><?php echo __('Author','call-a-nerd-theme');?>: <?php echo get_the_author_link(); ?> | <?php echo __('Published');?>: <?php  the_time('d.m.Y') ?></p>
                            <p <?php if(in_array("blog", $body_classes) && of_get_option('blog_hide_c')=="Hide")echo "style='display: none;'"; ?> <?php if((is_category() || is_tag()) && of_get_option('blogcategorytag_hide_c')=="Hide")echo "style='display: none;'"; ?>><?php echo __('Categories','call-a-nerd-theme');?>: <?php if(get_post_type()=='post'){the_category(',');}else{$terms = get_the_terms( $post->ID , get_post_type().'_cat' ); 
                    foreach ( $terms as $term ) {
                        $term_link = get_term_link( $term, get_post_type().'_cat' );
                        if( is_wp_error( $term_link ) )
                        continue;
                    echo '<a href="' . $term_link . '">' . $term->name . '</a>';
                    } } ?></p></strong>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </article>