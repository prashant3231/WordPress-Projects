<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CaN
 */

?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel='icon' href='<?php echo site_url().of_get_option('favicon_uploader') ?>'>


<?php wp_head(); ?>

<script type="text/javascript">
	jQuery(window).scroll(function(){
	  var sticky = jQuery('#header');
		  <?php if(of_get_option('global_header_behaviour')!='nonsticky'){?>
		  scroll = jQuery(window).scrollTop();<?php }?>
	
	  if (scroll >= 66) sticky.addClass('sticky_menu');
	  else sticky.removeClass('sticky_menu');
	});
</script>



<link href="<?php echo get_template_directory_uri(); ?>/css/font-awesome.min.css" rel="stylesheet">



<?php include get_template_directory()."/custom-css.php"  ?>
<style><?php echo of_get_option('custom_css') ?></style>

<script><?php echo of_get_option('custom_script') ?></script>
<?php runEval(of_get_option('custom_php_code')) ?>

<?php echo of_get_option('google_tracking_code'); ?>
<?php     $options=get_option('options-framework-theme'); 
  $example_colorpicker_tab=$options['example_colorpicker_tab'];

   ?>
   <link href="https://fonts.googleapis.com/css?family=<?php echo $example_colorpicker_tab['fontfamily_content'] ?>" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=<?php echo $example_colorpicker_tab['fontfamily_heading'] ?>" rel="stylesheet">

  <style type="">
    body *{
               font-family: <?php echo str_replace('+', ' ', $example_colorpicker_tab['fontfamily_content']) ?>;

    }
    body h1, body h2, body h3, body h4, body h5, body h6, .content-title{
               font-family: <?php echo str_replace('+', ' ', $example_colorpicker_tab['fontfamily_heading']) ?>;
   
    }
  </style>
</head>

<body <?php body_class(); ?>>
<div id="wrapper">
	<?php $display_preheader=of_get_option('display_preheader');if($display_preheader=='yes'){?>
<div class="top-strip" >
	<div class="container clearfix">
		<div class="row"><div class="col-sm-6"><?php wp_nav_menu( array(
                                'theme_location' => 'top-menu-1',
                                'menu_id'        => 'top-primary-menu',
                            ) );  ?></div><div class="col-sm-6" style="text-align:right;"><?php wp_nav_menu( array(
                                'theme_location' => 'top-menu-2',
                                'menu_id'        => 'top-secondary-menu',
                            ) );  ?></div>
		</div></div></div>
	<?php }?>
<?php if(get_post_meta($post->ID,'headertype',true)=='transparent' || get_post_meta($post->ID,'headertype',true)=='tao' )
{ ?>	<header id="header" class="header-overlay tao"><?php }elseif(get_post_meta($post->ID,'headertype',true)=='' && of_get_option('header_select')=='tao'){ ?>	<header id="header" class="header-overlay tao"><?php }else{ ?>    <header id="header"> <?php } ?>

    	<div class="container clearfix">
    		<div class="row">
    			<div class="col-sm-12">
    			
    		<?php if($options['global_logo_position']=='center'){  ?><style>#header .container{padding-left: 0px;padding-right: 0px;}.primary{float:left !important;}
			.secondary{float:right !important;}#header .logo{    width: 20% !important;
				display: inline-block !important;float: none !important;padding:1.5px 0px;}#header .navigation{width:40% !important;}@media (max-width: 767px){#header .navigation{width:100% !important;}#navbar-primary-secondary {display: none;}.nav-mobile-centered{max-height: 300px;top: 10px;position: relative;margin-bottom: 20px !important;float: none !important;margin: 0px !important;width: 100% !important;text-align: left !important;overflow-y: auto;padding-right: 15px;padding-left: 15px;overflow-x: visible;-webkit-overflow-scrolling: touch;-webkit-box-shadow: inset 0 1px 0 rgba(255,255,255,.1);box-shadow: inset 0 1px 0 rgba(255,255,255,.1);}}@media (min-width: 768px){#navbar-primary-secondary {display: inline;}}</style>
			
                <div class="logo">
                    <a href="<?php echo home_url() ?>"><img src="<?php echo site_url().of_get_option('logo_uploader') ?>" alt=""></a>
                            </div><!-- .site-branding -->
        
                <button type="button" class="navbar-toggle collapsed" id="centered-menu-collapse">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
                <span role="navigation" id="navbar-primary-secondary" class="nav-mobile-centered">
    
                <nav class="navigation text-right navbar-collapse primary" role="navigation" id="navbar-primary" >
                     <?php
                         $menu = get_term_by('name', 'Can Main Menu', 'nav_menu');   
                     
                        wp_nav_menu( array(
                                'theme_location' => 'menu-1',
                                'menu_id'        => 'primary-menu',
                            ) );  
                         ?>
                </nav><!-- #site-navigation -->
					
                    
                <nav class="navigation text-right navbar-collapse secondary" role="navigation" id="navbar-secondary">
                     <?php
						
		if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {          
                    the_widget( 'WooCommerce_Widget_DropdownCart', array('popup_align' => 'right'), array() );
																							 }
        
    
   
                         $menu = get_term_by('name', 'Can Main Menu', 'nav_menu');   
                     
                        wp_nav_menu( array(
                                'theme_location' => 'menu-2',
                                'menu_id'        => 'secondary-menu',
                            ) );  
																							
                    ?>
                </nav> </span><script>jQuery('#centered-menu-collapse').click(function(){jQuery('#navbar-primary-secondary').slideToggle('slow','linear');});</script><!-- #site-navigation -->
				<?php	}elseif($options['global_logo_position']=='left'){?><style>#header .container{padding-left: 0px;padding-right: 0px;}
#header .logo{
	float:left;
	}
#header .navigation{
	width:auto;
	float:right;
}#header nav > div{
	display: inline-flex;
	}
</style>
					<div class="logo">
                    <a href="<?php echo home_url() ?>"><img src="<?php echo site_url().of_get_option('logo_uploader') ?>" alt=""></a>
                   
                </div><!-- .site-branding -->
        
               
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
                <nav class="navigation text-right navbar-collapse collapse" role="navigation" id="navbar">
                     <?php
                         $menu = get_term_by('name', 'Can Main Menu', 'nav_menu');   
                     
                        wp_nav_menu( array(
                                'theme_location' => 'menu-1',
                                'menu_id'        => 'primary-menu',
                            ) );  
																		  if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {          
                         the_widget( 'WooCommerce_Widget_DropdownCart', array('popup_align' => 'right'), array() );
																		  }
																			  
                    ?>
                </nav><!-- #site-navigation -->
					<?php }elseif($options['global_logo_position']=='right'){?><style>#header .container{padding-left: 0px;padding-right: 0px;}
#header .logo{
	float:right;
	}
#header .navigation{
	width:auto;
	float:left;
	}#header nav > div{
	display: inline-flex;
	}
</style>
					<div class="logo">
                    <a href="<?php echo home_url() ?>"><img src="<?php echo site_url().of_get_option('logo_uploader') ?>" alt=""></a>
                   
                </div><!-- .site-branding -->
        
               
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
                <nav class="navigation text-right navbar-collapse collapse" role="navigation" id="navbar">
                     <?php
                         $menu = get_term_by('name', 'Can Main Menu', 'nav_menu');   
                     
                        wp_nav_menu( array(
                                'theme_location' => 'menu-1',
                                'menu_id'        => 'primary-menu',
                            ) );  
																			 if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {          
                         the_widget( 'WooCommerce_Widget_DropdownCart', array('popup_align' => 'right'), array() );
																			 }
                    ?>
                </nav><!-- #site-navigation -->
					<?php }?><div class="mobile-cart-icon">
				<?php if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {          
                         the_widget( 'WooCommerce_Widget_DropdownCart', array('popup_align' => 'right'), array() );
																							 } ?>
				</div>
					
        </div>
    </div>
    </div>
	</header><!-- #masthead -->
 <style>
@media screen and (min-width: 768px){
nav.navigation.text-right.navbar-collapse.primary{    padding-left: 0px;
    text-align: left !important;}
	nav.navigation.text-right.navbar-collapse.secondary{    padding-right: 0px;
    text-align: right !important;}
	nav.navigation.text-right.navbar-collapse.secondary div.menu-secondary-menu-container{float: right;}
}

#header .logo{
	max-width: 280px;
}
.dropdown-cart-button .dropdown.dropdown-right{
	top: 32px;z-index:200 !important;
}
.dropdown-cart-button .dropdown.dropdown-right a{
	border:0px;
	text-shadow: 0px 0px 0px rgba(0,0,0,0.6) !important; 
}
.dropdown-cart-button .dropdown .cart_list li{
	margin: 10px 0px !important;
    padding: 0px 0px !important;
    float: none !important;
    line-height: inherit;
    padding-bottom: 15px !important;
}
.dropdown-cart-button .dropdown .cart_list li a{
	color: #000 !important;
}
.dropdown-cart-button .dropdown .buttons .button {
    background-color: #0090ff !important;
    color: #fff !important;
    border:0px !important;
}
@media (max-width: 1023px){
	.navbar-toggle{
		margin-top: 18px !important;
		right: 0;
		display: block !important;
	}
	#header .navigation {
		background: rgba(0,0,0,.9);
		float: none !important;
		text-align: left;
	}
	#header .navigation.navbar-collapse{
		margin: 0px !important;
		top: 0;
		width: 100% !important;
	}
	#header .logo{
		width: 100% !important;
		float: none !important;
		display: block !important;
		margin: 0px;
		padding: 0px;
	}
	.nav-mobile-centered{
		padding-left: 0px;
		padding-right: 0px;
		top: 0;
	}
	#header nav li{
		display: block !important;
		float: none !important;
		line-height: inherit;
		margin: 10px 0px;
	}
	#navbar-primary-secondary{
		display: none;
		width: 100%;
	}
	#header nav ul.sub-menu {
	    margin: 0px;
	    position: static;
	    display: block !important;
	    background: none;
	    border: 0px;
	    margin-left: 10px;
	    margin-top: 5px;
	    width: 100% !important;
	}
	#header nav ul.sub-menu li a {
	    padding: 5px 5px;
	    display: inline-block !important;
	}
	.sub-menu li:before {
	    content: "-";
	}
	.widget.widget_shopping_mini_cart.dropdown-cart {
    position: absolute;
    right: 15px;
    bottom: 0px;    top: auto;
}
}	
</style> 
<div id="content" class="site-content">
