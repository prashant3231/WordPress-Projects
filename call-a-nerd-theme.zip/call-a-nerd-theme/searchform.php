<form role="search" method="get" class="search-form" action="<?php echo home_url() ?>">
				<label>
					<span class="screen-reader-text">Suche nach:</span>
				</label>
				<input type="search" class="search-field" placeholder="Suche&nbsp;…" value="" name="s">

				<input type="submit" class="search-submit" value="Suche">
			</form>