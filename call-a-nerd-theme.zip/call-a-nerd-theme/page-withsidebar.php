<?php
if(get_locale()=='de_DE' || get_locale()=='de_DE_formal' || get_locale()=='de_CH' || get_locale()=='de_CH_informal'){/**
 * Template Name: Mit Sidebar
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package CaN
 */}else{
/**
 * Template Name: page with sidebar
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package CaN
 */
}
get_header(); ?>
		<?php $featuresize=get_post_meta($post->ID, "featuresize", true); 
	$featuresize=(($featuresize=='')?of_get_option('page_feature_size'):$featuresize);
$page_title_position=get_post_meta($post->ID, "page_title_position", true);
if($page_title_position==''){
	$page_title_position=of_get_option('page_title_position');
}
		 ?>
	<?php 
		if($featuresize=='box' || $featuresize=='full'){
			if($featuresize=='box'){
				$fclass='container';
				$finclasss='col-sm-12';
			}
		
	 ?>
	<div class='feature-image <?php echo $fclass;?>'>
		
					<div id="primary" class="feature-image-inner">
					<?php 	if(has_post_thumbnail()){ ?>
						<div class='feature-image-inner-image <?php echo $finclasss ?>' style='background:url(<?php echo the_post_thumbnail_url( "full" ); ?>)'>
					<?php 	} else { ?>
					<div class='feature-image-inner-image <?php echo $finclasss ?>' style='background:url(<?php 
					echo esc_url( get_template_directory_uri("template_directory") ) ; ?>/images/default.jpg)' >
					<?php 	} ?>
								
								<?php if($page_title_position=='image_center'){ ?> 
								<div class="page-title">
									<h1><?php the_title(); ?></h1> 
								</div>
								<?php } ?>
							
						</div>

					</div>
				
	</div>
	<?php } ?>
	<div id="primary" class="content-area content-area-with-sidebar container">
		<main id="main" class="site-main clearfix" role="main">
			<?php $t=get_the_title(); ?>

			<div class="row">
			<div class='content-left sidebar col-md-9 <?php echo $t ?>'>
				<?php if($featuresize=='content'){ ?>

					<div class='feature-image-inner-image' style='background:url(<?php echo the_post_thumbnail_url( "full" ); ?>)'>
							<?php if($page_title_position=='image_center' ){ ?> 
							<div class="page-title">
									<h1><?php the_title(); ?></h1> 
								</div>
							<?php } ?>
					</div>
				<?php } ?>

				<?php if(($page_title_position=='image_under' || $featuresize=='nofeature') && $page_title_position!='hide'){ ?> <div class="kc-row-container  kc-container"><h1><?php the_title(); ?></h1></div> <?php } ?>
				<?php
				while ( have_posts() ) : the_post();

					the_content();

					// If comments are open or we have at least one comment, load up the comment template.
					if ( comments_open() || get_comments_number() ) :
						comments_template();
					endif;

				endwhile; // End of the loop.
				?>
				
			</div>

			<div class='content-right col-md-3 sidebar'>	
				<?php get_sidebar(); ?>
			</div>
			</div>
		</main><!-- #main -->
	</div><!-- #primary -->

<?php

get_footer();
