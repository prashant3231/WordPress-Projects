<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package CaN
 */

get_header(); ?>

<div class="sub-header">
    <div class="container">
    	<h1 class="page-title"><?php if ( is_author() ) {
        echo ( get_query_var( 'author_name' ) ) ? get_user_by( 'slug', get_query_var( 'author_name' ) ) : get_userdata( get_query_var( 'author' ) );
    } ?></h1>
          </div>
</div>

	<div class="container blog-post">
    	<div class="row">
		<div class="content-left col-md-9"><div class="blog-group">
            <?php while(have_posts()){ the_post(); ?> 
            <?php $thum=((has_post_thumbnail())?'has-post-thumbnail':'no-thumbnail'); ?>
            <article class="post type-post status-publish format-standard <?php echo $thum ?> hentry category-allgemein">
            	 <header class="entry-header">
                    <figure>    	
                        <?php the_post_thumbnail() ?>  
                    </figure>
                </header><!-- .entry-header -->
                <div class="entry-content">
                    <?php if(has_post_thumbnail()){ ?>
                    <div class="post-date">
                        <span><?php the_time('d') ?></span>
                        <em><?php the_time('M') ?> <?php the_time('Y') ?></em>
                    </div>
                    <?php } else { ?>
                    <div class="post-date-outer">
                        <div class="post-date">
                            <span><?php the_time('d') ?></span>
                        <em><?php the_time('M') ?> <?php the_time('Y') ?></em>
                        </div>
                    </div>
                    <?php } ?>
                    <div class="post-desc">
                    	<div class="entry-title">
                            <h2><a href="<?php the_permalink() ?>">Worldwide Users</a></h2>
                            <ul class="post-meta">
                              
                                <li><i class="fa fa-user" aria-hidden="true"></i><?php echo get_the_author_link(); ?></li>
                                <li><i class="fa fa-comments" aria-hidden="true"></i><a href="<?php the_permalink() ?>"><?php comments_number() ?></a></li>
                                <li><i class="fa fa-folder" aria-hidden="true"></i><?php the_category(',') ?></li>
                        
                            </ul>
                        </div>
                        <p><?php the_excerpt(); ?></p>
                    </div>
                </div>
            </article>
			<?php } ?></div>
			<?php /*
            if ( have_posts() ) :
    			
                if ( is_home() && ! is_front_page() ) : ?>
                    <!--<header>
                        <h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
                    </header>-->
    
                <?php
                endif;
    
             
                while ( have_posts() ) : the_post();
    
                    
					 the_post_thumbnail();
                    get_template_part( 'template-parts/content', get_post_format() );
    
                endwhile;
    
                the_posts_navigation();
    
            else :
    
                get_template_part( 'template-parts/content', 'none' );
    
            endif; */?>
        </div>
        <div class='content-right col-md-3 sidebar'>
        	<?php get_sidebar(); ?>
        </div>
        </div>
	</div><!-- container -->

<?php
get_footer();
