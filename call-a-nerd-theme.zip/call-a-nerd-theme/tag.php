<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package CaN
 */

get_header(); ?>

 <?php  


$queried_object = get_queried_object();
$metadata=get_option('taxonomy_term_'.$queried_object->term_id); 

if($metadata['term_featuresize']=='none'){
$metadata['term_featuresize']=of_get_option('blog_category_page_feature_size');
}

$featuresize=$metadata['term_featuresize'];    

// Get the current category ID, e.g. if we're on a category archive page
 $cat_id = $queried_object->term_id;

// Get the image ID for the category
$image_id = get_term_meta ( $cat_id, 'category-image-id', true );
// Echo the image
if($image_id!=''){
$imgsrc= wp_get_attachment_image_src( $image_id, 'large' );    
$imgsrc=$imgsrc[0];
}
else{
$imgsrc='';    
}


if(( $featuresize =='full' || $featuresize =='' ) && $imgsrc!=''){ ?>
<div class="sub-header sub-header-bg" style="background-image:url(<?php echo $imgsrc  ?>)">
    <div class="page-title">
        <h1><?php single_term_title() ?></h1>
    </div>
</div>
<?php   }  else if($featuresize =='nofeature' || $imgsrc=='') { ?>
<div class="sub-header">
    <div class="container">
        <h1 class="page-title"><?php single_term_title() ?></h1>     
        <nav class="woocommerce-breadcrumb"><a href="<?php echo site_url();?>"><?php echo __('Home','call-a-nerd-theme');?> </a>/ <?php single_term_title() ?></nav>
    </div>
</div>
    

<?php   } ?>


<?php 


if($metadata['template']==''){
$metadata['template']=of_get_option('blogkategoriedesign'); 
if($metadata['template']==''){
    $metadata['template']='template-3';    
}   

}

$blogseitendesign=$metadata['template'];

$blogseitendesigna=explode('-',$blogseitendesign);     

if(isset($metadata['term_layout']))
$term_layout=$metadata['term_layout'];
else
$term_layout='';

if($term_layout==''){
        $term_layout=of_get_option('blog_category_layout');
}


?>
 <?php if($featuresize =='box' && $imgsrc!=''){ ?>
    <div class="sub-header sub-header-bg container" style="background-image:url(<?php echo $imgsrc  ?>)">
        <div class="page-title">
            <h1><?php echo single_term_title(); ?></h1>
        </div>
    </div>
                
                <?php } ?>
<div id="blog-template-type-<?php  echo $blogseitendesigna[1] ?>">

     <?php  $ec=(($term_layout=='without-sidebar' || $term_layout=='')?'sw':'') ?>   

	<div class="container blog-post <?php  //echo $ec ?>">

                   


    	<div class="row">
<?php             if($term_layout=='without-sidebar'){  $class='col-md-12'; }  
            else if($term_layout=='with-sidebar') {  $class='col-md-9'; }
            else if($term_layout=='with-sidebar-left'){ $class='col-md-9 pull-right'; }     ?>
            
            <div class="bp-listing content-left <?php echo $class ?>">

                                <?php if($featuresize =='content' && $imgsrc!=''){ ?>
    <div class="sub-header sub-header-bg" style="background-image:url(<?php echo $imgsrc  ?>)">
        <div class="page-title">
            <h1><?php echo single_term_title(); ?></h1>
        </div>
    </div>
    <?php } ?>


             <div class="catdes"> <?php echo category_description($queried_object->term_id); ?> </div>   
          <div class="blog-group">  <?php if($metadata['template']=='template-1'){?><div class="row"><?php $counter = 1;while(have_posts()){ the_post(); ?> 
              
              <?php $template=$metadata['template'];get_template_part( 'blog/content', $template ); ?>
           
						<?php  if($counter % 2 === 0) :?>
        </div><div class="row">
      <?php endif; ?>
					   <?php $counter++;} ?></div><?php }else{ ?><?php while(have_posts()){ the_post(); ?> 
              
              <?php $template=$metadata['template'];get_template_part( 'blog/content', $template ); ?>
           
						
					   <?php } ?><?php } ?></div>
           
                        
                    <?php 
        $big = 999999999; // need an unlikely integer

        the_posts_pagination( array( 'mid_size'  => 2 ) );

                     ?> 


			
        </div>
<?php if($term_layout=='with-sidebar' || $term_layout=='with-sidebar-left'){ ?>
        <div class="content-right col-md-3 sidebar  <?php echo (($term_layout=='with-sidebar-left')?'pull-left':'') ?>"> 
            <?php get_sidebar() ?>
        </div>
        <?php   } ?>
        </div>
    </div><!-- container -->
    </div>

    
        </div>
	</div><!-- container -->

<?php
get_footer();
