<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package CaN
 */

get_header(); global $post; ?>

<?php 
$featuresize=get_post_meta($post->ID, "featuresize", true);
    $featuresize=(($featuresize=='')?of_get_option('post_feature_size'):$featuresize);
$layout=get_post_meta($post->ID, "layout", true);
$page_title_position=get_post_meta($post->ID,'page_title_position', true);
  ?>
<?php 
if($page_title_position==''){
$page_title_position=of_get_option('post_title_position');    
}

if($layout==''){
$layout=of_get_option('blog_single_layout');    
}

 ?>


<?php   if($featuresize =='full' && get_the_post_thumbnail_url($post->ID, 'full')){ ?>
<div class="sub-header sub-header-bg" style="background-image:url(<?php echo get_the_post_thumbnail_url($post->ID, 'full') ?>)">
	<div class="page-title">
    <?php if($page_title_position=='image_center'){ ?>
        <h1><?php the_title() ?></h1>
        <?php   } ?>
    </div>
</div>
<?php   }  ?>

	<div  class="container">
		<div class="row">
        <?php if(has_post_thumbnail() && $featuresize =='box'){ ?> 
                <div class="col-md-12">
                  <div class="sub-header sub-header-bg container" style="background-image:url(<?php echo get_the_post_thumbnail_url($post->ID, 'full') ?>)">
                    <div class="page-title">
                        <?php if($page_title_position=='image_center'){ ?>
                            <h1><?php the_title() ?></h1>
                            <?php   } ?>
                    </div>
                </div>
                </div>            
            
                
                <?php } ?>

<?php             if($layout=='without-sidebar'){  $class='col-md-12'; }  
            else if($layout=='with-sidebar') {  $class='col-md-9'; }
            else if($layout=='with-sidebar-left'){ $class='col-md-9 pull-right'; }     ?>

            
		<div class="content-left <?php echo $class ?>">
                <?php
        while ( have_posts() ) : the_post(); ?>

                <article class="post type-post status-publish format-standard <?php echo $thum ?> hentry category-allgemein">
                <?php if(has_post_thumbnail() && $featuresize =='content'){ ?> 
                  <div class="sub-header sub-header-bg" style="background-image:url(<?php echo get_the_post_thumbnail_url($post->ID, 'full') ?>)">
                    <div class="page-title">
                        <?php if($page_title_position=='image_center'){ ?>
                            <h1><?php the_title() ?></h1>
                            <?php   } ?>
                    </div>
                </div>
                            
            
                
                <?php } ?>
                <div class="entry-content">
                  
                    <div class="post-desc">
                        <?php if($page_title_position!='image_center' || $featuresize =='nofeature'){ ?>    
                         <h1 class='posttitle'><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h1>
                        <?php }  ?>
                        <?php if(of_get_option('showmetdata')==1){ ?>
                            <ul class="post-meta">
                              
                                <li><i class="fa fa-user" aria-hidden="true"></i><?php echo get_the_author_link(); ?></li>
								
                                <li><i class="fa fa-comments" aria-hidden="true"></i><a href="<?php the_permalink() ?>"><?php comments_number() ?></a></li>
                                <li><i class="fa fa-folder" aria-hidden="true"></i><?php the_category(',') ?></li>
                        
                            </ul>
                            <?php } ?>
                        <?php the_content(); ?>
                      
                    </div>
                    <div class='clearfix'></div>
                </div>
            </article>
           
            
                <?php
			//get_template_part( 'template-parts/content', get_post_format() );

			//the_post_navigation();

			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;

		endwhile; // End of the loop.
		?>
<?php if(of_get_option('post_hide_c')=='Show' || of_get_option('post_hide_t')=='Show'){ ?>
                              
                                
								
                                <?php if(of_get_option('post_hide_c')=='Show'){ ?>
                                <strong><p><i class="fa fa-folder" aria-hidden="true"></i> <?php echo __('Categories','call-a-nerd-theme');?>: <?php the_category(',') ?></p><?php } ?> <?php if(of_get_option('post_hide_t')=='Show'){ ?>
								<p><i class="fa fa-tag" aria-hidden="true"></i> <?php echo __('Tags','call-a-nerd-theme');?>: <?php $post_tags = get_the_tags();
    $separator = ' | ';
    if (!empty($post_tags)) {
        foreach ($post_tags as $tag) {
            $output .= '<a href="' . get_tag_link($tag->term_id) . '">' . $tag->name . '</a>' . $separator;
        }
        echo trim($output, $separator);
    } ?></p></strong><br/><br/><?php } ?>
                        
                            </ul>
                           <?php } ?> 
        <?php $hidepost=get_post_custom( get_the_ID() );$hide=$hidepost['relatedpost'][0];if($hide=='')$hide=of_get_option('show_related_post_post');    ?>
        <?php if($hide!='none' && $hide!='1' ){ ?>
        <div class='relatedpost row'>
                            <div class='col-md-12'>
                            <h3 id="reply-title" class="comment-reply-title"><?php echo __('Related posts','call-a-nerd-theme');?></h3>
                            </div>
                        <?php
                        global $post;
                         $args = array(
        'post_type'     => 'post',
        'post_status'   => 'publish',
        'meta_query' => array(
            array(
                'key' => 'excluderelatedpost',
                'value' => '1' 
            )
        )
    );

    $queryexc  = new WP_Query($args);$post_ids = wp_list_pluck( $queryexc->posts, 'ID' );
											   $resultcat = array_diff(wp_get_post_categories($post->ID,  array( 'fields' => 'ids' )), array('1'));
                        if(of_get_option('show_related_post_by')=='category'  && $resultcat){
                                $args=array('category__in' =>$resultcat ,  'post__not_in' => array_unique(array_merge($post_ids,array($post->ID)), SORT_REGULAR),'numberposts' => 4,);
                         }
                         else if(of_get_option('show_related_post_by')=='tag' && wp_get_post_tags($post->ID,  array( 'fields' => 'ids' ))){
                         
                         $args=array('tag__in' =>wp_get_post_tags($post->ID,  array( 'fields' => 'ids' )),  'post__not_in' => array_unique(array_merge($post_ids,array($post->ID)), SORT_REGULAR),'numberposts' => 4,);
                         }
                         else if(of_get_option('show_related_post_by')=='random'){
                           $args=array('orderby'   => 'rand', 'numberposts' => 4, 'post__not_in' => array_unique(array_merge($post_ids,array($post->ID)), SORT_REGULAR), );  
                         }
                         else{
                            $args=array('numberposts' => 4, 'post__not_in' => array_unique(array_merge($post_ids,array($post->ID)), SORT_REGULAR), 'order'=>'DESC', 'orderby'=>'ID',);  
                         }

                            query_posts($args); 
                         
$i=0;
                                                  
                         ?>
                        <?php  if ( have_posts() ) : while(have_posts() && $i<=3){the_post(); ?> 
                            <div class='related-posts col-sm-3'>
                                 <a href="<?php the_permalink() ?>">
                                   <?php   if(has_post_thumbnail()){  ?> 
                                <div class='related-featured-image'><img src="<?php echo the_post_thumbnail_url()?>"></div>
                                    <?php   } else { ?>
                                <div class='related-featured-image'><img src="<?php echo esc_url( get_template_directory_uri('template_directory') ) ?>/images/noimage.png"></div>
                                
                                <?php   } ?>

                                <h4><?php the_title(); ?></h4>    
                                </a>
                            </div>
                            
                        <?php $i++;}  else: ?> <div class='related-posts col-sm-3'><h4><?php echo __('None','call-a-nerd-theme'); ?>!</h4></div> <?php endif;?>
            
        </div>

        <?php } ?>
</div>


<?php if($layout=='with-sidebar' || $layout=='with-sidebar-left'){ ?>
        <div class="content-right col-md-3 sidebar  <?php echo (($layout=='with-sidebar-left')?'pull-left':'') ?>"> 
            <?php get_sidebar(); ?>
        </div>
        <?php   } ?>
        
        </div>

    </div><!-- container -->



</div>
	</div><!-- #primary -->

<?php
get_footer();
