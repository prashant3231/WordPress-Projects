<style type="text/css">
.widget.woocommerce > .price_slider_wrapper > .hide_cart_widget_if_empty > .widget_shopping_cart_content > .mid-visible, .widget.woocommerce > .price_slider_wrapper > .hide_cart_widget_if_empty > .widget_shopping_cart_content > .total.shipping-costs-cart-info.wc-gzd-total-mini-cart{display: none;}
<?php $options=get_option('options-framework-theme'); 
		$example_colorpicker_tab=$options['example_colorpicker_tab'];
?>
	<?php if($example_colorpicker_tab['header_border_bottom_show_hide']=='Show'){?>
	#header{border-bottom: 1px solid <?php echo $example_colorpicker_tab['header_border_bottom_color']; ?> !important;}
	<?php }	?>
#header.header-overlay.tao, #header.header-overlay{
		background-color: transparent;
		border-bottom: none !important;
	}
	<?php if(of_get_option('blog_hide_title')=='Hide')echo '.blog .page-title{display: none !important;}';?>
	<?php if(of_get_option('shop_title_position')=='Hide')echo '.archive.post-type-archive.post-type-archive-product .page-title{display: none !important;}';?>
.top-strip{background-color: <?php echo $example_colorpicker_tab['preheader_background_Color']; ?>;
 color: <?php echo $example_colorpicker_tab['preheader_font_Color']; ?>;}
#top-primary-menu > li a, #top-secondary-menu > li a, #top-primary-menu > li a:hover, #top-secondary-menu > li a:hover{color: <?php echo $example_colorpicker_tab['preheader_font_Color']; ?>;text-decoration:none;}
 #header, #header.sticky_menu,#header.header-overlay.tao.sticky_menu, #header.header-overlay.sticky_menu {
 	background-color: <?php echo $example_colorpicker_tab['header_background_Color']; ?>;
 }


	
#header nav div ul > li > a{	
	font-size:<?php echo $options['header-font-size']; ?>px  !important;
}
@media only screen and (min-width: 1023px) and (max-width: 5500px) {	
#header.header-overlay.tao nav > div > ul > li > a{
	color: <?php echo $example_colorpicker_tab['header_menu_color']; ?> !important;
	text-shadow: 0px 1px 8px <?php echo $example_colorpicker_tab['header_menu_shadow_color']; ?> !important;
	font-weight: 700;
}
#header.header-overlay.tao nav .dropdown-cart-button a.dropdown-total{
	color: <?php echo $example_colorpicker_tab['header_menu_color']; ?> !important;
	text-shadow: 0px 1px 8px <?php echo $example_colorpicker_tab['header_menu_shadow_color']; ?> !important;
	font-weight: 700;
}
	
	
#header.header-overlay.sticky_menu nav > div > ul > li > a, #header.header-overlay.tao.sticky_menu nav > div > ul > li > a, #header nav > div > ul > li > a, #header.header-overlay.sticky_menu .dropdown-cart-button a.dropdown-total, #header  nav > div .dropdown-cart-button a.dropdown-total, #header.header-overlay.tao.sticky_menu .dropdown-cart-button a.dropdown-total{
	color: <?php echo $example_colorpicker_tab['solid_header_menu_color']; ?> !important;
	font-weight: 700;
	text-shadow: none !important;
}

	
#header.header-overlay.sticky_menu nav > div > ul > li > a:hover, #header.header-overlay.tao.sticky_menu nav > div > ul > li > a:hover, #header nav > div > ul > li > a:hover{
	color: <?php echo $example_colorpicker_tab['solid_header_menu_color_hover']; ?> !important;
}
	
#header.header-overlay.tao nav > div > ul > li > a:hover{
	color: <?php echo $example_colorpicker_tab['header_menu_color_hover']; ?> !important;
}
	
	
#header.header-overlay.sticky_menu nav > div > ul > li.current-menu-item > a, #header.header-overlay.tao.sticky_menu nav > div > ul > li.current-menu-item > a, #header nav > div > ul > li.current-menu-item > a{
	color: <?php echo $example_colorpicker_tab['solid_header_menu_color_hover']; ?> !important;
}
	
#header.header-overlay.tao nav > div > ul > li.current-menu-item > a {
    color: <?php echo $example_colorpicker_tab['header_menu_color_hover']; ?> !important;
}
	
	}	

#header nav li.mini_cart_item a, #header nav li.mini_cart_item span{color: #000000;float:right;}.dropdown.dropdown-right p.wc-gzd-additional-info{line-height:0px !important;float:left !important;margin-top:20px;}.dropdown.dropdown-right p.wc-gzd-additional-info a{padding:0px 0px !important;line-height:0px !important;}.dropdown-cart-button .dropdown .cart_list li{line-height: inherit !important;}.cart_totals p.wc-gzd-additional-info {
	width: 100% !important;
	border-top: 1px solid #CCC;
}
#header .dropdown-cart-button li.mini_cart_item a, #header.header-overlay .dropdown-cart-button li.mini_cart_item a,  #header.header-overlay.tao .dropdown-cart-button li.mini_cart_item a, #header.sticky_menu .dropdown-cart-button li.mini_cart_item a, #header.header-overlay.sticky_menu .dropdown-cart-button li.mini_cart_item a, #header.header-overlay.tao.sticky_menu .dropdown-cart-button li.mini_cart_item a{color: #000000 !important;}#place_order{float: right;}


.woocommerce-checkout h3, h1.woocommerce-products-header__title.page-title {
    color:  <?php echo $example_colorpicker_tab['main_content_heading_color']; ?> !important;
}
.sub-header{background-color: <?php echo $example_colorpicker_tab['subheader_background_color']; ?>!important;}
#content .sub-header .page-title, .sub-header .page-title, .sub-header .woocommerce-breadcrumb{color: <?php echo $example_colorpicker_tab['subheader_font_color']; ?>!important;}
ins{text-decoration: none !important;}
	.woocommerce div.product p.price, .woocommerce div.product span.price, .variations .label{color: #000000;}
.site-content h1.page-title, .site-content h1.posttitle a, .site-content h1.posttitle{
    color:  <?php echo $example_colorpicker_tab['main_content_heading_color']; ?> !important;text-decoration:none;
}
	.site-content a{color:  <?php echo $example_colorpicker_tab['main_content_anchor_color']; ?>;}
	.mark, mark{color:  <?php echo $example_colorpicker_tab['main_content_anchor_color']; ?> !important;}
	.mark, mark{background-color:transparent !important;}

	.site-content a:hover{color:  <?php echo $example_colorpicker_tab['main_content_anchor_hover_color']; ?>;}
	.mark:hover, mark:hover{color:  <?php echo $example_colorpicker_tab['main_content_anchor_hover_color']; ?> !important;}
	article .entry-content h2.post-title a, ul li h3.product-title a, .related-posts a{color:  <?php echo $example_colorpicker_tab['main_blog_post_title_color']; ?>;}
	article .entry-content h2.post-title a:hover, ul li h3.product-title a:hover, .related-posts a:hover{color:  <?php echo $example_colorpicker_tab['main_blog_post_title_hover_color']; ?>;}
	article .entry-content .post-desc .post-meta a, article .entry-content .author-info a{color:  <?php echo $example_colorpicker_tab['main_blog_post_meta_color']; ?>;}
	article .entry-content .post-desc .post-meta a:hover, article .entry-content .author-info a:hover{color:  <?php echo $example_colorpicker_tab['main_blog_post_meta_hover_color']; ?>;}
 
	
.site-content{background-color: <?php echo $example_colorpicker_tab['main_content_background']; ?> !important;}
	
#header.header-overlay.tao nav .dropdown.dropdown-right p.wc-gzd-additional-info a, .dropdown.dropdown-right p.wc-gzd-additional-info a{color:  <?php echo $example_colorpicker_tab['main_content_anchor_color']; ?> !important;}
#header.header-overlay.tao nav .dropdown.dropdown-right p.wc-gzd-additional-info a:hover, .dropdown.dropdown-right p.wc-gzd-additional-info a:hover{color:  <?php echo $example_colorpicker_tab['main_content_anchor_hover_color']; ?> !important;}

	
.kc-blog-posts a.kc-post-2-button, a.kc-post-2-button, #add_payment_method .wc-proceed-to-checkout a.checkout-button, .woocommerce-cart .wc-proceed-to-checkout a.checkout-button, .woocommerce-checkout .wc-proceed-to-checkout a.checkout-button, input[name="apply_coupon"], .checkout-button, input[name="update_cart"], #place_order,  a.button, button.button, input.button, #header .dropdown-cart-button .dropdown .buttons .button, input.submit, input[type="submit"], input[type="button"], .search-form .search-submit, .product-buttons .button.add_to_cart_button, .woocommerce div.product form.cart .button{
background-color:  <?php echo $example_colorpicker_tab['main_content_button_background_color']; ?> !important;
border-color:  <?php echo $example_colorpicker_tab['main_content_button_background_color']; ?> !important;
color: <?php echo $example_colorpicker_tab['main_content_button_color']; ?> !important;
}
.header-search{border: 2px solid <?php echo $example_colorpicker_tab['main_content_button_background_color']; ?>;}
.woocommerce-MyAccount-navigation .is-active {
	background: <?php echo $example_colorpicker_tab['main_content_button_background_color']; ?> !important;
}
.woocommerce-MyAccount-navigation li:hover {
	background: <?php echo $example_colorpicker_tab['main_content_button_background_color']; ?> !important;
}
.woocommerce-info, .dropdown.dropdown-right, .woocommerce-message, .woocommerce-error{border-top-color:  <?php echo $example_colorpicker_tab['main_content_button_background_color']; ?> !important;}.woocommerce-info::before, .woocommerce-message::before, .woocommerce-error::before{color:  <?php echo $example_colorpicker_tab['main_content_button_background_color']; ?> !important;}
ul.products > li.product > a.button, ul.products > li > div.product-buttons > div.product-buttons-box > form > button.button{background-color: rgba(0,0,0,0.5) !important;}
ul.products > li.product > a.button:hover, ul.products > li > div.product-buttons > div.product-buttons-box > form > button.button:hover{background-color:  <?php echo $example_colorpicker_tab['main_content_button_background_hover_color']; ?> !important;}

.kc-blog-posts a.kc-post-2-button:hover, a.kc-post-2-button:hover,#add_payment_method .wc-proceed-to-checkout a.checkout-button:hover, .woocommerce-cart .wc-proceed-to-checkout a.checkout-button:hover, .woocommerce-checkout .wc-proceed-to-checkout a.checkout-button:hover, input[name="apply_coupon"]:hover, .checkout-button:hover, input[name="update_cart"]:hover, #place_order:hover,  a.button:hover, button.button:hover, input.button:hover, #header .dropdown-cart-button .dropdown .buttons .button:hover, input.submit:hover, input[type="submit"]:hover, input[type="button"]:hover, .search-form .search-submit:hover, .product-buttons .button.add_to_cart_button:hover, .woocommerce div.product form.cart .button:hover{
background-color:  <?php echo $example_colorpicker_tab['main_content_button_background_hover_color']; ?> !important;
color: <?php echo $example_colorpicker_tab['main_content_button_hover_color']; ?> !important;
}
	
.single-product h1.product_title{color: <?php echo $example_colorpicker_tab['main_content_single_product_title_color']; ?> !important; }



.sidebar .widget {
    /*margin-top: 0 !important;
    box-sizing: content-box !important;*/
    overflow: hidden;
}
.sidebar p {
	word-wrap: break-word !important;
	}

.content-right .widget.woocommerce {
	background: <?php echo $example_colorpicker_tab['sidebar_widget_background_color']; ?> !important;
	border: 1px solid <?php echo $example_colorpicker_tab['sidebar_border_background_color']; ?> !important;
	padding: 10px;
}

.sidebar .widget-title:after {
    background: <?php echo $example_colorpicker_tab['sidebar_border_background_color']; ?> !important;
}




<?php
 if($example_colorpicker_tab['main_content_background']!=$example_colorpicker_tab['sidebar_background_color']){ ?>
.post .sidebar, .archive .sidebar, .page .sidebar, .category .sidebar, .tag .sidebar {
    /*margin-top: 25px;*/
}
.product .sidebar {
    /*margin-top: 0px;*/
}
<?php } ?>


.content-right.col-md-3.sidebar .page-sidebar{
background:  <?php echo $example_colorpicker_tab['sidebar_background_color']; ?> !important;
	color: <?php echo $example_colorpicker_tab['sidebar_font_content_color'] ?> !important;
}

.content-right.col-md-3.sidebar label, .content-right.col-md-3.sidebar  .priceValue, .content-right.col-md-3.sidebar .total strong{
	color: <?php echo $example_colorpicker_tab['sidebar_font_content_color']; ?> !important;

}
.content-right.col-md-3.sidebar a{
	color: <?php echo $example_colorpicker_tab['sidebar_anchor_color']; ?> !important;
	text-decoration: none;
}
.content-right.col-md-3.sidebar a:hover{
	color: <?php echo $example_colorpicker_tab['main_content_anchor_hover_color']; ?> !important;
}
.sidebar .widget ul li.cat-item.current-cat a{
	color: <?php echo $example_colorpicker_tab['main_content_anchor_hover_color']; ?> !important;
}

.content-right.col-md-3.sidebar button, .content-right.col-md-3.sidebar input[type="button"], .content-right.col-md-3.sidebar input[type="submit"], .content-right.col-md-3.sidebar a.button, .content-right.col-md-3.sidebar .button, a.default-btn, .content-right.col-md-3.sidebar .textwidget a.default-btn{
	color: <?php echo $example_colorpicker_tab['sidebar_button_color']; ?> !important;
	background-color: <?php echo $example_colorpicker_tab['sidebar_button_background_color']; ?> !important;

	
}

.sidebar .widget-title{
	color:<?php echo $example_colorpicker_tab['sidebar_content_heading_color']; ?> !important;
}
.sidebar .widget-title:after {
 	color:<?php echo $example_colorpicker_tab['sidebar_content_heading_color']; ?> !important;
 }



.sidebar .widget-title,.sidebar p.widget-title{font-size:<?php echo $options['sidebar-title-font-size']; ?>px !important;}
.sidebar .price_slider_amount, .sidebar .price_slider_wrapper, .sidebar p, .sidebar ul li{font-size:<?php echo $options['sidebar-text-font-size']; ?>px !important;}
.site-footer {
	background-color: <?php echo $example_colorpicker_tab['footer_background']; ?> !important;
	color:<?php echo $example_colorpicker_tab['footer_color']; ?> !important;
}
.site-footer .widgetsection, .site-footer .widget-title{
	font-size:<?php echo $options['footer-font-size']; ?>px !important;
}
.site-footer a{
	color: <?php echo $example_colorpicker_tab['footer_anchor_color']; ?> !important;
}
.site-footer a:hover{
	color: <?php echo $example_colorpicker_tab['footer_anchor_hover_color']; ?> !important;
}
.site-footer .price_slider_wrapper li.current-cat a{
	color: <?php echo $example_colorpicker_tab['footer_anchor_hover_color']; ?> !important;
}

.site-footer  h3{
	color:<?php echo $example_colorpicker_tab['footer_title']; ?> !important;
}

.sidebar .widget select{width: 100%;}	

ul.sub-menu {
    position: absolute;
    z-index: 99999;
    background: rgba(0,0,0,0.8);
    top: 49px;
    display: none;
}
#header nav li {
    float: left;
    display: block;
    padding-bottom: 0;
}

#header nav li:hover ul li a{
	color: #fff;
}
section {
     margin: 0px 0; 
}
	

<?php
	
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {          
if(is_single() && !is_product() && !is_page()){ 
	$background_image='';
	$background_color='';
	$metaback = get_post_custom( get_the_ID() );
	$options_page=get_option('options-framework-theme');
	$back_type = ( isset( $metaback['background_type'][0] ) ) ? $metaback['background_type'][0] : '';
	if($back_type!=''){
		if($back_type=='bimage' && $metaback['podcast_file'][0] !=''){
			$background_image = $metaback['podcast_file'][0];
			$background_image_style = $metaback['background_texture_style'][0];
			if($background_image_style=='no-repeat'){
			echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}
		}
		elseif($back_type=='bcolor'  && $metaback['background_color'][0]!=''){
			$background_color = ( isset( $metaback['background_color'][0] ) ) ? $metaback['background_color'][0] : '';
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
		elseif($back_type=='lthemeop'){
			if($options_page['posts_background_type']!='postsbnone'){
				if($options_page['posts_background_type']=='postsbimage' && $options_page['posts_background_image']!=''){
					$background_image = $options_page['posts_background_image'];
					$background_image_style = $options_page['posts_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
					
				}
				elseif($options_page['posts_background_type']=='postsbcolor' && $options_page['posts_background_color']!=''){
					$background_color = $options_page['posts_background_color']; 
					echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
				}
			}
			elseif($options_page['global_background_type']!='gbnone'){
				if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
					$background_image = $options_page['global_background_image'];
					$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
				}
				elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
					$background_color = $options_page['global_background_color'];
					echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";  
				}
			}
		}
	}
	elseif($options_page['posts_background_type']!='postsbnone'){
		if($options_page['posts_background_type']=='postsbimage' && $options_page['posts_background_image']!=''){
			$background_image = $options_page['posts_background_image'];
			$background_image_style = $options_page['posts_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['posts_background_type']=='postsbcolor' && $options_page['posts_background_color']!=''){
			$background_color = $options_page['posts_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}
	elseif($options_page['global_background_type']!='gbnone'){
		if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
			$background_image = $options_page['global_background_image'];
			$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
			$background_color = $options_page['global_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}  
}
elseif(is_page()){
	$background_image='';
	$background_color='';
	$metaback = get_post_custom( get_the_ID() );
	$options_page=get_option('options-framework-theme');
	$back_type = ( isset( $metaback['background_type'][0] ) ) ? $metaback['background_type'][0] : '';
	if($back_type!=''){
		if($back_type=='bimage' && $metaback['podcast_file'][0] !=''){
			$background_image = $metaback['podcast_file'][0];
			$background_image_style = $metaback['background_texture_style'][0];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($back_type=='bcolor'  && $metaback['background_color'][0]!=''){
			$background_color = ( isset( $metaback['background_color'][0] ) ) ? $metaback['background_color'][0] : ''; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
		elseif($back_type=='lthemeop'){
			if($options_page['pages_background_type']!='pagesbnone'){
				if($options_page['pages_background_type']=='pagesbimage' && $options_page['pages_background_image']!=''){
				$background_image = $options_page['pages_background_image'];
				$background_image_style = $options_page['pages_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
				}
				elseif($options_page['pages_background_type']=='pagesbcolor' && $options_page['pages_background_color']!=''){
					$background_color = $options_page['pages_background_color']; 
					echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
				}
			}
			elseif($options_page['global_background_type']!='gbnone'){
				if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
					$background_image = $options_page['global_background_image'];
					$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
				}
				elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
					$background_color = $options_page['global_background_color']; 
					echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
				}
			}
		}
	}
	elseif($options_page['pages_background_type']!='pagesbnone'){
		if($options_page['pages_background_type']=='pagesbimage' && $options_page['pages_background_image']!=''){
			$background_image = $options_page['pages_background_image'];
			$background_image_style = $options_page['pages_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['pages_background_type']=='pagesbcolor' && $options_page['pages_background_color']!=''){
			$background_color = $options_page['pages_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}
	elseif($options_page['global_background_type']!='gbnone'){
		if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
			$background_image = $options_page['global_background_image'];
			$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
			$background_color = $options_page['global_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}
}elseif(is_category()){
	$background_image='';
	$background_color='';
	$options_page=get_option('options-framework-theme');
	if($options_page['categories_background_type']!='categoriesbnone'){
		if($options_page['categories_background_type']=='categoriesbimage' && $options_page['categories_background_image']!=''){
			$background_image = $options_page['categories_background_image'];
			$background_image_style = $options_page['categories_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['categories_background_type']=='categoriesbcolor' && $options_page['categories_background_color']!=''){
			$background_color = $options_page['categories_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}
	elseif($options_page['global_background_type']!='gbnone'){
		if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
			$background_image = $options_page['global_background_image'];
			$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
			$background_color = $options_page['global_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}
}elseif(is_tag()){
	$background_image='';
	$background_color='';
	$options_page=get_option('options-framework-theme');
	if($options_page['tags_background_type']!='tagsbnone'){
		if($options_page['tags_background_type']=='tagsbimage' && $options_page['tags_background_image']!=''){
			$background_image = $options_page['tags_background_image'];
			$background_image_style = $options_page['tags_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['tags_background_type']=='tagsbcolor' && $options_page['tags_background_color']!=''){
			$background_color = $options_page['tags_background_color'];
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";  
		}
	}
	elseif($options_page['global_background_type']!='gbnone'){
		if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
			$background_image = $options_page['global_background_image'];
			$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
			$background_color = $options_page['global_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}

}elseif(is_shop()){
	$background_image='';
	$background_color='';
	$options_page=get_option('options-framework-theme');
	if($options_page['shop_background_type']!='shopbnone'){
		if($options_page['shop_background_type']=='shopbimage' && $options_page['shop_background_image']!=''){
			$background_image = $options_page['shop_background_image'];
			$background_image_style = $options_page['shop_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['shop_background_type']=='shopbcolor' && $options_page['shop_background_color']!=''){
			$background_color = $options_page['shop_background_color'];
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";  
		}
	}
	elseif($options_page['global_background_type']!='gbnone'){
		if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
			$background_image = $options_page['global_background_image'];
			$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
			$background_color = $options_page['global_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}

}elseif(is_product_category()){
	$background_image='';
	$background_color='';
	$options_page=get_option('options-framework-theme');
	if($options_page['productcategories_background_type']!='productcategoriesbnone'){
		if($options_page['productcategories_background_type']=='productcategoriesbimage' && $options_page['productcategories_background_image']!=''){
			$background_image = $options_page['productcategories_background_image'];
			$background_image_style = $options_page['productcategories_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['productcategories_background_type']=='productcategoriesbcolor' && $options_page['productcategories_background_color']!=''){
			$background_color = $options_page['productcategories_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}
	elseif($options_page['global_background_type']!='gbnone'){
		if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
			$background_image = $options_page['global_background_image'];
			$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
			$background_color = $options_page['global_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}
}elseif(is_product_tag()){
	$background_image='';
	$background_color='';
	$options_page=get_option('options-framework-theme');
	if($options_page['producttags_background_type']!='producttagsbnone'){
		if($options_page['producttags_background_type']=='producttagsbimage' && $options_page['producttags_background_image']!=''){
			$background_image = $options_page['producttags_background_image'];
			$background_image_style = $options_page['producttags_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['producttags_background_type']=='producttagsbcolor' && $options_page['producttags_background_color']!=''){
			$background_color = $options_page['producttags_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}
	elseif($options_page['global_background_type']!='gbnone'){
		if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
			$background_image = $options_page['global_background_image'];
			$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
			$background_color = $options_page['global_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}
}elseif(is_product()){
	$background_image='';
	$background_color='';
	$metaback = get_post_custom( get_the_ID() );
	$options_page=get_option('options-framework-theme');
	$back_type = ( isset( $metaback['background_type'][0] ) ) ? $metaback['background_type'][0] : '';
	if($back_type!=''){
		if($back_type=='bimage' && $metaback['podcast_file'][0] !=''){
			$background_image = $metaback['podcast_file'][0];
			$background_image_style = $metaback['background_texture_style'][0];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($back_type=='bcolor'  && $metaback['background_color'][0]!=''){
			$background_color = ( isset( $metaback['background_color'][0] ) ) ? $metaback['background_color'][0] : ''; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
		elseif($back_type=='lthemeop'){
			if($options_page['singleproducts_background_type']!='singleproductsbnone'){
				if($options_page['singleproducts_background_type']=='singleproductsbimage' && $options_page['singleproducts_background_image']!=''){
					$background_image = $options_page['singleproducts_background_image'];
					$background_image_style = $options_page['singleproducts_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
				}
				elseif($options_page['singleproducts_background_type']=='singleproductsbcolor' && $options_page['singleproducts_background_color']!=''){
					$background_color = $options_page['singleproducts_background_color']; 
					echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
				}
			}
			elseif($options_page['global_background_type']!='gbnone'){
				if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
					$background_image = $options_page['global_background_image'];
					$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
				}
				elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
					$background_color = $options_page['global_background_color'];
					echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";  
				}
			}
		}
	}
	elseif($options_page['singleproducts_background_type']!='singleproductsbnone'){
		if($options_page['singleproducts_background_type']=='singleproductsbimage' && $options_page['singleproducts_background_image']!=''){
			$background_image = $options_page['singleproducts_background_image'];
			$background_image_style = $options_page['singleproducts_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['singleproducts_background_type']=='singleproductsbcolor' && $options_page['singleproducts_background_color']!=''){
			$background_color = $options_page['singleproducts_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}
	elseif($options_page['global_background_type']!='gbnone'){
		if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
			$background_image = $options_page['global_background_image'];
			$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
			$background_color = $options_page['global_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}

}
else{$options_page=get_option('options-framework-theme');
	if($options_page['global_background_type']!='gbnone'){
		if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
			$background_image = $options_page['global_background_image'];
			$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
			$background_color = $options_page['global_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}

}

}
else{
if(is_single() && !is_page()){ 
	$background_image='';
	$background_color='';
	$metaback = get_post_custom( get_the_ID() );
	$options_page=get_option('options-framework-theme');
	$back_type = ( isset( $metaback['background_type'][0] ) ) ? $metaback['background_type'][0] : '';
	if($back_type!=''){
		if($back_type=='bimage' && $metaback['podcast_file'][0] !=''){
			$background_image = $metaback['podcast_file'][0];
			$background_image_style = $metaback['background_texture_style'][0];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($back_type=='bcolor'  && $metaback['background_color'][0]!=''){
			$background_color = ( isset( $metaback['background_color'][0] ) ) ? $metaback['background_color'][0] : '';
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
		elseif($back_type=='lthemeop'){
			if($options_page['posts_background_type']!='postsbnone'){
				if($options_page['posts_background_type']=='postsbimage' && $options_page['posts_background_image']!=''){
					$background_image = $options_page['posts_background_image'];
					$background_image_style = $options_page['posts_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
				}
				elseif($options_page['posts_background_type']=='postsbcolor' && $options_page['posts_background_color']!=''){
					$background_color = $options_page['posts_background_color']; 
					echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
				}
			}
			elseif($options_page['global_background_type']!='gbnone'){
				if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
					$background_image = $options_page['global_background_image'];
					$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
				}
				elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
					$background_color = $options_page['global_background_color'];
					echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";  
				}
			}
		}
	}
	elseif($options_page['posts_background_type']!='postsbnone'){
		if($options_page['posts_background_type']=='postsbimage' && $options_page['posts_background_image']!=''){
			$background_image = $options_page['posts_background_image'];
			$background_image_style = $options_page['posts_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['posts_background_type']=='postsbcolor' && $options_page['posts_background_color']!=''){
			$background_color = $options_page['posts_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}
	elseif($options_page['global_background_type']!='gbnone'){
		if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
			$background_image = $options_page['global_background_image'];
			$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
			$background_color = $options_page['global_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}  
}
elseif(is_page()){
	$background_image='';
	$background_color='';
	$metaback = get_post_custom( get_the_ID() );
	$options_page=get_option('options-framework-theme');
	$back_type = ( isset( $metaback['background_type'][0] ) ) ? $metaback['background_type'][0] : '';
	if($back_type!=''){
		if($back_type=='bimage' && $metaback['podcast_file'][0] !=''){
			$background_image = $metaback['podcast_file'][0];
			$background_image_style = $metaback['background_texture_style'][0];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($back_type=='bcolor'  && $metaback['background_color'][0]!=''){
			$background_color = ( isset( $metaback['background_color'][0] ) ) ? $metaback['background_color'][0] : ''; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
		elseif($back_type=='lthemeop'){
			if($options_page['pages_background_type']!='pagesbnone'){
				if($options_page['pages_background_type']=='pagesbimage' && $options_page['pages_background_image']!=''){
				$background_image = $options_page['pages_background_image'];
				$background_image_style = $options_page['pages_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
				}
				elseif($options_page['pages_background_type']=='pagesbcolor' && $options_page['pages_background_color']!=''){
					$background_color = $options_page['pages_background_color']; 
					echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
				}
			}
			elseif($options_page['global_background_type']!='gbnone'){
				if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
					$background_image = $options_page['global_background_image'];
					$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
				}
				elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
					$background_color = $options_page['global_background_color']; 
					echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
				}
			}
		}
	}
	elseif($options_page['pages_background_type']!='pagesbnone'){
		if($options_page['pages_background_type']=='pagesbimage' && $options_page['pages_background_image']!=''){
			$background_image = $options_page['pages_background_image'];
			$background_image_style = $options_page['pages_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['pages_background_type']=='pagesbcolor' && $options_page['pages_background_color']!=''){
			$background_color = $options_page['pages_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}
	elseif($options_page['global_background_type']!='gbnone'){
		if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
			$background_image = $options_page['global_background_image'];
			$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
			$background_color = $options_page['global_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}
}elseif(is_category()){
	$background_image='';
	$background_color='';
	$options_page=get_option('options-framework-theme');
	if($options_page['categories_background_type']!='categoriesbnone'){
		if($options_page['categories_background_type']=='categoriesbimage' && $options_page['categories_background_image']!=''){
			$background_image = $options_page['categories_background_image'];
			$background_image_style = $options_page['categories_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['categories_background_type']=='categoriesbcolor' && $options_page['categories_background_color']!=''){
			$background_color = $options_page['categories_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}
	elseif($options_page['global_background_type']!='gbnone'){
		if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
			$background_image = $options_page['global_background_image'];
			$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
			$background_color = $options_page['global_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}
}elseif(is_tag()){
	$background_image='';
	$background_color='';
	$options_page=get_option('options-framework-theme');
	if($options_page['tags_background_type']!='tagsbnone'){
		if($options_page['tags_background_type']=='tagsbimage' && $options_page['tags_background_image']!=''){
			$background_image = $options_page['tags_background_image'];
			$background_image_style = $options_page['tags_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['tags_background_type']=='tagsbcolor' && $options_page['tags_background_color']!=''){
			$background_color = $options_page['tags_background_color'];
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";  
		}
	}
	elseif($options_page['global_background_type']!='gbnone'){
		if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
			$background_image = $options_page['global_background_image'];
			$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
			$background_color = $options_page['global_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}

}
else{$options_page=get_option('options-framework-theme');
	if($options_page['global_background_type']!='gbnone'){
		if($options_page['global_background_type']=='gbimage' && $options_page['global_background_image']!=''){
			$background_image = $options_page['global_background_image'];
			$background_image_style = $options_page['global_background_texture_style'];
					if($background_image_style=='no-repeat'){
					echo "body{background:url('".site_url().$background_image."') ".$background_image_style." fixed center top !important;background-size: cover !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
			}else{
			echo "body{background:url('".site_url().$background_image."') ".(($background_image_style=='fixed')?$background_image_style." no-repeat center top":$background_image_style)."!important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}";
					}
		}
		elseif($options_page['global_background_type']=='gbcolor' && $options_page['global_background_color']!=''){
			$background_color = $options_page['global_background_color']; 
			echo "body{background-color:".$background_color." !important;} .site-content{background-color: transparent !important;}.sidebar {background: transparent !important;}.content-right .widget.woocommerce{
background: transparent !important;}"; 
		}
	}

}


} ?>	

</style>




