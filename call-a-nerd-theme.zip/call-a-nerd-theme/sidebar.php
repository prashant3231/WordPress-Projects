 <div class="page-sidebar">
<?php
wp_reset_query();
$the_sidebars = wp_get_sidebars_widgets();
$validation = get_option('key_validated')=='1'?'Valid':'Invalid';
$show_ad='';
if($validation=="Valid"){
	$show_ad = get_option('show_ad');
}


if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) { 

if(is_home()){
 dynamic_sidebar(of_get_option('blog_page_sidebar'));
 $wic=count($the_sidebars[strtolower(of_get_option('blog_page_sidebar'))]);
} 
else if(is_single()){
dynamic_sidebar(of_get_option('blog_detail_page_sidebar'));	
$wic=count($the_sidebars[strtolower(of_get_option('blog_detail_page_sidebar'))]);

}
else if(is_page()){
dynamic_sidebar(of_get_option('main_page_sidebar'));
$wic=count($the_sidebars[strtolower(of_get_option('main_page_sidebar'))]);
}
else if(is_shop()){
dynamic_sidebar(of_get_option('shop_page_sidebar'));
$wic=count($the_sidebars[strtolower(of_get_option('shop_page_sidebar'))]);
}
else if(is_product_category() || is_product_tag() ){
dynamic_sidebar(of_get_option('shop_category_page_sidebar'));
$wic=count($the_sidebars[strtolower(of_get_option('shop_category_page_sidebar'))]);
}
else if(is_product()){
dynamic_sidebar(of_get_option('shop_detail_page_sidebar'));
$wic=count($the_sidebars[strtolower(of_get_option('shop_detail_page_sidebar'))]);
}
else{
	$queried_object = get_queried_object();

if($queried_object->term_id!=''){
	dynamic_sidebar(of_get_option('blog_category_page_sidebar'));
	$wic=count($the_sidebars[strtolower(of_get_option('blog_category_page_sidebar'))]);
}else{
dynamic_sidebar('main-sidebar');	
$wic=count($the_sidebars['main-sidebar']);
}}
}
else
{
	if(is_home()){
 dynamic_sidebar(of_get_option('blog_page_sidebar'));
 $wic=count($the_sidebars[strtolower(of_get_option('blog_page_sidebar'))]);
} 
else if(is_single()){
dynamic_sidebar(of_get_option('blog_detail_page_sidebar'));	
$wic=count($the_sidebars[strtolower(of_get_option('blog_detail_page_sidebar'))]);

}
else{
	$queried_object = get_queried_object();

if($queried_object->term_id!=''){
	dynamic_sidebar(of_get_option('blog_category_page_sidebar'));
	$wic=count($the_sidebars[strtolower(of_get_option('blog_category_page_sidebar'))]);
}else{
dynamic_sidebar('main-sidebar');	
$wic=count($the_sidebars['main-sidebar']);
}}
}




 ?>

<?php if($wic>=4 && $show_ad!='1'){ if(get_locale()=='de_DE' || get_locale()=='de_DE_formal' || get_locale()=='de_CH' || get_locale()=='de_CH_informal'){?>

<div class="widget woocommerce">
<a href='https://callanerd.help/wordpress-theme/' target="_blank"  rel="nofollow">
	<p class="widget-title"  style="text-transform: none;">Diese Webseite wurde mit dem kostenlosen Call a Nerd Theme erstellt</p>

	    <div class="pipeSliderPrice"></div>
		<div class="price_slider_amount input_box clearfix">Klicke Sie hier um zu erfahren wie auch Sie Ihre Webseite mit dem kostenlosen Call a Nerd WordPress Theme erstellen können. Beim Premium Theme ist dieser Link optional und es sind viele weitere Zusatzleistungen enthalten. Bereitgestellt durch Ihre persönliche WooCommerce und Wordpress Agentur Call a Nerd aus Köln.</div>
		</a>	
</div>
<?php }else{?>
<div class="widget woocommerce">
<a href='https://callanerd.help/wordpress-theme/' target="_blank" rel="nofollow">
	<p class="widget-title"  style="text-transform: none;">This website was created with the free Call a Nerd theme</p>

	    <div class="pipeSliderPrice"></div>
		<div class="price_slider_amount input_box clearfix">Click here to learn how to create your website for the free Call a Nerd WordPress theme. Provided by your personal WooCommerceOnlineshop and Wordpress Agency from Cologne. The premium theme version does not contain this link</div>
		</a>	
</div>
<?php } } ?>
</div>