<?php
/**
 * A unique identifier is defined to store the options in the database and reference them from the theme.
 */

if(isset($_POST['option_page']) && $_POST['option_page']!=''){

$options=get_option('options-framework-theme'); 
	if(isset($_POST['page_on_front']))
		$options['home-page']=$_POST['page_on_front'];
	if(isset($_POST['page_for_posts']))
	    $options['blog-page']=$_POST['page_for_posts'];
		update_option('options-framework-theme',$options);

}
else{
$options=get_option('options-framework-theme'); 
		$example_colorpicker_page=$options['home-page'];
				$example_colorpicker_blog=$options['blog-page'];

update_option( 'page_on_front', $example_colorpicker_page );
update_option( 'show_on_front', 'page' );
update_option( 'page_for_posts', $example_colorpicker_blog );

	
}


$options=get_option('options-framework-theme'); //foreach($options as $option)echo $option;
	if(isset($options['logo_uploader']) && strpos($options['logo_uploader'],site_url()) !== false)
		$options['logo_uploader']=str_replace(site_url()."/", "/", $options['logo_uploader']);
    if(isset($options['favicon_uploader']) && strpos($options['favicon_uploader'],site_url()) !== false)
		$options['favicon_uploader']=str_replace(site_url()."/", "/", $options['favicon_uploader']);
 if(isset($options['blog_banner_image']) && strpos($options['blog_banner_image'],site_url()) !== false)
		$options['blog_banner_image']=str_replace(site_url()."/", "/", $options['blog_banner_image']);
if(isset($options['shop_banner_image']) && strpos($options['shop_banner_image'],site_url()) !== false)
		$options['shop_banner_image']=str_replace(site_url()."/", "/", $options['shop_banner_image']);
if(isset($options['global_background_image']) && strpos($options['global_background_image'],site_url()) !== false)
		$options['global_background_image']=str_replace(site_url()."/", "/", $options['global_background_image']);
if(isset($options['pages_background_image']) && strpos($options['pages_background_image'],site_url()) !== false)
		$options['pages_background_image']=str_replace(site_url()."/", "/", $options['pages_background_image']);
if(isset($options['posts_background_image']) && strpos($options['posts_background_image'],site_url()) !== false)
		$options['posts_background_image']=str_replace(site_url()."/", "/", $options['posts_background_image']);
if(isset($options['categories_background_image']) && strpos($options['categories_background_image'],site_url()) !== false)
		$options['categories_background_image']=str_replace(site_url()."/", "/", $options['categories_background_image']);
if(isset($options['tags_background_image']) && strpos($options['tags_background_image'],site_url()) !== false)
		$options['tags_background_image']=str_replace(site_url()."/", "/", $options['tags_background_image']);
if(isset($options['shop_background_image']) && strpos($options['shop_background_image'],site_url()) !== false)
		$options['shop_background_image']=str_replace(site_url()."/", "/", $options['shop_background_image']);
if(isset($options['productcategories_background_image']) && strpos($options['productcategories_background_image'],site_url()) !== false)
		$options['productcategories_background_image']=str_replace(site_url()."/", "/", $options['productcategories_background_image']);
if(isset($options['producttags_background_image']) && strpos($options['producttags_background_image'],site_url()) !== false)
		$options['producttags_background_image']=str_replace(site_url()."/", "/", $options['producttags_background_image']);
if(isset($options['singleproducts_background_image']) && strpos($options['singleproducts_background_image'],site_url()) !== false)
		$options['singleproducts_background_image']=str_replace(site_url()."/", "/", $options['singleproducts_background_image']);
	
		update_option('options-framework-theme',$options);
	

			

function optionsframework_option_name() {
	// Change this to use your theme slug
	return 'options-framework-theme';
}

/**
 * Defines an array of options that will be used to generate the settings page and be saved in the database.
 * When creating the 'id' fields, make sure to use all lowercase and no spaces.
 *
 * If you are making your theme translatable, you should replace 'call-a-nerd-theme'
 * with the actual text domain for your theme.  Read more:
 * http://codex.wordpress.org/Function_Reference/load_theme_textdomain
 */

function optionsframework_options() {

	// Test data
	$test_array = array(
		'one' => __( 'One', 'call-a-nerd-theme' ),
		'two' => __( 'Two', 'call-a-nerd-theme' ),
		'three' => __( 'Three', 'call-a-nerd-theme' ),
		'four' => __( 'Four', 'call-a-nerd-theme' ),
		'five' => __( 'Five', 'call-a-nerd-theme' )
	);

	// Multicheck Array
	$multicheck_array = array(
		'one' => __( 'French Toast', 'call-a-nerd-theme' ),
		'two' => __( 'Pancake', 'call-a-nerd-theme' ),
		'three' => __( 'Omelette', 'call-a-nerd-theme' ),
		'four' => __( 'Crepe', 'call-a-nerd-theme' ),
		'five' => __( 'Waffle', 'call-a-nerd-theme' )
	);

	// Multicheck Defaults
	$multicheck_defaults = array(
		'one' => '1',
		'five' => '1'
	);

	// Background Defaults
	$background_defaults = array(
		'color' => '',
		'image' => '',
		'repeat' => 'repeat',
		'position' => 'top center',
		'attachment'=>'scroll' );

	// Typography Defaults
	$typography_defaults = array(
		'size' => '15px',
		'face' => 'georgia',
		'style' => 'bold',
		'color' => '#bada55' );

	// Typography Options
	$typography_options = array(
		'sizes' => array( '6','12','14','16','20' ),
		'faces' => array( 'Helvetica Neue' => 'Helvetica Neue','Arial' => 'Arial' ),
		'styles' => array( 'normal' => 'Normal','bold' => 'Bold' ),
		'color' => false
	);

	// Pull all the categories into an array
	$options_categories = array();
	$options_categories_obj = get_categories();
	foreach ($options_categories_obj as $category) {
		$options_categories[$category->cat_ID] = $category->cat_name;
	}

	// Pull all tags into an array
	$options_tags = array();
	$options_tags_obj = get_tags();
	foreach ( $options_tags_obj as $tag ) {
		$options_tags[$tag->term_id] = $tag->name;
	}


	// Pull all the pages into an array
	$options_pages = array();
	$options_pages_obj = get_pages( 'sort_column=post_parent,menu_order' );
	$options_pages[''] = 'Select a page:';
	foreach ($options_pages_obj as $page) {
		$options_pages[$page->ID] = $page->post_title;
	}

	// If using image radio buttons, define a directory path
	$imagepath =  get_template_directory_uri() . '/images/';

	$options = array();

	$options[] = array(
		'name' => __( 'Basic options', 'call-a-nerd-theme' ),
		'type' => 'heading',
		'desc' => '<a href="https://callanerd.help/category/wordpress-theme/" target="_blank">'.__('Click here to view the theme documentation','call-a-nerd-theme').'</a>',
		'imgurl'=>get_template_directory_uri('template_directory').'/images/home.png'
	);

	
	$options[] = array(
		'name' => __( 'Header behaviour', 'call-a-nerd-theme' ),
		'desc' => __( 'Here you can choose if the header is always visible on top or will be hidden after scrolling down', 'call-a-nerd-theme' ),
		'id' => 'global_header_behaviour',
		'std' => 'sticky',
		'type' => 'select','class' => 'mini', //mini, tiny, small
		'options' => array(
			'sticky' => __( 'Always on top', 'call-a-nerd-theme' ),
			'nonsticky' => __( 'Not scrolling', 'call-a-nerd-theme' ),
		)
	);
	
	
	$options[] = array(
		'name' => __( 'Global Logo Position', 'call-a-nerd-theme' ),
		'desc' => __( 'Here you can define the logo position(If you selecting Center then you need to have mandatory to assign Primary and Secondary menu for Left and Right part of navigation respectively.)', 'call-a-nerd-theme' ),
		'id' => 'global_logo_position',
		'std' => '',
		'class' => 'mini', //mini, tiny, small
		'type' => 'select',
		'options' => array(
			'left' => __( 'Left', 'call-a-nerd-theme' ),
			'center' => __( 'Center', 'call-a-nerd-theme' ),
            'right' => __( 'Right', 'call-a-nerd-theme' ),
		)
	);

	

	
	$options[] = array(
		'name' => __( 'Header logo', 'call-a-nerd-theme' ),
		'desc' => __( 'Click on "change" to select a new header logo', 'call-a-nerd-theme' ),
		'id' => 'logo_uploader',
		'type' => 'upload'
	);
	
	
	$options[] = array(
		'name' => __( 'Favicon', 'call-a-nerd-theme' ),
		'desc' => __( 'Click on "change" to select a Favicon' ,'call-a-nerd-theme'),
		'id' => 'favicon_uploader',
				'std' => get_template_directory_uri() .'/images/favicon.jpg',
		'type' => 'upload'
	);

	$options[] = array(
		'name' => __( 'Footer columns', 'call-a-nerd-theme' ),
		'desc' => __( 'Here you can define the number of columns in the footer (bottom section)', 'call-a-nerd-theme' ),
		'id' => 'number_of_widgets',
		'std' => '',
		'class' => 'mini', //mini, tiny, small
		'type' => 'select',
		'options' => array(
			'2' => __( '2', 'call-a-nerd-theme' ),
			'3' => __( '3', 'call-a-nerd-theme' ),
			'4' => __( '4', 'call-a-nerd-theme' ),
		)
	);

	$pages=array();
	$query=new WP_Query('showposts=-1&post_type=page');
	while($query->have_posts()){ $query->the_post();
		$pages[$query->post->ID]=get_the_title($query->post->ID);

	}
	$options[] = array(
		'name' => __( 'Select frontpage', 'call-a-nerd-theme' ),
		'desc' => sprintf(__( 'Here you can select the frontpage of your website <a href=%s>View home Page</a>', 'call-a-nerd-theme' ),home_url()),
		'id' => 'home-page',
		'placeholder' => '',
		'class' => 'mini',
		'std' => '',
		'type' => 'select',
		'options' => $pages
	);
		$options[] = array(
		'name' => __( 'Define main blogpage', 'call-a-nerd-theme' ),
		'desc' => sprintf(__( 'Here you can define the page that is containing the blog main page with the category list <a href=%s>View Blog Page</a>', 'call-a-nerd-theme' ),get_permalink( get_option( 'page_for_posts' ) )),
		'id' => 'blog-page',
		'placeholder' => '',
		'class' => 'mini',
		'std' => '',
		'type' => 'select',
		'options' => $pages
	);

	$options[] = array(
		'name' => __( 'Header fontsize', 'call-a-nerd-theme' ),
		'desc' => '',
		'id' => 'header-font-size',
		'placeholder' => '',
		'type' => 'select',
		'class' => 'mini',
		'std' => '16',
		'options' => array(
				9 => '9px',
				10 => '10px',
				11 => '11px',
				12=> '12px',
				13 => '13px',
				14 => '14px',
				15 => '15px',
				16 => '16px',
				17 => '17px',
				18 => '18px',
				19 => '19px',
				20 => '20px',
				21 => '21px',
				22 => '22px',
				23 => '23px',
				24 => '24px',
				25 => '25px',

			)	
	);

		$options[] = array(
		'name' => __( 'Footer fontsize', 'call-a-nerd-theme' ),
		'desc' => '',
		'id' => 'footer-font-size',
		'placeholder' => '',
			'class' => 'mini',
			'std' => '14',
			'type' => 'select',

		'options' => array(
				9 => '9px',
				10 => '10px',
				11 => '11px',
				12=> '12px',
				13 => '13px',
				14 => '14px',
				15 => '15px',
				16 => '16px',
				17 => '17px',
				18 => '18px',
				19 => '19px',
				20 => '20px',
				21 => '21px',
				22 => '22px',
				23 => '23px',
				24 => '24px',
				25 => '25px',

			)	
	);
	$options[] = array(
		'name' => __( 'Sidebar heading fontsize', 'call-a-nerd-theme' ),
		'desc' => '',
		'id' => 'sidebar-title-font-size',
		'placeholder' => '',
		'type' => 'select',
		'class' => 'mini',
		'std' => '16',
		'options' => array(
				9 => '9px',
				10 => '10px',
				11 => '11px',
				12=> '12px',
				13 => '13px',
				14 => '14px',
				15 => '15px',
				16 => '16px',
				17 => '17px',
				18 => '18px',
				19 => '19px',
				20 => '20px',
				21 => '21px',
				22 => '22px',
				23 => '23px',
				24 => '24px',
				25 => '25px',

			)	
	);

	$options[] = array(
		'name' => __( 'Sidebar content fontsize', 'call-a-nerd-theme' ),
		'desc' => '',
		'id' => 'sidebar-text-font-size',
		'placeholder' => '',
		'type' => 'select',
		'class' => 'mini',
		'std' => '16',
		'options' => array(
				9 => '9px',
				10 => '10px',
				11 => '11px',
				12=> '12px',
				13 => '13px',
				14 => '14px',
				15 => '15px',
				16 => '16px',
				17 => '17px',
				18 => '18px',
				19 => '19px',
				20 => '20px',
				21 => '21px',
				22 => '22px',
				23 => '23px',
				24 => '24px',
				25 => '25px',

			)	
	);
	
	$options[] = array(
		'name' => __( 'Display search in header', 'call-a-nerd-theme' ),
		'desc' => __( 'Display search YES/NO', 'call-a-nerd-theme' ),
		'id' => 'display_search',
		'std' => 'no',
		'class' => 'mini', //mini, tiny, small
		'type' => 'select',
		'options' => array(
			'yes' => __( 'Yes', 'call-a-nerd-theme' ),
			'no' => __( 'No', 'call-a-nerd-theme' )
		)
	);
	$options[] = array(
		'name' => __( 'Display preheader', 'call-a-nerd-theme' ),
		'desc' => __( 'Display preheader YES/NO', 'call-a-nerd-theme' ),
		'id' => 'display_preheader',
		'std' => 'no',
		'class' => 'mini', //mini, tiny, small
		'type' => 'select',
		'options' => array(
			'yes' => __( 'Yes', 'call-a-nerd-theme' ),
			'no' => __( 'No', 'call-a-nerd-theme' )
		)
	);

	$options[] = array(
		'name' => __( 'Page settings', 'call-a-nerd-theme' ),
		'type' => 'heading',
		'imgurl'=>get_template_directory_uri('template_directory').'/images/toolbox.png'
	);
$options[] = array(
		'name' => __( 'Header Design', 'call-a-nerd-theme' ),
		'id' => 'header_select',
		'std' => 'one',
		'type' => 'select',
		'class' => 'mini', //mini, tiny, small
		'options' => array(
			'solid' => __( 'Solid and separate', 'call-a-nerd-theme' ),
			'tao' => __( 'Transparent and overlay', 'call-a-nerd-theme' ),
		)
	);


	$options[] = array(
		'name' => __( 'Headline (h1) position', 'call-a-nerd-theme' ),
		'desc' => __( 'This setting defines if the main headline is placed on the main image or below. This option can also be changed in option of each single page', 'call-a-nerd-theme' ),
		'id' => 'page_title_position',
		'type' => 'select', 'std' => 'image_center', 
		'class' => 'mini', //mini, tiny, small
		'options' => array(
			'image_center' => __( 'Centered on image', 'call-a-nerd-theme' ),
			'image_under' => __( 'Below the image', 'call-a-nerd-theme' ),
			'hide' => __( 'Hide', 'call-a-nerd-theme' ),
		)
	);

	$options[] = array(
		'name' => __( 'Size of the featured image', 'call-a-nerd-theme' ),
		'desc' => __( 'With this option you can select the default featured image width of a page. 1080 Pixel is only possible if you also have selected the template "with sidebar" in the single page options. Otherwise the default size is 1170 Pixel instead.', 'call-a-nerd-theme' ),
		'id' => "page_feature_size",
		'std' => "full",	
		'type' => "select",
		'options' => array(
			'full' => __( 'Fullwidth', 'call-a-nerd-theme' ),
			'box' => __( '1170 pixel width', 'call-a-nerd-theme' ),
			'content' => __( '1080 pixel width', 'call-a-nerd-theme' ),
			'nofeature' => __( 'No featured image', 'call-a-nerd-theme' )		)		
	);
	
	
	foreach ( $GLOBALS['wp_registered_sidebars'] as $sidebar ) { 
 	$allsidebars[ucwords( $sidebar['id'] )]=ucwords( $sidebar['name'] );
 }

$options[] = array(
		'name' => __( 'Page sidebar', 'call-a-nerd-theme' ),
		'desc' => __( 'Here you can define which sidebar will be displayed on the pages. You can find the sidebar in settings under Design->Widgets', 'call-a-nerd-theme' ),
		'id' => 'main_page_sidebar',
		'std' => '',
		'type' => 'select',
		'class' => 'mini', //mini, tiny, small
		'options' => $allsidebars,
	);
	
	








	$options[] = array(
		'name' => __( 'Blog main page', 'call-a-nerd-theme' ),
		'desc' => __( '<a href="'.site_url().'/index.php?p='.get_option('page_for_posts').'">Blog</a>', 'call-a-nerd-theme' ),
		'type' => 'heading',
		'imgurl'=>get_template_directory_uri('template_directory').'/images/blog.png'
	);

	
	$options[] = array(
		'name' => __( 'Blog page design', 'call-a-nerd-theme' ),
		'desc' => __( 'You can choose between 3 different category list designs: 1 Two categories side by side 2 One category at full width 3 Picture left text right', 'call-a-nerd-theme' ),
		'id' => 'blogseitendesign',
		'type' => 'select',
				'std' => 'template-3',
		'class' => 'mini', //mini, tiny, small

		'options' => array(
			'template-1' => __('Two posts side by side','call-a-nerd-theme'),
			'template-2' => __('One post at full width','call-a-nerd-theme'),
			'template-3' => __('Picture left text right','call-a-nerd-theme'),
		)

	);

	$options[] = array(
		'name' => __( 'Position of headlines', 'call-a-nerd-theme' ),
		'desc' => __( 'The headlines of category preview can be centered on image or below', 'call-a-nerd-theme' ),
		'id' => 'blogpage_title_position',
		'type' => 'select', 'std' => 'image_under',
		'class' => 'mini', //mini, tiny, small
		'options' => array(
			'image_center' => __( 'Centered on image', 'call-a-nerd-theme' ),
			'image_under' => __( 'Below the image', 'call-a-nerd-theme' ),
		)
	);

	$options[] = array(
		'name' => __( 'Blog title', 'call-a-nerd-theme' ),
		'std' => 'Hide',
		'id' => 'blog_hide_title',
		'type' => 'select',
		'options' => array(
			'Hide' => __('Hide','call-a-nerd-theme'),
			'Show' => __('Show','call-a-nerd-theme'),
		)

	);

	$options[] = array(
		'name' => __( 'Blog Banner Image', 'call-a-nerd-theme' ),
		'desc' => __( 'Upload Blog banner from here', 'call-a-nerd-theme' ),
		'id' => 'blog_banner_image',
		'type' => 'upload'
	);

		$options[] = array(
		'name' => __( 'Blog page feature size', 'call-a-nerd-theme' ),
		'desc' => __( 'With this option you can select the default featured image width of a page. 1080 Pixel is only possible if you also have selected the template "with sidebar" in the single page options. Otherwise the default size is 1170 Pixel instead.', 'call-a-nerd-theme' ),
		'id' => "blog_page_feature_size",
		'std' => "full",	
		'type' => "select",
		'options' => array(
			'full' => __( 'Fullwidth', 'call-a-nerd-theme' ),
			'box' => __( '1170 pixel width', 'call-a-nerd-theme' ),
			'content' => __( '1080 pixel width', 'call-a-nerd-theme' ),
			'nofeature' => __( 'No featured image', 'call-a-nerd-theme' )		)		
	);

	
$options[] = array(
		'name' => __( 'Excerpt', 'call-a-nerd-theme' ),
		'std' => 'Hide',
		'id' => 'blog_hide_e',
		'type' => 'select',
		'options' => array(
			'Hide' => __('Hide','call-a-nerd-theme'),
			'Show' => __('Show','call-a-nerd-theme'),
		)

	);
	
	$options[] = array(
		'name' => __( 'Author and Published', 'call-a-nerd-theme' ),
		'std' => 'Show',
		'id' => 'blog_hide_ap',
		'type' => 'select',
		'options' => array(
			'Hide' => __('Hide','call-a-nerd-theme'),
			'Show' => __('Show','call-a-nerd-theme'),
		)

	);
	
	$options[] = array(
		'name' => __( 'Category Details', 'call-a-nerd-theme' ),
		'std' => 'Show',
		'id' => 'blog_hide_c',
		'type' => 'select',
		'options' => array(
			'Hide' => __('Hide','call-a-nerd-theme'),
			'Show' => __('Show','call-a-nerd-theme'),
		)

	);
	
	
	foreach ( $GLOBALS['wp_registered_sidebars'] as $sidebar ) { 
 	$allsidebars[ucwords( $sidebar['id'] )]=ucwords( $sidebar['name'] );
 }
	$options[] = array(
		'name' => __("Sidebar Position",'call-a-nerd-theme' ),
		'desc' => __("Here you can select if and where the sidebar is displayed on the category overview page",'call-a-nerd-theme' ),
		'id' => "blog_layout",
		'std' => "with-sidebar",
		'type' => "images",
		'options' => array(
			'without-sidebar' => $imagepath . '1col.png',
			'with-sidebar' => $imagepath . '2cr.png',
			'with-sidebar-left' => $imagepath . '2cl.png',
		)
	);

$options[] = array(
		'name' => __( 'Select sidebar', 'call-a-nerd-theme' ),
		'desc' => __( 'Here you can define which sidebar will be displayed on the pages. You can find the sidebar in settings under Design->Widgets', 'call-a-nerd-theme' ),
		'id' => 'blog_page_sidebar',
		'std' => 'Sidebar-1',
		'type' => 'select',
		'class' => 'mini', //mini, tiny, small
		'options' => $allsidebars,
	);

	
	$options[] = array(
		'name' => __( 'Single blog post', 'call-a-nerd-theme' ),
		'type' => 'heading',
		'imgurl'=>get_template_directory_uri('template_directory').'/images/page.png'
	);

$options[] = array(
		'name' => __( 'Headline (h1) position', 'call-a-nerd-theme' ),
		'desc' => __( 'The headlines of category preview can be centered on image or below', 'call-a-nerd-theme' ),
		'id' => 'post_title_position',
		'type' => 'select', 'std' => 'image_center',
		'class' => 'mini', //mini, tiny, small
		'options' => array(
			'image_center' => __( 'Centered on image', 'call-a-nerd-theme' ),
			'image_under' => __( 'Below the image', 'call-a-nerd-theme' ),
		)
	);
	
	$options[] = array(
		'name' => __( 'Size of the featured image', 'call-a-nerd-theme' ),
		'desc' => __( 'With this option you can select the default featured image width of a page. 1080 Pixel is only possible if you also have selected the template "with sidebar" in the single page options. Otherwise the default size is 1170 Pixel instead.', 'call-a-nerd-theme' ),
		'id' => 'post_feature_size',
		'std' => "full",	
		'type' => "select",
		'options' => array(
			'full' => __( 'Fullwidth', 'call-a-nerd-theme' ),
			'box' => __( '1170 pixel width', 'call-a-nerd-theme' ),
			'content' => __( '1080 pixel width', 'call-a-nerd-theme' ),
			'nofeature' => __( 'No featured image', 'call-a-nerd-theme' )		)		
	);
	
	
	
	$options[] = array(
		'name' => __( 'Sidebar Position', 'call-a-nerd-theme' ),
		'desc' => __( 'Here you can select if and where the sidebar is displayed on the category overview page', 'call-a-nerd-theme' ),
		'id' => "blog_single_layout",
		'std' => "with-sidebar",
		'type' => "images",
		'options' => array(
			'without-sidebar' => $imagepath . '1col.png',
			'with-sidebar' => $imagepath . '2cr.png',
			'with-sidebar-left' => $imagepath . '2cl.png',
		)
	);

$options[] = array(
		'name' => __( 'Select sidebar', 'call-a-nerd-theme' ),
		'desc' => __( 'Here you can define which sidebar will be displayed on pages. You can find the sidebar in settings under Design->Widgets', 'call-a-nerd-theme' ),
		'id' => 'blog_detail_page_sidebar',
		'std' => 'Sidebar-1',
		'type' => 'select',
		'class' => 'mini', //mini, tiny, small
		'options' => $allsidebars,
	);

$options[] = array(
		'name' => __( 'Categories', 'call-a-nerd-theme' ),
		'std' => 'Hide',
		'id' => 'post_hide_c',
		'type' => 'select',
		'options' => array(
			'Hide' => __('Hide','call-a-nerd-theme'),
			'Show' => __('Show','call-a-nerd-theme'),
		)

	);
	$options[] = array(
		'name' => __( 'Tags', 'call-a-nerd-theme' ),
		'std' => 'Hide',
		'id' => 'post_hide_t',
		'type' => 'select',
		'options' => array(
			'Hide' => __('Hide','call-a-nerd-theme'),
			'Show' => __('Show','call-a-nerd-theme'),
		)

	);

$options[] = array(
		'name' => __( 'Related posts', 'call-a-nerd-theme' ),
		'desc' => __( 'Related posts help the user to navigate and extend the visitors time on the website.  This option can also be changed in option of each single page', 'call-a-nerd-theme' ),
		'id' => 'show_related_post_post',
		'std' => 'post',
		'type' => 'select',
		'options' => array(
			'post' =>__('Show similar posts', 'call-a-nerd-theme' ),
			'none' => __('Hide', 'call-a-nerd-theme' ),
		)
	
	);
	

if(of_get_option('show_related_post_post')=="post")
$options[] = array(
		'name' => __( 'Show related posts by this criteria', 'call-a-nerd-theme' ),
		'desc' => __( 'These are different selctable options to define the related products: 1 Category 2 Tag 3 Category and tag 4 Newst Posts 5 Random', 'call-a-nerd-theme' ),
		'id' => 'show_related_post_by',
		'std' => 'category',
		'type' => 'select',
		'options' => array(
			'category' => __( 'Category', 'call-a-nerd-theme'),
			'tag' =>  __( 'Tags', 'call-a-nerd-theme'),
			'recent' =>  __( 'Newest Posts', 'call-a-nerd-theme'),
			'random' =>  __( 'Random', 'call-a-nerd-theme'),
		)
	
	); 



    $options[] = array(
		'name' => __( 'Blog category & tags', 'call-a-nerd-theme' ),
		'type' => 'heading',
		'imgurl'=>get_template_directory_uri('template_directory').'/images/tags.png'
	);


	
$options[] = array(
		'name' => __( 'Category design | Tag design', 'call-a-nerd-theme' ),
		'desc' => __( 'You can choose between 3 different category overview designs: 1 Two categories side by side 2 One category at full with 3 Picture left text right.  This option can also be changed in option of each single category and tag', 'call-a-nerd-theme' ),
		'id' => 'blogkategoriedesign',
		'type' => 'select',
		'options' => array(
			'template-1' => __('Two posts side by side','call-a-nerd-theme'),
			'template-2' => __('One post at full width','call-a-nerd-theme'),
			'template-3' => __('Picture left text right','call-a-nerd-theme'),
		)

	);
	
	
	$options[] = array(
		'name' => __( 'Position of category headlines  | Position of tag headlines', 'call-a-nerd-theme' ),
		'desc' => __( 'The headlines can be centered on image or below', 'call-a-nerd-theme' ),
		'id' => 'blog_cat_title_position',
		'type' => 'select', 'std' => 'image_under',
		'class' => 'mini', //mini, tiny, small
		'options' => array(
			'image_center' => __( 'Centered on image', 'call-a-nerd-theme' ),
			'image_under' => __( 'Below the image', 'call-a-nerd-theme' ),
		)
	);
	
	
	$options[] = array(
		'name' => __( 'Excerpt', 'call-a-nerd-theme' ),
		'std' => 'Hide',
		'id' => 'blogcategorytag_hide_e',
		'type' => 'select',
		'options' => array(
			'Hide' => __('Hide','call-a-nerd-theme'),
			'Show' => __('Show','call-a-nerd-theme'),
		)

	);
	
	$options[] = array(
		'name' => __( 'Author and Published', 'call-a-nerd-theme' ),
		'std' => 'Show',
		'id' => 'blogcategorytag_hide_ap',
		'type' => 'select',
		'options' => array(
			'Hide' => __('Hide','call-a-nerd-theme'),
			'Show' => __('Show','call-a-nerd-theme'),
		)

	);
	
	$options[] = array(
		'name' => __( 'Category Details', 'call-a-nerd-theme' ),
		'std' => 'Show',
		'id' => 'blogcategorytag_hide_c',
		'type' => 'select',
		'options' => array(
			'Hide' => __('Hide','call-a-nerd-theme'),
			'Show' => __('Show','call-a-nerd-theme'),
		)

	);
	
	

		$options[] = array(
		'name' => __("Size of the featured image",'call-a-nerd-theme'),
		'desc' => __( 'With this option you can select the default featured image width of a page. 1080 Pixel is only possible if you also have selected the template "with sidebar" in the single page options. Otherwise the default size is 1170 Pixel instead.','call-a-nerd-theme'),
		'id' => "blog_category_page_feature_size",
		'std' => "full",
		'type' => "select",
		'options' => array(
			'full' => __( 'Fullwidth', 'call-a-nerd-theme' ),
			'box' => __( '1170 pixel width', 'call-a-nerd-theme' ),
			'content' => __( '1080 pixel width', 'call-a-nerd-theme' ),
			'nofeature' => __( 'No featured image', 'call-a-nerd-theme' )
		));

		
$options[] = array(
		'name' => __( 'Sidebar Position', 'call-a-nerd-theme' ),
		'desc' => __( 'Here you can select if and where the sidebar is displayed', 'call-a-nerd-theme' ),
		'id' => "blog_category_layout",
		'std' => "with-sidebar",
		'type' => "images",
		'options' => array(
			'without-sidebar' => $imagepath . '1col.png',
			'with-sidebar' => $imagepath . '2cr.png',
			'with-sidebar-left' => $imagepath . '2cl.png',
		)
	);



$options[] = array(
		'name' => __( 'Select sidebar', 'call-a-nerd-theme' ),
		'desc' => __( 'Here you can define which sidebar will be displayed on pages. You can find the sidebar in settings under Design->Widgets', 'call-a-nerd-theme' ),
		'id' => 'blog_category_page_sidebar',
		'std' => 'three',
		'type' => 'select',
		'class' => 'mini', //mini, tiny, small
		'options' => $allsidebars,
	);



	
		$options[] = array(
		'name' => __( 'Shop frontpage', 'call-a-nerd-theme' ),
		'type' => 'heading',
		'imgurl'=>get_template_directory_uri('template_directory').'/images/shop.png'
	);
	
	
	$options[] = array(
		'name' => __( 'Shop Page Title', 'call-a-nerd-theme' ),
		'desc' => '',
		'id' => 'shop_page_title',
		'std' => 'Shop',
		'type' => 'text'
	);

	
$options[] = array(
		'name' => __( 'Headline (h1) position', 'call-a-nerd-theme' ),
		'desc' => __( 'The headlines of category preview can be centered on image or below', 'call-a-nerd-theme' ),
		'id' => 'shop_title_position',
		'type' => 'select', 'std' => 'image_center',
		'class' => 'mini', //mini, tiny, small
		'options' => array(
			'hide' => __( 'Hide', 'call-a-nerd-theme' ),
			'image_center' => __( 'Centered on image', 'call-a-nerd-theme' ),
			'image_under' => __( 'Below the image', 'call-a-nerd-theme' ),
		)
	);    
    

	$options[] = array(
		'name' => __( 'Main page', 'call-a-nerd-theme' ),
		'desc' => __( 'Here you can change the main image. The image should have at least more resolution than the next size option', 'call-a-nerd-theme' ),
		'id' => 'shop_banner_image',
		'type' => 'upload'
	);

		$options[] = array(
		'name' => __('Size of the featured image', 'call-a-nerd-theme'),
		'desc' => __('With this option you can select the default featured image width of a page. 1080 Pixel is only possible if you also have selected the template "with sidebar" in the single page options. Otherwise the default size is 1170 Pixel instead.', 'call-a-nerd-theme'),
		'id' => "shop_page_feature_size",
		'std' => "full",
		'type' => "select",
		'options' => array(
			'full' => __( 'Fullwidth', 'call-a-nerd-theme' ),
			'box' => __( '1170 pixel width', 'call-a-nerd-theme' ),
			'nofeature' => __( 'No featured image', 'call-a-nerd-theme' )
		)		
	);

$options[] = array(
		'name' => __( 'Show / Hide top cart?', 'call-a-nerd-theme' ),
		'desc' => '',
		'id' => 'show_hide_top_cart',
		'std' => 'show',
		'type' => 'select',
		'options' => array(
			'show' => __( 'Show', 'call-a-nerd-theme' ),
			'hide' => __( 'Hide', 'call-a-nerd-theme' ),
		)
	);

	$options[] = array(
		'name' => __( 'Top cart will display number of products added to cart or total of them?', 'call-a-nerd-theme' ),
		'desc' => '',
		'id' => 'top_cart_display',
		'std' => 'number',
		'type' => 'select',
		'options' => array(
			'number' => __( 'Number of items', 'call-a-nerd-theme' ),
			'total' => __( 'Total', 'call-a-nerd-theme' ),
		)
	);
	

	$options[] = array(
		'name' => __("Sidebar Position", 'call-a-nerd-theme'),
		'desc' => __("Here you can select if and where the sidebar is displayed", 'call-a-nerd-theme'),
		'id' => "shop_layout",
		'std' => "without-sidebar",
		'type' => "images",
		'options' => array(
			'without-sidebar' => $imagepath . '1col.png',
			'with-sidebar' => $imagepath . '2cr.png',
			'with-sidebar-left' => $imagepath . '2cl.png',
		)
	);


		$options[] = array(
		'name' => __( 'Select sidebar', 'call-a-nerd-theme' ),
		'desc' => __( 'Here you can define which sidebar will be displayed on pages. You can find the sidebar in settings under Design->Widgets', 'call-a-nerd-theme' ),
		'id' => 'shop_page_sidebar',
		'std' => 'three',
		'type' => 'select',
		'class' => 'mini', //mini, tiny, small
		'options' => $allsidebars,
	);


		$options[] = array(
		'name' => __( 'Shop category & tags', 'call-a-nerd-theme' ),
		'type' => 'heading',
		'imgurl'=>get_template_directory_uri('template_directory').'/images/shop_tags.png'
	);

$options[] = array(
		'name' => __( 'Headline (h1) position', 'call-a-nerd-theme' ),
		'desc' => __( 'The headlines of category preview can be centered on image or below', 'call-a-nerd-theme' ),
		'id' => 'shop_category_title_position',
		'type' => 'select', 'std' => 'image_center',
		'class' => 'mini', //mini, tiny, small
		'options' => array(
			'image_center' => __( 'Centered on image', 'call-a-nerd-theme' ),
			'image_under' => __( 'Below the image', 'call-a-nerd-theme' ),
		)
	);


	
$options[] = array(
		'name' => __('Size of the featured image', 'call-a-nerd-theme'),
		'desc' => __('With this option you can select the default featured image width of a page. 1080 Pixel is only possible if you also have selected the template "with sidebar" in the single page options. Otherwise the default size is 1170 Pixel instead.', 'call-a-nerd-theme'),
		'id' => "shop_category_page_feature_size",
		'std' => "full",
		'type' => "select",
		'options' => array(
			'full' => __( 'Fullwidth', 'call-a-nerd-theme' ),
			'box' => __( '1170 pixel width', 'call-a-nerd-theme' ),
			'nofeature' => __( 'No featured image', 'call-a-nerd-theme' )
		)		
	);

      
	
	
	$options[] = array(
		'name' => __( 'Sidebar Position', 'call-a-nerd-theme' ),
		'desc' => __( 'Here you can select if and where the sidebar is displayed', 'call-a-nerd-theme' ),
		'id' => "shop_category_layout",
		'std' => "without-sidebar",
		'type' => "images",
		'options' => array(
			'without-sidebar' => $imagepath . '1col.png',
			'with-sidebar' => $imagepath . '2cr.png',
			'with-sidebar-left' => $imagepath . '2cl.png',
		)
	);


		$options[] = array(
		'name' => __( 'Select sidebar', 'call-a-nerd-theme' ),
		'desc' => __( 'Here you can define which sidebar will be displayed on pages. You can find the sidebar in settings under Design->Widgets', 'call-a-nerd-theme' ),
		'id' => 'shop_category_page_sidebar',
		'std' => 'three',
		'type' => 'select',
		'class' => 'mini', //mini, tiny, small
		'options' => $allsidebars,
	);

	

		$options[] = array(
		'name' => __( 'Shop single product', 'call-a-nerd-theme' ),
		'type' => 'heading',
		'imgurl'=>get_template_directory_uri('template_directory').'/images/box.png'
	);



$options[] = array(
		'name' => __('Width of the description', 'call-a-nerd-theme'),
		'desc' => __('with in container or fullwidth', 'call-a-nerd-theme'),
		'id' => "shop_detail_description",
		'std' => "full",
		'type' => "select",
		'options' => array(
			'full' => __( 'fullwidth', 'call-a-nerd-theme' ),
			'box' => __( 'with in container', 'call-a-nerd-theme' )
		)		
	);

$options[] = array(
		'name' => __( 'Show related products?', 'call-a-nerd-theme' ),
		'desc' => __( 'Related products help the user to navigate and extend the visitors time on the website. This also increase sales This option can also be changed in option of each single product', 'call-a-nerd-theme' ),
		'id' => 'show_related_post',
		'std' => 'product',
		'type' => 'select',
		'options' => array(
			'product' => __('Show similar product', 'call-a-nerd-theme' ),
			'none' => __('None', 'call-a-nerd-theme' ),

		)
	
	);

	$options[] = array(
		'name' => __( 'Sidebar Position', 'call-a-nerd-theme' ),
		'desc' => __( 'Here you can select if and where the sidebar is displayed', 'call-a-nerd-theme' ),
		'id' => "shop_detail_layout",
		'std' => "without-sidebar",
		'type' => "images",
		'options' => array(
			'without-sidebar' => $imagepath . '1col.png',
			'with-sidebar' => $imagepath . '2cr.png',
						'with-sidebar-left' => $imagepath . '2cl.png',
		)
	);



	$options[] = array(
		'name' => __( 'Select sidebar', 'call-a-nerd-theme' ),
		'desc' => __( 'Here you can define which sidebar will be displayed on pages. You can find the sidebar in settings under Design->Widgets', 'call-a-nerd-theme' ),
		'id' => 'shop_detail_page_sidebar',
		'std' => 'three',
		'type' => 'select',
		'class' => 'mini', //mini, tiny, small
		'options' => $allsidebars,
	);

	


	
	$options[] = array(
		'name' => __( 'Select design', 'call-a-nerd-theme' ),
		'type' => 'heading',
		'imgurl'=>get_template_directory_uri('template_directory').'/images/colors.png'
	);



$options[] = array(
		'name' => __( 'Choose color profile', 'call-a-nerd-theme' ),
		'desc' => '',
		'id' => 'theme color',
		'std' => 'one',
		'type' => 'radio',
		'options' => json_decode(get_option('all_color_scheme_pair'),true)
	);



$options[] = array(
		'name' => '',
		'desc' => '',
		'id' => 'example_colorpicker_tab',
		'std' => 'Default',
		'type' => 'tabs');

if(get_option('key_validated')=='1'){
$options[] = array(
		'name' => '',
		'desc' => '',
		'id' => 'save-color-scheme',
		'std' => 'one',
		'type' => 'custombutton',
		'options' => array(
			'save' => 'Save',
			
			)
	);
}

 $options[] = array(
		'name' => __( 'Background Selection', 'call-a-nerd-theme' ),
		'type' => 'heading',
		'imgurl'=>get_template_directory_uri('template_directory').'/images/background-tool.png'
	);
	/*global*/
	$options[] = array(
		'name' => __( 'Global', 'call-a-nerd-theme' ),
		'desc' => __( 'Select Global Background Color/Texture', 'call-a-nerd-theme' ),
		'id' => 'global_background_type',
		'type' => 'radio','std' => 'gbnone', 'class' => 'small',		'options' => array(
			'gbcolor' => __( 'Background Color', 'call-a-nerd-theme' ),
			'gbimage' => __( 'Background Texture', 'call-a-nerd-theme' ),
			'gbnone' => __( 'None', 'call-a-nerd-theme' ),
		)
	);
	$options[] = array(
		'name' => __('Background Color', 'call-a-nerd-theme'),
		'desc' => __('No color selected by default', 'call-a-nerd-theme'),
		'id' => 'global_background_color',
		'std' => '',
		'type' => 'text' );
	$options[] = array(
		'name' => __('Background Texture', 'call-a-nerd-theme'),
		'desc' => __('This creates a full size uploader that previews the texture', 'call-a-nerd-theme'),
		'id' => 'global_background_image',
		'type' => 'upload');
	$options[] = array(
		'name' => __('Background Texture Style', 'call-a-nerd-theme'),
		
		'id' => 'global_background_texture_style',
		'type' => 'select',
	    'std' => 'no-repeat',
		'class' => 'small',
		'options' => array(
			'fixed' => __( 'Fixed', 'call-a-nerd-theme' ),	
			'repeat' => __( 'Repeating', 'call-a-nerd-theme' ),
			'no-repeat' => __( 'Stretched', 'call-a-nerd-theme' ), )	);
		
	/*pages*/
	$options[] = array(
		'name' => __( 'Pages', 'call-a-nerd-theme' ),
		'desc' => __( 'Select Pages Background Color/Texture', 'call-a-nerd-theme' ),
		'id' => 'pages_background_type',
		'type' => 'radio','std' => 'pagesbnone', 'class' => 'small',		'options' => array(
			'pagesbcolor' => __( 'Background Color', 'call-a-nerd-theme' ),
			'pagesbimage' => __( 'Background Texture', 'call-a-nerd-theme' ),
			'pagesbnone' => __( 'None', 'call-a-nerd-theme' ),
		)
	);
	$options[] = array(
		'name' => __('Background Color', 'call-a-nerd-theme'),
		'desc' => __('No color selected by default', 'call-a-nerd-theme'),
		'id' => 'pages_background_color',
		'std' => '',
		'type' => 'text' );
	$options[] = array(
		'name' => __('Background Texture', 'call-a-nerd-theme'),
		'desc' => __('This creates a full size uploader that previews the texture', 'call-a-nerd-theme'),
		'id' => 'pages_background_image',
		'type' => 'upload');
	$options[] = array(
		'name' => __('Background Texture Style', 'call-a-nerd-theme'),
		
		'id' => 'pages_background_texture_style',
		'type' => 'select',
	    'std' => 'no-repeat',
		'class' => 'small',
		'options' => array(
			'fixed' => __( 'Fixed', 'call-a-nerd-theme' ),	
			'repeat' => __( 'Repeating', 'call-a-nerd-theme' ),
			'no-repeat' => __( 'Stretched', 'call-a-nerd-theme' ), )	);
		
	/*posts*/
	$options[] = array(
		'name' => __( 'Posts', 'call-a-nerd-theme' ),
		'desc' => __( 'Select Posts Background Color/Texture', 'call-a-nerd-theme' ),
		'id' => 'posts_background_type',
		'type' => 'radio','std' => 'postsbnone', 'class' => 'small',		'options' => array(
			'postsbcolor' => __( 'Background Color', 'call-a-nerd-theme' ),
			'postsbimage' => __( 'Background Texture', 'call-a-nerd-theme' ),
			'postsbnone' => __( 'None', 'call-a-nerd-theme' ),
		)
	);
	$options[] = array(
		'name' => __('Background Color', 'call-a-nerd-theme'),
		'desc' => __('No color selected by default', 'call-a-nerd-theme'),
		'id' => 'posts_background_color',
		'std' => '',
		'type' => 'text' );
	$options[] = array(
		'name' => __('Background Texture', 'call-a-nerd-theme'),
		'desc' => __('This creates a full size uploader that previews the texture', 'call-a-nerd-theme'),
		'id' => 'posts_background_image',
		'type' => 'upload');
	$options[] = array(
		'name' => __('Background Texture Style', 'call-a-nerd-theme'),
		
		'id' => 'posts_background_texture_style',
		'type' => 'select',
	    'std' => 'no-repeat',
		'class' => 'small',
		'options' => array(
			'fixed' => __( 'Fixed', 'call-a-nerd-theme' ),	
			'repeat' => __( 'Repeating', 'call-a-nerd-theme' ),
			'no-repeat' => __( 'Stretched', 'call-a-nerd-theme' ), )	);

    /*category*/
	$options[] = array(
		'name' => __( 'Categories', 'call-a-nerd-theme' ),
		'desc' => __( 'Select Categories Background Color/Texture', 'call-a-nerd-theme' ),
		'id' => 'categories_background_type',
		'type' => 'radio','std' => 'categoriesbnone', 'class' => 'small',		'options' => array(
			'categoriesbcolor' => __( 'Background Color', 'call-a-nerd-theme' ),
			'categoriesbimage' => __( 'Background Texture', 'call-a-nerd-theme' ),
			'categoriesbnone' => __( 'None', 'call-a-nerd-theme' ),
		)
	);
	$options[] = array(
		'name' => __('Background Color', 'call-a-nerd-theme'),
		'desc' => __('No color selected by default', 'call-a-nerd-theme'),
		'id' => 'categories_background_color',
		'std' => '',
		'type' => 'text' );
	$options[] = array(
		'name' => __('Background Texture', 'call-a-nerd-theme'),
		'desc' => __('This creates a full size uploader that previews the texture', 'call-a-nerd-theme'),
		'id' => 'categories_background_image',
		'type' => 'upload');	
	$options[] = array(
		'name' => __('Background Texture Style', 'call-a-nerd-theme'),
		'id' => 'categories_background_texture_style',
		'type' => 'select',
	    'std' => 'no-repeat',
		'class' => 'small',
		'options' => array(
			'fixed' => __( 'Fixed', 'call-a-nerd-theme' ),	
			'repeat' => __( 'Repeating', 'call-a-nerd-theme' ),
			'no-repeat' => __( 'Stretched', 'call-a-nerd-theme' ), )	);
		
    /*tags*/
	$options[] = array(
		'name' => __( 'Tags', 'call-a-nerd-theme' ),
		'desc' => __( 'Select Tags Background Color/Texture', 'call-a-nerd-theme' ),
		'id' => 'tags_background_type',
		'type' => 'radio','std' => 'tagsbnone', 'class' => 'small',		'options' => array(
			'tagsbcolor' => __( 'Background Color', 'call-a-nerd-theme' ),
			'tagsbimage' => __( 'Background Texture', 'call-a-nerd-theme' ),
			'tagsbnone' => __( 'None', 'call-a-nerd-theme' ),
		)
	);
	$options[] = array(
		'name' => __('Background Color', 'call-a-nerd-theme'),
		'desc' => __('No color selected by default', 'call-a-nerd-theme'),
		'id' => 'tags_background_color',
		'std' => '',
		'type' => 'text' );
	$options[] = array(
		'name' => __('Background Texture', 'call-a-nerd-theme'),
		'desc' => __('This creates a full size uploader that previews the texture', 'call-a-nerd-theme'),
		'id' => 'tags_background_image',
		'type' => 'upload');
	$options[] = array(
		'name' => __('Background Texture Style', 'call-a-nerd-theme'),
		'id' => 'tags_background_texture_style',
		'type' => 'select',
	    'std' => 'no-repeat',
		'class' => 'small',
		'options' => array(
			'fixed' => __( 'Fixed', 'call-a-nerd-theme' ),	
			'repeat' => __( 'Repeating', 'call-a-nerd-theme' ),
			'no-repeat' => __( 'Stretched', 'call-a-nerd-theme' ), )	);
	
	/*Shop*/
	$options[] = array(
		'name' => __( 'Shop Page', 'call-a-nerd-theme' ),
		'desc' => __( 'Select Shop Page Background Color/Texture', 'call-a-nerd-theme' ),
		'id' => 'shop_background_type',
		'type' => 'radio','std' => 'shopbnone', 'class' => 'small',		'options' => array(
			'shopbcolor' => __( 'Background Color', 'call-a-nerd-theme' ),
			'shopbimage' => __( 'Background Texture', 'call-a-nerd-theme' ),
			'shopbnone' => __( 'None', 'call-a-nerd-theme' ),
		)
	);
	$options[] = array(
		'name' => __('Background Color', 'call-a-nerd-theme'),
		'desc' => __('No color selected by default', 'call-a-nerd-theme'),
		'id' => 'shop_background_color',
		'std' => '',
		'type' => 'text' );
	$options[] = array(
		'name' => __('Background Texture', 'call-a-nerd-theme'),
		'desc' => __('This creates a full size uploader that previews the texture', 'call-a-nerd-theme'),
		'id' => 'shop_background_image',
		'type' => 'upload');
	$options[] = array(
		'name' => __('Background Texture Style', 'call-a-nerd-theme'),
		'id' => 'shop_background_texture_style',
		'type' => 'select',
	    'std' => 'no-repeat',
		'class' => 'small',
		'options' => array(
			'fixed' => __( 'Fixed', 'call-a-nerd-theme' ),	
			'repeat' => __( 'Repeating', 'call-a-nerd-theme' ),
			'no-repeat' => __( 'Stretched', 'call-a-nerd-theme' ), )	);

	
	/*product categories*/
	$options[] = array(
		'name' => __( 'Product Categories', 'call-a-nerd-theme' ),
		'desc' => __( 'Select Product Categories Background Color/Texture', 'call-a-nerd-theme' ),
		'id' => 'productcategories_background_type',
		'type' => 'radio','std' => 'productcategoriesbnone', 'class' => 'small',		'options' => array(
			'productcategoriesbcolor' => __( 'Background Color', 'call-a-nerd-theme' ),
			'productcategoriesbimage' => __( 'Background Texture', 'call-a-nerd-theme' ),
			'productcategoriesbnone' => __( 'None', 'call-a-nerd-theme' ),
		)
	);
	$options[] = array(
		'name' => __('Background Color', 'call-a-nerd-theme'),
		'desc' => __('No color selected by default', 'call-a-nerd-theme'),
		'id' => 'productcategories_background_color',
		'std' => '',
		'type' => 'text' );
	$options[] = array(
		'name' => __('Background Texture', 'call-a-nerd-theme'),
		'desc' => __('This creates a full size uploader that previews the texture', 'call-a-nerd-theme'),
		'id' => 'productcategories_background_image',
		'type' => 'upload');
	$options[] = array(
		'name' => __('Background Texture Style', 'call-a-nerd-theme'),
		'id' => 'productcategories_background_texture_style',
		'type' => 'select',
	    'std' => 'no-repeat',
		'class' => 'small',
		'options' => array(
			'fixed' => __( 'Fixed', 'call-a-nerd-theme' ),	
			'repeat' => __( 'Repeating', 'call-a-nerd-theme' ),
			'no-repeat' => __( 'Stretched', 'call-a-nerd-theme' ), )	);

/*product tags*/
	$options[] = array(
		'name' => __( 'Product Tags', 'call-a-nerd-theme' ),
		'desc' => __( 'Select Product Tags Background Color/Texture', 'call-a-nerd-theme' ),
		'id' => 'producttags_background_type',
		'type' => 'radio','std' => 'producttagsbnone', 'class' => 'small',		'options' => array(
			'producttagsbcolor' => __( 'Background Color', 'call-a-nerd-theme' ),
			'producttagsbimage' => __( 'Background Texture', 'call-a-nerd-theme' ),
			'producttagsbnone' => __( 'None', 'call-a-nerd-theme' ),
		)
	);
	$options[] = array(
		'name' => __('Background Color', 'call-a-nerd-theme'),
		'desc' => __('No color selected by default', 'call-a-nerd-theme'),
		'id' => 'producttags_background_color',
		'std' => '',
		'type' => 'text' );
	$options[] = array(
		'name' => __('Background Texture', 'call-a-nerd-theme'),
		'desc' => __('This creates a full size uploader that previews the texture', 'call-a-nerd-theme'),
		'id' => 'producttags_background_image',
		'type' => 'upload');	
$options[] = array(
		'name' => __('Background Texture Style', 'call-a-nerd-theme'),
		'id' => 'producttags_background_texture_style',
		'type' => 'select',
	    'std' => 'no-repeat',
		'class' => 'small',
		'options' => array(
			'fixed' => __( 'Fixed', 'call-a-nerd-theme' ),	
			'repeat' => __( 'Repeating', 'call-a-nerd-theme' ),
			'no-repeat' => __( 'Stretched', 'call-a-nerd-theme' ), )	);
			
    /*product*/
	$options[] = array(
		'name' => __( 'Single Products', 'call-a-nerd-theme' ),
		'desc' => __( 'Select Single Products Background Color/Texture', 'call-a-nerd-theme' ),
		'id' => 'singleproducts_background_type',
		'type' => 'radio','std' => 'singleproductsbnone', 'class' => 'small',		'options' => array(
			'singleproductsbcolor' => __( 'Background Color', 'call-a-nerd-theme' ),
			'singleproductsbimage' => __( 'Background Texture', 'call-a-nerd-theme' ),
			'singleproductsbnone' => __( 'None', 'call-a-nerd-theme' ),
		)
	);
	$options[] = array(
		'name' => __('Background Color', 'call-a-nerd-theme'),
		'desc' => __('No color selected by default', 'call-a-nerd-theme'),
		'id' => 'singleproducts_background_color',
		'std' => '',
		'type' => 'text' );
	$options[] = array(
		'name' => __('Background Texture', 'call-a-nerd-theme'),
		'desc' => __('This creates a full size uploader that previews the texture', 'call-a-nerd-theme'),
		'id' => 'singleproducts_background_image',
		'type' => 'upload');
	$options[] = array(
		'name' => __('Background Texture Style', 'call-a-nerd-theme'),
		'id' => 'singleproducts_background_texture_style',
		'type' => 'select',
	    'std' => 'no-repeat',
		'class' => 'small',
		'options' => array(
			'fixed' => __( 'Fixed', 'call-a-nerd-theme' ),	
			'repeat' => __( 'Repeating', 'call-a-nerd-theme' ),
			'no-repeat' => __( 'Stretched', 'call-a-nerd-theme' ), )	);



	$options[] = array(
		'name' => __( 'Individual code', 'call-a-nerd-theme' ),
		'type' => 'heading',
		'imgurl'=>get_template_directory_uri('template_directory').'/images/code.png'
	);


	$options[] = array(
		'name' => __( 'Javascript', 'call-a-nerd-theme' ),
		'desc' => __( 'The script can be copied into this text box, e.g. alert ( "HII");', 'call-a-nerd-theme' ),
		'id' => 'custom_script',
		'validate' => 'html',
		'std' => '',
		'type' => 'textarea'
	);

		$options[] = array(
		'name' => __( 'Individual CSS', 'call-a-nerd-theme' ),
		'desc' => __( 'The CSS commands can be copied into this text field, e.g. color: #ffffff;', 'call-a-nerd-theme' ),
		'id' => 'custom_css',
		'validate' => 'html',
		'std' => '',
		'type' => 'textarea'
	);

			$options[] = array(
		'name' => __( 'Custom PHP code run after wp_head', 'call-a-nerd-theme' ),
		'desc' => __( 'The PHP code can be copied into this text field and is exported to wp_head e.g. echo "hii";', 'call-a-nerd-theme' ),
		'id' => 'custom_php_code',
		'std' => '',
		'validate' => 'html',
		'type' => 'textarea'
	);


	$options[] = array(
		'name' => __( 'Insert google code', 'call-a-nerd-theme' ),
		'type' => 'heading',
		'imgurl'=>get_template_directory_uri('template_directory').'/images/analytics.png'
	);

$wp_editor_settings = array(
		'wpautop' => true, // Default
		'textarea_rows' => 5,
		'media_buttons' => false,
	    'quicktags' => array( 'buttons' => 'script' ),
	    'tinymce'   => false
	);
	$options[] = array(
		'name' => __( 'Insert google code', 'call-a-nerd-theme' ),
		'desc' => __( 'Here, Google code like the Google analytics tracking code can be inserted e.g. &lt;script&gt;....&lt;/script&gt;','call-a-nerd-theme'),
		'id' => 'google_tracking_code',
		'std' => '',
		'type' => 'editor',
		'settings' => $wp_editor_settings
	);

	$options[] = array(
		'name' => __( 'Custom post types', 'call-a-nerd-theme' ),
		'type' => 'heading',
		'imgurl'=>get_template_directory_uri('template_directory').'/images/custom_post.png'
	);

	$options[] = array(
		'desc' => __( 'Just like "blog post" is a preinstalled type it is also possible to add custom post types like testimonial, portfolio, customers and so on. WordPress has limitations for the length of a custom post type name of 20 characters. Empty spaces in custom post type name are not allowed by wordpress. Therefore we replace the empty space with minus. Example: "Reference customers" is replaced by "Reference-customers" in backend. But in frontend it will Show without that substitution: "Reference customers"', 'call-a-nerd-theme' ),
		'id' => 'list_cui',
		'std' => '',
		'type' => 'list_cui'
	);
	
	$options[] = array(
		'name' => __( 'Licence Key Validation', 'call-a-nerd-theme' ),
		'type' => 'heading',
		'imgurl'=>get_bloginfo('template_directory').'/images/toolbox.png'
	);

$options[] = array(
		'name' => __( 'Licence Key', 'call-a-nerd-theme' ).(get_option('key_validated')=='1'?'&nbsp;&nbsp;✓&nbsp;'.__('Valid','call-a-nerd-theme'):'&nbsp;&nbsp;X&nbsp;'.__('Invalid','call-a-nerd-theme')),
		'desc' => __( 'Please put licence key here', 'call-a-nerd-theme' ),
		'id' => 'licence_key',
		'std' => '','class' => 'validate-required',
		'type' => 'text'
	);

	return $options;
}


?>